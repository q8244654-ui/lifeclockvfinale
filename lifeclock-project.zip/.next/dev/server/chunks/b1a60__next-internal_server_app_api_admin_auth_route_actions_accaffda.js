module.exports = [
"[project]/lifeclock-20251031-141611/.next-internal/server/app/api/admin/auth/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=b1a60__next-internal_server_app_api_admin_auth_route_actions_accaffda.js.map