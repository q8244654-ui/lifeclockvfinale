module.exports = [
"[project]/lifeclock-20251031-141611/node_modules/@supabase/node-fetch/lib/index.js [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/lifeclock-20251031-141611/node_modules/@supabase/node-fetch/lib/index.js [app-route] (ecmascript)");
    });
});
}),
];