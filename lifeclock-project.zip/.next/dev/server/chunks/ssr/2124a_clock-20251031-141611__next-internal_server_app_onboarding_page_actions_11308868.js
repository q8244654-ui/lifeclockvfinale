module.exports = [
"[project]/lifeclock-20251031-141611/.next-internal/server/app/onboarding/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=2124a_clock-20251031-141611__next-internal_server_app_onboarding_page_actions_11308868.js.map