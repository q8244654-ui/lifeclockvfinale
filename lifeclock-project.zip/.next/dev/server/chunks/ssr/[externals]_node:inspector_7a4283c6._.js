module.exports = [
"[externals]/node:inspector [external] (node:inspector, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:inspector", () => require("node:inspector"));

module.exports = mod;
}),
];