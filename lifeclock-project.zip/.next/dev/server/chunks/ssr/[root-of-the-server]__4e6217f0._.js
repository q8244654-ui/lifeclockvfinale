module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[project]/lib/utils.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cn",
    ()=>cn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-ssr] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
}),
"[project]/components/chat-message.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ChatMessage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
function ChatMessage({ role, text, delay = 0, messageType = "normal", showReadReceipt = false, timestamp }) {
    const isAssistant = role === "assistant";
    const [showReceipt, setShowReceipt] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (showReadReceipt && !isAssistant) {
            const timer = setTimeout(()=>{
                setShowReceipt(true);
            }, 1500);
            return ()=>clearTimeout(timer);
        }
    }, [
        showReadReceipt,
        isAssistant
    ]);
    const messageStyles = {
        normal: {
            background: "#2C2C2E",
            color: "#E5E5EA",
            glow: "none",
            haloColor: "transparent",
            tailColor: "#2C2C2E"
        },
        motivation: {
            background: "linear-gradient(135deg, #F97316 0%, #FB923C 100%)",
            color: "#FFFFFF",
            glow: "0 0 15px rgba(249, 115, 22, 0.5)",
            haloColor: "#F97316",
            tailColor: "#F97316"
        },
        revelation: {
            background: "linear-gradient(135deg, #EF4444 0%, #F87171 100%)",
            color: "#FFFFFF",
            glow: "0 0 15px rgba(239, 68, 68, 0.5)",
            haloColor: "#EF4444",
            tailColor: "#EF4444"
        },
        introspection: {
            background: "linear-gradient(135deg, #EAB308 0%, #FCD34D 100%)",
            color: "#000000",
            glow: "0 0 15px rgba(234, 179, 8, 0.5)",
            haloColor: "#EAB308",
            tailColor: "#EAB308"
        },
        humor: {
            background: "linear-gradient(135deg, #22C55E 0%, #4ADE80 100%)",
            color: "#FFFFFF",
            glow: "0 0 15px rgba(34, 197, 94, 0.5)",
            haloColor: "#22C55E",
            tailColor: "#22C55E"
        }
    };
    const style = isAssistant && messageType !== "normal" ? messageStyles[messageType] : messageStyles.normal;
    if (isAssistant && messageType !== "normal") {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
            className: "flex w-full justify-start",
            initial: {
                opacity: 0,
                y: 10,
                scale: 0.95
            },
            animate: {
                opacity: 1,
                y: 0,
                scale: 1
            },
            transition: {
                duration: 0.5,
                delay,
                type: "spring",
                stiffness: 200,
                damping: 20
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                        className: "absolute inset-0 -z-10 blur-xl",
                        animate: {
                            opacity: [
                                0.4,
                                0.6,
                                0.4
                            ],
                            scale: [
                                1,
                                1.15,
                                1
                            ]
                        },
                        transition: {
                            duration: 2.5,
                            repeat: Number.POSITIVE_INFINITY,
                            ease: "easeInOut"
                        },
                        style: {
                            background: `radial-gradient(circle, ${style.haloColor}50 0%, transparent 70%)`
                        }
                    }, void 0, false, {
                        fileName: "[project]/components/chat-message.tsx",
                        lineNumber: 92,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                        className: "relative max-w-[80%] rounded-3xl px-4 py-2 text-pretty before:absolute before:bottom-2 before:left-[-8px] before:h-0 before:w-0 before:border-b-[12px] before:border-r-[12px] before:border-solid before:border-b-transparent before:border-l-transparent before:border-r-[var(--tail-color)] before:border-t-transparent before:content-['']",
                        style: {
                            background: style.background,
                            color: style.color,
                            fontSize: "17px",
                            lineHeight: "22px",
                            boxShadow: style.glow,
                            // @ts-ignore
                            "--tail-color": style.tailColor
                        },
                        whileHover: {
                            scale: 1.02
                        },
                        transition: {
                            type: "spring",
                            stiffness: 300
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: text
                        }, void 0, false, {
                            fileName: "[project]/components/chat-message.tsx",
                            lineNumber: 121,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/chat-message.tsx",
                        lineNumber: 107,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/chat-message.tsx",
                lineNumber: 90,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/chat-message.tsx",
            lineNumber: 78,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("flex w-full flex-col", isAssistant ? "items-start" : "items-end"),
        initial: {
            opacity: 0,
            y: 10
        },
        animate: {
            opacity: 1,
            y: 0
        },
        transition: {
            duration: 0.3,
            delay,
            type: "spring",
            stiffness: 260,
            damping: 20
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("max-w-[80%] rounded-3xl px-4 py-2 text-pretty", isAssistant ? "imessage-bubble-assistant" : "imessage-bubble-user"),
                style: {
                    fontSize: "17px",
                    lineHeight: "22px"
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: text
                }, void 0, false, {
                    fileName: "[project]/components/chat-message.tsx",
                    lineNumber: 151,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/chat-message.tsx",
                lineNumber: 141,
                columnNumber: 7
            }, this),
            !isAssistant && showReceipt && timestamp && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                className: "mt-0.5 pr-1.5 text-right",
                initial: {
                    opacity: 0,
                    y: 3
                },
                animate: {
                    opacity: [
                        0,
                        1,
                        0.7,
                        1
                    ],
                    y: 0
                },
                transition: {
                    opacity: {
                        duration: 0.6,
                        times: [
                            0,
                            0.5,
                            0.7,
                            1
                        ]
                    },
                    y: {
                        duration: 0.6
                    }
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-[12px] text-[#8E8E93]",
                    style: {
                        fontFamily: "SF Pro Text, -apple-system, system-ui, sans-serif"
                    },
                    children: [
                        "read at ",
                        timestamp
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/chat-message.tsx",
                    lineNumber: 167,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/chat-message.tsx",
                lineNumber: 155,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/chat-message.tsx",
        lineNumber: 129,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/typing-indicator.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TypingIndicator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-ssr] (ecmascript)");
"use client";
;
;
function TypingIndicator() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex justify-start",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center gap-1.5 rounded-3xl bg-[#2C2C2E] px-4 py-2.5",
            children: [
                0,
                1,
                2
            ].map((i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                    className: "h-2 w-2 rounded-full imessage-typing-dot",
                    animate: {
                        y: [
                            0,
                            -4,
                            0
                        ],
                        opacity: [
                            0.5,
                            1,
                            0.5
                        ]
                    },
                    transition: {
                        duration: 0.8,
                        repeat: Number.POSITIVE_INFINITY,
                        delay: i * 0.15,
                        ease: "easeInOut"
                    }
                }, i, false, {
                    fileName: "[project]/components/typing-indicator.tsx",
                    lineNumber: 10,
                    columnNumber: 11
                }, this))
        }, void 0, false, {
            fileName: "[project]/components/typing-indicator.tsx",
            lineNumber: 8,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/typing-indicator.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/progress-bar.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProgressBar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-ssr] (ecmascript)");
"use client";
;
;
function ProgressBar({ current, total, customProgress, phaseColor = "#0A84FF" }) {
    const percentage = customProgress !== undefined ? customProgress : current / total * 100;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full px-4 py-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-3 flex items-center justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-sm font-medium",
                    style: {
                        color: phaseColor
                    },
                    children: [
                        Math.round(percentage),
                        "%"
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/progress-bar.tsx",
                    lineNumber: 18,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/progress-bar.tsx",
                lineNumber: 17,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative h-[2px] w-full overflow-hidden rounded-full bg-white/10",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                    className: "h-full rounded-full",
                    style: {
                        backgroundColor: phaseColor,
                        boxShadow: `0 0 8px ${phaseColor}99`
                    },
                    initial: {
                        width: 0
                    },
                    animate: {
                        width: `${percentage}%`
                    },
                    transition: {
                        type: "spring",
                        stiffness: 100,
                        damping: 20,
                        mass: 0.8
                    }
                }, void 0, false, {
                    fileName: "[project]/components/progress-bar.tsx",
                    lineNumber: 23,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/progress-bar.tsx",
                lineNumber: 22,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/progress-bar.tsx",
        lineNumber: 16,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/phase-transition.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PhaseTransition
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
;
function PhaseTransition({ phase, onComplete }) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        try {
            const audio = new Audio(`/sounds/${phase.sound}`);
            audio.volume = 0.6;
            audio.play().catch(()=>{});
        } catch (e) {}
        // Play heartbeat sound
        try {
            const heartbeat = new Audio("/sounds/heartbeat.mp3");
            heartbeat.volume = 0.5;
            heartbeat.loop = true;
            heartbeat.play().catch(()=>{});
            // Stop heartbeat after transition
            setTimeout(()=>{
                heartbeat.pause();
                heartbeat.currentTime = 0;
            }, 9000);
        } catch (e) {}
        // Long vibration
        if (typeof navigator !== "undefined" && navigator.vibrate) {
            navigator.vibrate(150);
        }
        const timer = setTimeout(()=>{
            onComplete();
        }, 9000);
        return ()=>clearTimeout(timer);
    }, [
        phase,
        onComplete
    ]);
    const confettiColors = [
        "#0A84FF",
        "#7C3AED",
        "#EC4899",
        "#F97316",
        "#22C55E",
        "#FFD60A",
        "#06B6D4",
        "#DC2626"
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        transition: {
            duration: 1
        },
        className: "fixed inset-0 z-50 flex items-center justify-center",
        style: {
            backgroundColor: "#000000"
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                className: "absolute inset-0",
                animate: {
                    background: `radial-gradient(circle at 50% 50%, ${phase.color}60 0%, ${phase.color}20 40%, transparent 70%)`,
                    scale: [
                        1,
                        1.05,
                        1,
                        1.08,
                        1
                    ]
                },
                transition: {
                    duration: 1.2,
                    repeat: Number.POSITIVE_INFINITY,
                    ease: [
                        0.4,
                        0,
                        0.6,
                        1
                    ],
                    times: [
                        0,
                        0.2,
                        0.4,
                        0.6,
                        1
                    ]
                },
                style: {
                    filter: "blur(120px)"
                }
            }, void 0, false, {
                fileName: "[project]/components/phase-transition.tsx",
                lineNumber: 71,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 overflow-hidden",
                children: Array.from({
                    length: 25
                }).map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                        className: "absolute rounded-full",
                        style: {
                            backgroundColor: confettiColors[Math.floor(Math.random() * confettiColors.length)],
                            width: Math.random() * 8 + 4,
                            height: Math.random() * 8 + 4,
                            left: `${Math.random() * 100}%`,
                            bottom: "-5%",
                            opacity: 0.6
                        },
                        animate: {
                            y: [
                                0,
                                -window.innerHeight - 100
                            ],
                            opacity: [
                                0,
                                0.8,
                                0
                            ],
                            scale: [
                                0.5,
                                1,
                                0.5
                            ]
                        },
                        transition: {
                            duration: 4 + Math.random() * 3,
                            delay: Math.random() * 2,
                            ease: "easeOut"
                        }
                    }, i, false, {
                        fileName: "[project]/components/phase-transition.tsx",
                        lineNumber: 91,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/phase-transition.tsx",
                lineNumber: 89,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                className: "relative z-10 mx-4 max-w-lg text-center",
                initial: {
                    scale: 0.9,
                    opacity: 0
                },
                animate: {
                    scale: [
                        1,
                        1.02,
                        1,
                        1.03,
                        1
                    ],
                    opacity: 1
                },
                transition: {
                    scale: {
                        duration: 1.2,
                        repeat: Number.POSITIVE_INFINITY,
                        ease: [
                            0.4,
                            0,
                            0.6,
                            1
                        ],
                        times: [
                            0,
                            0.2,
                            0.4,
                            0.6,
                            1
                        ]
                    },
                    opacity: {
                        duration: 1.2,
                        delay: 0.3,
                        ease: "easeOut"
                    }
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                        className: "mb-6 text-sm font-medium uppercase tracking-wider",
                        style: {
                            color: phase.color
                        },
                        initial: {
                            opacity: 0,
                            y: 20
                        },
                        animate: {
                            opacity: 1,
                            y: 0
                        },
                        transition: {
                            delay: 0.5,
                            duration: 0.8
                        },
                        children: [
                            "Phase ",
                            phase.id
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/phase-transition.tsx",
                        lineNumber: 139,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].h1, {
                        className: "mb-4 text-balance font-rounded text-2xl font-bold leading-tight text-white",
                        initial: {
                            opacity: 0,
                            y: 20
                        },
                        animate: {
                            opacity: 1,
                            y: 0
                        },
                        transition: {
                            delay: 0.8,
                            duration: 0.8
                        },
                        children: phase.text
                    }, void 0, false, {
                        fileName: "[project]/components/phase-transition.tsx",
                        lineNumber: 150,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].p, {
                        className: "text-base font-medium text-white/60",
                        initial: {
                            opacity: 0,
                            y: 20
                        },
                        animate: {
                            opacity: 1,
                            y: 0
                        },
                        transition: {
                            delay: 1.1,
                            duration: 0.8
                        },
                        children: phase.name
                    }, void 0, false, {
                        fileName: "[project]/components/phase-transition.tsx",
                        lineNumber: 160,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                        className: "mx-auto mt-8 h-px w-24",
                        style: {
                            background: `linear-gradient(90deg, transparent, ${phase.color}, transparent)`,
                            boxShadow: `0 0 20px ${phase.color}`
                        },
                        initial: {
                            opacity: 0,
                            scaleX: 0
                        },
                        animate: {
                            opacity: 1,
                            scaleX: 1
                        },
                        transition: {
                            delay: 1.4,
                            duration: 1
                        }
                    }, void 0, false, {
                        fileName: "[project]/components/phase-transition.tsx",
                        lineNumber: 170,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/phase-transition.tsx",
                lineNumber: 117,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/phase-transition.tsx",
        lineNumber: 63,
        columnNumber: 5
    }, this);
}
}),
"[project]/lib/phases/phase1.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "phase1",
    ()=>phase1
]);
const phase1 = {
    id: 1,
    title: "The Mask",
    category: "Ego",
    energyType: "Mind",
    color: "#94A3B8",
    intro: "🕯️ Every being wears a mask. Yours is starting to slip. Answer without thinking — the first emotion is always the truest.",
    questions: [
        {
            id: 1,
            text: "When someone sincerely compliments you, {name}... how do you really feel?",
            provocativeComment: "Most people lie at this question. Not you, I hope?",
            options: [
                {
                    label: "😐 You smile but want to disappear.",
                    value: 0,
                    feedback: "You still doubt your own light."
                },
                {
                    label: "🙂 You say thank you, but you doubt it.",
                    value: 1,
                    feedback: "You want to be perfect, not just appreciated."
                },
                {
                    label: "😄 You shine and own it.",
                    value: 3,
                    feedback: "You accept recognition without guilt."
                },
                {
                    label: "🧊 You change the subject.",
                    value: -1,
                    feedback: "You avoid the spotlight to avoid burning."
                }
            ]
        },
        {
            id: 2,
            text: "When you accomplish something important…",
            options: [
                {
                    label: "🎭 You downplay it so you don't disturb anyone.",
                    value: 0,
                    feedback: "You hide behind humility to stay safe."
                },
                {
                    label: "⚡ You immediately seek the next challenge.",
                    value: 2,
                    feedback: "Action soothes you more than victory."
                },
                {
                    label: "🌟 You openly share your joy.",
                    value: 3,
                    feedback: "You vibrate through expression, not fear."
                },
                {
                    label: "🤫 You'd rather no one knew.",
                    value: -1,
                    feedback: "You fear envy more than invisibility."
                }
            ]
        },
        {
            id: 3,
            text: "If someone criticizes you publicly, {name}…",
            provocativeComment: "This one reveals everything. Watch yourself.",
            options: [
                {
                    label: "🔥 You boil inside but stay composed.",
                    value: 0,
                    feedback: "You turn pain into control."
                },
                {
                    label: "💬 You respond calmly.",
                    value: 3,
                    feedback: "You've learned to separate your being from opinions."
                },
                {
                    label: "🧍 You stay silent but replay it later.",
                    value: 1,
                    feedback: "You hold back to preserve your image."
                },
                {
                    label: "🧊 You cut ties and move on.",
                    value: 2,
                    feedback: "You protect your energy, not your ego."
                }
            ]
        },
        {
            id: 4,
            text: "You walk into a room full of strangers:",
            options: [
                {
                    label: "😶 You fade into the background and observe.",
                    value: 0,
                    feedback: "The world feels hostile, so you choose silence."
                },
                {
                    label: "😏 You analyze who stands out the most.",
                    value: 1,
                    feedback: "Your gaze seeks social reference points."
                },
                {
                    label: "😃 You start conversations naturally.",
                    value: 3,
                    feedback: "You no longer need a mask to exist."
                },
                {
                    label: "🧠 You think about how others see you.",
                    value: 1,
                    feedback: "Self-awareness becomes your cage."
                }
            ]
        },
        {
            id: 5,
            text: "When you look at yourself in the mirror, {name}:",
            options: [
                {
                    label: "👀 You hunt for flaws.",
                    value: 0,
                    feedback: "You search for errors instead of truth."
                },
                {
                    label: "💡 You see the version you want to become.",
                    value: 2,
                    feedback: "Your ideal inspires you — but also judges you."
                },
                {
                    label: "😎 You accept yourself as you are.",
                    value: 3,
                    feedback: "Acceptance has made you free."
                },
                {
                    label: "🩶 You look without really seeing.",
                    value: -1,
                    feedback: "The reflection has become armor."
                }
            ]
        },
        {
            id: 6,
            text: "You prefer to be seen as:",
            options: [
                {
                    label: "🧱 Strong and reliable.",
                    value: 2,
                    feedback: "You wear strength as a duty."
                },
                {
                    label: "⚡ Brilliant and unique.",
                    value: 1,
                    feedback: "Your identity depends on standing out."
                },
                {
                    label: "💎 Gentle and reassuring.",
                    value: 3,
                    feedback: "Your sincerity has become your power."
                },
                {
                    label: "🕶️ Mysterious and unpredictable.",
                    value: 0,
                    feedback: "You hide fear behind mystery."
                }
            ]
        },
        {
            id: 7,
            text: "When you're alone for too long…",
            provocativeComment: "Interesting choice...",
            options: [
                {
                    label: "🌫️ You feel useless.",
                    value: 0,
                    feedback: "Silence confronts you with your inner void."
                },
                {
                    label: "🌿 You recharge in solitude.",
                    value: 3,
                    feedback: "Solitude feeds you — it's no longer a threat."
                },
                {
                    label: "🔄 You start planning your next goals.",
                    value: 2,
                    feedback: "Your mind constantly searches for purpose."
                },
                {
                    label: "🔥 You escape boredom by planning ahead.",
                    value: 1,
                    feedback: "You fill the void with control."
                }
            ]
        },
        {
            id: 8,
            text: "When you meet someone more 'successful' than you, {name}:",
            options: [
                {
                    label: "⚔️ You feel a touch of jealousy.",
                    value: 1,
                    feedback: "Comparison gives you a sense of identity."
                },
                {
                    label: "🧠 You analyze how they did it.",
                    value: 2,
                    feedback: "Your awareness protects you from resentment."
                },
                {
                    label: "💬 You sincerely congratulate them.",
                    value: 3,
                    feedback: "You honor others without shrinking yourself."
                },
                {
                    label: "🕳️ You feel smaller inside.",
                    value: 0,
                    feedback: "Doubt still rules your reflection."
                }
            ]
        },
        {
            id: 9,
            text: "When someone dislikes you…",
            options: [
                {
                    label: "🧊 You distance yourself immediately.",
                    value: 2,
                    feedback: "You choose peace over validation."
                },
                {
                    label: "😈 You want to prove them wrong.",
                    value: 1,
                    feedback: "Revenge gives you a sense of control."
                },
                {
                    label: "🤷 You truly don't care.",
                    value: 3,
                    feedback: "Authentic indifference — rare and solid."
                },
                {
                    label: "🧠 You wonder what you did wrong.",
                    value: 0,
                    feedback: "You turn rejection into self-blame."
                }
            ]
        },
        {
            id: 10,
            text: "If LifeClock could show you your true inner face, {name}... would you want to see it?",
            provocativeComment: "Take your time. This question counts.",
            options: [
                {
                    label: "😨 No, I'm afraid of what I'd see.",
                    value: 0,
                    feedback: "Truth still terrifies you."
                },
                {
                    label: "🕯️ Yes, but slowly.",
                    value: 1,
                    feedback: "You open the door carefully."
                },
                {
                    label: "⚡ Yes, even if it burns.",
                    value: 3,
                    feedback: "You prefer light over illusion."
                },
                {
                    label: "😐 I don't believe in a 'true self'.",
                    value: -1,
                    feedback: "Cynicism shields your subconscious."
                }
            ]
        }
    ],
    evaluate (answers) {
        const total = answers.reduce((sum, a)=>sum + a.value, 0);
        let profile;
        if (total <= 8) {
            profile = {
                archetype: "🧊 The Fugitive",
                description: "You hide your sensitivity behind distance. The fear of judgment isolates you, but your silence is a muffled scream.",
                message: "You don't want to be seen, yet you crave to be discovered."
            };
        } else if (total <= 15) {
            profile = {
                archetype: "🎭 The Strategist",
                description: "You control your image with precision. You want love without dependence, admiration without exposure.",
                message: "You mastered your mask — but now it masters you."
            };
        } else if (total <= 22) {
            profile = {
                archetype: "🔮 The Chameleon",
                description: "You adapt your face to the world — sincere, but unstable. Your authenticity shifts with the light.",
                message: "You change colors to be loved. The real you is waiting."
            };
        } else {
            profile = {
                archetype: "🌞 The Transparent",
                description: "You embrace your truth without fear. Your vulnerability has become your strength.",
                message: "Your mask has melted. You've started to breathe again."
            };
        }
        return {
            total,
            ...profile
        };
    },
    globalFeedback (total) {
        if (total < 10) return "🕯️ Your mask remains cold. Fear still protects you.";
        if (total < 20) return "⚡ A crack appears. You're beginning to let yourself be seen.";
        return "🌞 The mirror welcomes you. You no longer need to hide.";
    }
};
}),
"[project]/lib/phases/phase2.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "phase2",
    ()=>phase2
]);
const phase2 = {
    id: 2,
    title: "The Control",
    category: "Fear",
    energyType: "Mind",
    color: "#3B82F6",
    intro: "⏳ Control feels safe, but safety often costs your freedom. Answer instinctively — where does your control begin, and where does it end?",
    questions: [
        {
            id: 1,
            text: "When plans suddenly change, {name}…",
            provocativeComment: "You can lie to me. But can you lie to yourself?",
            options: [
                {
                    label: "😤 You panic and try to restore order.",
                    value: 0,
                    feedback: "You equate chaos with danger."
                },
                {
                    label: "🧠 You quickly rebuild a new plan.",
                    value: 2,
                    feedback: "Flexibility keeps your power intact."
                },
                {
                    label: "😐 You adapt and move on.",
                    value: 3,
                    feedback: "You've learned to surf uncertainty."
                },
                {
                    label: "🤷 You freeze and wait for others to decide.",
                    value: 1,
                    feedback: "Indecision disguises hidden control — waiting for the world to act for you."
                }
            ]
        },
        {
            id: 2,
            text: "You realize something went wrong because of you.",
            options: [
                {
                    label: "💥 You obsess over every detail.",
                    value: 0,
                    feedback: "Perfectionism is your punishment ritual."
                },
                {
                    label: "🧩 You analyze, learn, and move on.",
                    value: 3,
                    feedback: "You transform guilt into mastery."
                },
                {
                    label: "😔 You blame yourself quietly.",
                    value: 1,
                    feedback: "Responsibility without compassion breeds exhaustion."
                },
                {
                    label: "😎 You pretend it never happened.",
                    value: -1,
                    feedback: "Denial keeps your illusion of control alive."
                }
            ]
        },
        {
            id: 3,
            text: "When someone does things differently from you, {name}…",
            provocativeComment: "This answer says more about you than them.",
            options: [
                {
                    label: "🔥 You correct them immediately.",
                    value: 0,
                    feedback: "You control to feel safe, not efficient."
                },
                {
                    label: "🧘 You let them try and learn.",
                    value: 3,
                    feedback: "True control is trusting the process."
                },
                {
                    label: "🤔 You compare silently.",
                    value: 1,
                    feedback: "Judgment is your quiet weapon."
                },
                {
                    label: "😅 You intervene later with advice.",
                    value: 2,
                    feedback: "You disguise control as guidance."
                }
            ]
        },
        {
            id: 4,
            text: "When the outcome is uncertain…",
            options: [
                {
                    label: "😬 You imagine every worst scenario.",
                    value: 0,
                    feedback: "Fear is your way of feeling prepared."
                },
                {
                    label: "🧭 You act anyway, uncertainty excites you.",
                    value: 3,
                    feedback: "You trust momentum more than safety."
                },
                {
                    label: "💭 You wait for a 'sign' before moving.",
                    value: 1,
                    feedback: "You hand your power to the invisible."
                },
                {
                    label: "📋 You double-check every variable.",
                    value: 2,
                    feedback: "Logic gives you the illusion of control."
                }
            ]
        },
        {
            id: 5,
            text: "If someone takes control in your place, {name}…",
            options: [
                {
                    label: "😡 You resist immediately.",
                    value: 0,
                    feedback: "Dominance feels like survival."
                },
                {
                    label: "🧩 You observe how they handle it.",
                    value: 2,
                    feedback: "You learn by letting go — a rare skill."
                },
                {
                    label: "😶 You withdraw silently.",
                    value: 1,
                    feedback: "Retreat is your subtle rebellion."
                },
                {
                    label: "🙏 You feel relieved.",
                    value: 3,
                    feedback: "You no longer need to rule everything to feel valuable."
                }
            ]
        },
        {
            id: 6,
            text: "When you can't predict the future…",
            provocativeComment: "You're answering fast. Too fast. Are you really thinking?",
            options: [
                {
                    label: "🕰️ You plan obsessively.",
                    value: 0,
                    feedback: "Preparation has replaced faith."
                },
                {
                    label: "🌊 You surrender to what comes.",
                    value: 3,
                    feedback: "Flow replaces fear — control evolves into presence."
                },
                {
                    label: "📅 You make a backup plan, just in case.",
                    value: 2,
                    feedback: "You mix logic with intuition — balanced control."
                },
                {
                    label: "😐 You ignore it until it's too late.",
                    value: -1,
                    feedback: "Avoidance is inverted control."
                }
            ]
        },
        {
            id: 7,
            text: "How do you feel when someone else drives the car?",
            options: [
                {
                    label: "😬 I want to grab the wheel.",
                    value: 0,
                    feedback: "Trust is your hardest test."
                },
                {
                    label: "😅 I watch the road and breathe.",
                    value: 1,
                    feedback: "Your vigilance never sleeps."
                },
                {
                    label: "😎 I relax, music on.",
                    value: 3,
                    feedback: "Letting go feels like freedom now."
                },
                {
                    label: "😐 I close my eyes and endure it.",
                    value: 2,
                    feedback: "You fake surrender, but still calculate."
                }
            ]
        },
        {
            id: 8,
            text: "When things go better than expected, {name}…",
            options: [
                {
                    label: "🤨 You worry it won't last.",
                    value: 0,
                    feedback: "Your mind mistrusts peace."
                },
                {
                    label: "😊 You enjoy it fully.",
                    value: 3,
                    feedback: "You allow happiness without control."
                },
                {
                    label: "🧠 You immediately plan to sustain it.",
                    value: 2,
                    feedback: "Even joy becomes a project."
                },
                {
                    label: "😐 You feel strangely empty.",
                    value: 1,
                    feedback: "Control fed you — calm leaves a void."
                }
            ]
        },
        {
            id: 9,
            text: "If someone surprises you emotionally…",
            options: [
                {
                    label: "😶 You freeze, unsure what to do.",
                    value: 1,
                    feedback: "Emotion without control feels like chaos."
                },
                {
                    label: "💬 You express your surprise honestly.",
                    value: 3,
                    feedback: "You welcome spontaneity as truth."
                },
                {
                    label: "😏 You act like you expected it.",
                    value: 0,
                    feedback: "Image over authenticity — the strategist returns."
                },
                {
                    label: "🧠 You analyze the reason behind it.",
                    value: 2,
                    feedback: "Understanding gives you safety."
                }
            ]
        },
        {
            id: 10,
            text: "What scares you the most, {name}?",
            provocativeComment: "Be honest. The truth is waiting.",
            options: [
                {
                    label: "💀 Losing control of yourself.",
                    value: 0,
                    feedback: "Your power depends on resistance."
                },
                {
                    label: "🌫️ Not knowing what comes next.",
                    value: 1,
                    feedback: "Uncertainty still whispers fear."
                },
                {
                    label: "🕊️ Letting go and trusting life.",
                    value: 2,
                    feedback: "Surrender feels both terrifying and sacred."
                },
                {
                    label: "🔥 Realizing you were never in control.",
                    value: 3,
                    feedback: "That truth could finally set you free."
                }
            ]
        }
    ],
    evaluate (answers) {
        const total = answers.reduce((sum, a)=>sum + a.value, 0);
        let profile;
        if (total <= 8) {
            profile = {
                archetype: "🧩 The Controller",
                description: "You grip reality with both hands. Control protects you from chaos, but also from growth.",
                message: "You mistake safety for mastery. The tighter you hold, the less you feel."
            };
        } else if (total <= 15) {
            profile = {
                archetype: "⚙️ The Planner",
                description: "You seek stability through structure. Predictability comforts you, but sometimes cages you.",
                message: "You manage well, but you rarely flow."
            };
        } else if (total <= 22) {
            profile = {
                archetype: "🌬️ The Balancer",
                description: "You dance between order and surrender. You control when needed, release when wise.",
                message: "You bend, so you never break."
            };
        } else {
            profile = {
                archetype: "🌊 The Flow-Master",
                description: "You've transcended control. You act from trust, not fear. The universe moves through you.",
                message: "You don't control the tide — you surf it."
            };
        }
        return {
            total,
            ...profile
        };
    },
    globalFeedback (total) {
        if (total < 10) return "🕰️ Your grip is iron — but even iron rusts. Let the current move once.";
        if (total < 20) return "⚡ You're learning to balance control and faith.";
        return "🌊 You've found flow. Control has become clarity.";
    }
};
}),
"[project]/lib/phases/phase3.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "phase3",
    ()=>phase3
]);
const phase3 = {
    id: 3,
    title: "The Desire",
    category: "Fire",
    energyType: "Drive",
    color: "#EF4444",
    intro: "🔥 Desire is not weakness — it's direction. But only if you learn to ride it, not drown in it. Answer with honesty — what truly pulls your strings?",
    questions: [
        {
            id: 1,
            text: "When you want something deeply…",
            options: [
                {
                    label: "🔥 You can't think about anything else.",
                    value: 0,
                    feedback: "Obsession gives you focus — and blindness."
                },
                {
                    label: "🌪️ You plan how to get it step by step.",
                    value: 2,
                    feedback: "You channel fire into precision — dangerous and powerful."
                },
                {
                    label: "💬 You talk about it until it feels real.",
                    value: 1,
                    feedback: "Desire becomes your story before your reality."
                },
                {
                    label: "🌊 You let it come naturally if it's meant for you.",
                    value: 3,
                    feedback: "You no longer chase — you attract."
                }
            ]
        },
        {
            id: 2,
            text: "When you see someone living your dream…",
            options: [
                {
                    label: "😠 You feel envy and pressure.",
                    value: 0,
                    feedback: "You confuse inspiration with comparison."
                },
                {
                    label: "🧠 You study how they did it.",
                    value: 2,
                    feedback: "You turn jealousy into fuel — wisdom through imitation."
                },
                {
                    label: "💬 You celebrate them genuinely.",
                    value: 3,
                    feedback: "You understand abundance is not a zero-sum game."
                },
                {
                    label: "😐 You feel distant and detached.",
                    value: 1,
                    feedback: "You protect yourself from longing by numbing it."
                }
            ]
        },
        {
            id: 3,
            text: "When you get what you wanted…",
            options: [
                {
                    label: "😶 You feel empty again.",
                    value: 0,
                    feedback: "You crave the chase, not the prize."
                },
                {
                    label: "💫 You enjoy it and then evolve.",
                    value: 3,
                    feedback: "You turn desire into growth — mastery in motion."
                },
                {
                    label: "🔄 You immediately want something bigger.",
                    value: 1,
                    feedback: "Hunger keeps you alive, but restless."
                },
                {
                    label: "🧘 You slow down to appreciate it deeply.",
                    value: 2,
                    feedback: "You've learned that gratitude feeds desire, not kills it."
                }
            ]
        },
        {
            id: 4,
            text: "If love and ambition collided, you would…",
            options: [
                {
                    label: "🔥 Choose ambition — love can wait.",
                    value: 0,
                    feedback: "Your fire consumes connection."
                },
                {
                    label: "🌹 Choose love — success means nothing without it.",
                    value: 2,
                    feedback: "Your heart leads, even when it hurts."
                },
                {
                    label: "⚖️ Try to balance both, even if it kills you.",
                    value: 3,
                    feedback: "You chase harmony inside the storm."
                },
                {
                    label: "🧊 Avoid both — too risky to lose control.",
                    value: 1,
                    feedback: "Fear disguises itself as logic."
                }
            ]
        },
        {
            id: 5,
            text: "What drives you the most?",
            options: [
                {
                    label: "💰 Recognition and wealth.",
                    value: 1,
                    feedback: "You measure worth through mirrors and numbers."
                },
                {
                    label: "🔥 The thrill of achieving what few dare.",
                    value: 2,
                    feedback: "You crave the impossible — it's your element."
                },
                {
                    label: "💡 The need to create something meaningful.",
                    value: 3,
                    feedback: "You are driven by purpose, not applause."
                },
                {
                    label: "😐 Avoiding failure at all costs.",
                    value: 0,
                    feedback: "Fear is your hidden fuel."
                }
            ]
        },
        {
            id: 6,
            text: "When desire becomes overwhelming…",
            options: [
                {
                    label: "🧊 You suppress it completely.",
                    value: 0,
                    feedback: "Control kills your vitality."
                },
                {
                    label: "🔥 You act impulsively.",
                    value: 1,
                    feedback: "You feed the flame faster than you can direct it."
                },
                {
                    label: "🧘 You observe it until it fades or transforms.",
                    value: 3,
                    feedback: "You've mastered the fire instead of fearing it."
                },
                {
                    label: "💬 You rationalize it away.",
                    value: 2,
                    feedback: "Your mind negotiates with your instincts."
                }
            ]
        },
        {
            id: 7,
            text: "If success meant losing some people in your life…",
            options: [
                {
                    label: "💀 I'd still go all in.",
                    value: 2,
                    feedback: "You burn bridges to build kingdoms."
                },
                {
                    label: "💔 I'd hesitate — I value connection too much.",
                    value: 1,
                    feedback: "Your heart negotiates with your ambition."
                },
                {
                    label: "🧠 I'd find a way to have both.",
                    value: 3,
                    feedback: "You seek evolution without destruction — rare wisdom."
                },
                {
                    label: "😐 I'd rather stay comfortable.",
                    value: 0,
                    feedback: "You trade destiny for peace."
                }
            ]
        },
        {
            id: 8,
            text: "How do you react to delayed gratification?",
            options: [
                {
                    label: "🔥 I hate waiting — I need it now.",
                    value: 0,
                    feedback: "Patience feels like punishment."
                },
                {
                    label: "🧠 I distract myself by working harder.",
                    value: 2,
                    feedback: "You weaponize time to stay in control."
                },
                {
                    label: "🕰️ I trust that what's meant will come.",
                    value: 3,
                    feedback: "You've aligned with the rhythm of the universe."
                },
                {
                    label: "😶 I lose motivation quickly.",
                    value: 1,
                    feedback: "Desire without direction drains you."
                }
            ]
        },
        {
            id: 9,
            text: "When you fall in love with an idea or a person…",
            options: [
                {
                    label: "💭 You idealize them until they disappoint you.",
                    value: 0,
                    feedback: "You love the reflection more than the reality."
                },
                {
                    label: "💬 You obsessively talk about them.",
                    value: 1,
                    feedback: "You verbalize passion to feel in control."
                },
                {
                    label: "🔥 You take action, no hesitation.",
                    value: 3,
                    feedback: "Desire becomes creation — pure fire."
                },
                {
                    label: "🧘 You feel deeply, but stay detached.",
                    value: 2,
                    feedback: "You've learned to love without possession."
                }
            ]
        },
        {
            id: 10,
            text: "If LifeClock could measure your fire, it would find that you…",
            options: [
                {
                    label: "🕯️ Burn for what's missing.",
                    value: 0,
                    feedback: "Desire defines your pain."
                },
                {
                    label: "⚡ Burn for what's possible.",
                    value: 2,
                    feedback: "You turn imagination into movement."
                },
                {
                    label: "🔥 Burn for everything, all at once.",
                    value: 1,
                    feedback: "Intensity gives you identity."
                },
                {
                    label: "🌞 Burn steadily — warm, not wild.",
                    value: 3,
                    feedback: "You've learned that true fire doesn't consume — it sustains."
                }
            ]
        }
    ],
    evaluate (answers) {
        const total = answers.reduce((sum, a)=>sum + a.value, 0);
        let profile;
        if (total <= 8) {
            profile = {
                archetype: "🔥 The Addict of Fire",
                description: "Desire rules you. You chase the high, not the truth. Your hunger creates progress — and chaos.",
                message: "You don't love what you want. You love the wanting itself."
            };
        } else if (total <= 15) {
            profile = {
                archetype: "💭 The Dream-Chaser",
                description: "You live through visions and emotion. Desire motivates you, but sometimes blinds you.",
                message: "You chase horizons, but forget the ground beneath you."
            };
        } else if (total <= 22) {
            profile = {
                archetype: "⚡ The Alchemist",
                description: "You transform desire into creation. You know how to balance passion with intention.",
                message: "Your fire builds — it no longer burns."
            };
        } else {
            profile = {
                archetype: "🌞 The Embodied Flame",
                description: "You've merged hunger with peace. Your desire doesn't control you — it guides you.",
                message: "You are desire without desperation."
            };
        }
        return {
            total,
            ...profile
        };
    },
    globalFeedback (total) {
        if (total < 10) return "🔥 You burn fast and bright — but the light fades quickly. Learn to breathe inside your fire.";
        if (total < 20) return "⚡ Desire drives you. Balance it with patience, and it becomes power.";
        return "🌞 Your fire is steady — creation without destruction.";
    }
};
}),
"[project]/lib/phases/phase4.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "phase4",
    ()=>phase4
]);
const phase4 = {
    id: 4,
    title: "Love",
    category: "Heart",
    energyType: "Heart",
    color: "#EC4899",
    intro: "💓 Love is the most powerful force — and the most misunderstood. Let's see not who you love… but how you love.",
    questions: [
        {
            id: 1,
            text: "When someone truly loves you, how do you react?",
            options: [
                {
                    label: "😨 You pull away — it feels dangerous.",
                    value: 0,
                    feedback: "You mistake love for risk."
                },
                {
                    label: "🙂 You accept it, but quietly doubt it.",
                    value: 1,
                    feedback: "You crave love but question its permanence."
                },
                {
                    label: "💫 You open up fully.",
                    value: 3,
                    feedback: "You understand that love expands when shared."
                },
                {
                    label: "😐 You act like it's nothing special.",
                    value: 2,
                    feedback: "You protect your heart by pretending it's normal."
                }
            ]
        },
        {
            id: 2,
            text: "When you love someone deeply…",
            options: [
                {
                    label: "🔥 You give everything — even too much.",
                    value: 0,
                    feedback: "You confuse love with self-erasure."
                },
                {
                    label: "⚖️ You give and receive equally.",
                    value: 3,
                    feedback: "You've found the art of reciprocal love."
                },
                {
                    label: "🧊 You give slowly, waiting to be sure.",
                    value: 2,
                    feedback: "You love with calculation, not fear."
                },
                {
                    label: "💭 You think more than you feel.",
                    value: 1,
                    feedback: "Your mind supervises your heart."
                }
            ]
        },
        {
            id: 3,
            text: "If you feel rejected by someone you love…",
            options: [
                {
                    label: "💔 You chase them even harder.",
                    value: 0,
                    feedback: "You turn pain into pursuit."
                },
                {
                    label: "🧘 You accept it and let go.",
                    value: 3,
                    feedback: "You choose peace over possession."
                },
                {
                    label: "🧠 You try to understand what went wrong.",
                    value: 2,
                    feedback: "Reason replaces resentment — healing through clarity."
                },
                {
                    label: "🧊 You pretend not to care.",
                    value: 1,
                    feedback: "Your armor hides your wound."
                }
            ]
        },
        {
            id: 4,
            text: "When someone doesn't meet your expectations…",
            options: [
                {
                    label: "😡 You feel betrayed.",
                    value: 0,
                    feedback: "You confuse love with loyalty to your script."
                },
                {
                    label: "💬 You communicate honestly.",
                    value: 3,
                    feedback: "Love matures through truth, not guessing."
                },
                {
                    label: "😐 You withdraw and go silent.",
                    value: 1,
                    feedback: "Your silence becomes your shield."
                },
                {
                    label: "🤝 You adjust and understand.",
                    value: 2,
                    feedback: "You let compassion override ego."
                }
            ]
        },
        {
            id: 5,
            text: "In a relationship, you fear most:",
            options: [
                {
                    label: "💀 Being abandoned.",
                    value: 0,
                    feedback: "Fear of loss runs deeper than love itself."
                },
                {
                    label: "😶 Losing yourself.",
                    value: 2,
                    feedback: "You protect your identity inside connection."
                },
                {
                    label: "💔 Being misunderstood.",
                    value: 1,
                    feedback: "You crave emotional precision, not just affection."
                },
                {
                    label: "🌿 Becoming too comfortable.",
                    value: 3,
                    feedback: "You know comfort kills fire — and growth."
                }
            ]
        },
        {
            id: 6,
            text: "When you fight with someone you care about…",
            options: [
                {
                    label: "🔥 You explode, then regret it.",
                    value: 0,
                    feedback: "Anger masks your fear of rejection."
                },
                {
                    label: "🧊 You shut down until things cool off.",
                    value: 1,
                    feedback: "Distance feels safer than confrontation."
                },
                {
                    label: "💬 You talk it through quickly.",
                    value: 3,
                    feedback: "You value connection over being right."
                },
                {
                    label: "🧠 You analyze every word later.",
                    value: 2,
                    feedback: "Reflection saves you — but delays healing."
                }
            ]
        },
        {
            id: 7,
            text: "When you see affection between others, you…",
            options: [
                {
                    label: "💔 Feel left out.",
                    value: 0,
                    feedback: "You measure love as scarcity."
                },
                {
                    label: "😊 Feel warm and inspired.",
                    value: 3,
                    feedback: "Love multiplies in your presence."
                },
                {
                    label: "😐 Feel nothing special.",
                    value: 1,
                    feedback: "You keep your emotions neutral to stay safe."
                },
                {
                    label: "🧠 Compare it to your own experiences.",
                    value: 2,
                    feedback: "You intellectualize what others feel."
                }
            ]
        },
        {
            id: 8,
            text: "Do you believe love should be easy?",
            options: [
                {
                    label: "💤 Yes — if it's hard, it's wrong.",
                    value: 0,
                    feedback: "You confuse peace with absence of growth."
                },
                {
                    label: "⚡ No — real love demands effort.",
                    value: 3,
                    feedback: "You embrace the labor of intimacy."
                },
                {
                    label: "🧘 Sometimes — but not forced.",
                    value: 2,
                    feedback: "You balance harmony with honesty."
                },
                {
                    label: "🤷 I don't really believe in 'love' anymore.",
                    value: 1,
                    feedback: "Disappointment disguised as wisdom."
                }
            ]
        },
        {
            id: 9,
            text: "When you love, what's your hidden expectation?",
            options: [
                {
                    label: "❤️ To be saved.",
                    value: 0,
                    feedback: "You want love to fix what's broken inside."
                },
                {
                    label: "🌿 To grow together.",
                    value: 3,
                    feedback: "You see love as evolution, not rescue."
                },
                {
                    label: "✨ To feel chosen.",
                    value: 1,
                    feedback: "Validation still fuels your affection."
                },
                {
                    label: "🧘 To experience peace.",
                    value: 2,
                    feedback: "You seek stillness in shared chaos."
                }
            ]
        },
        {
            id: 10,
            text: "If LifeClock could show how you love, it would reveal that you…",
            options: [
                {
                    label: "💀 Fear love but crave it endlessly.",
                    value: 0,
                    feedback: "You orbit the flame but never touch it."
                },
                {
                    label: "💞 Love deeply but inconsistently.",
                    value: 1,
                    feedback: "Your intensity is both gift and curse."
                },
                {
                    label: "🌹 Love consciously — even when it hurts.",
                    value: 3,
                    feedback: "You know that love and pain are twins of growth."
                },
                {
                    label: "🌊 Love freely — without needing to own.",
                    value: 2,
                    feedback: "You've transcended attachment into connection."
                }
            ]
        }
    ],
    evaluate (answers) {
        const total = answers.reduce((sum, a)=>sum + a.value, 0);
        let profile;
        if (total <= 8) {
            profile = {
                archetype: "🧊 The Guarded Heart",
                description: "You fear love's unpredictability. You wear distance as armor, but longing as perfume.",
                message: "You want to be loved without being seen."
            };
        } else if (total <= 15) {
            profile = {
                archetype: "💔 The Romantic Survivor",
                description: "You've been burned and built walls. Yet beneath the ashes, your heart still glows.",
                message: "You still believe — but carefully."
            };
        } else if (total <= 22) {
            profile = {
                archetype: "🌹 The Conscious Lover",
                description: "You love with both courage and clarity. You allow others to be free while staying true to yourself.",
                message: "You know that love is not ownership — it's presence."
            };
        } else {
            profile = {
                archetype: "🌊 The Unconditional Soul",
                description: "You've merged compassion with strength. You love from wholeness, not from need.",
                message: "You no longer love to fill a void — you love to expand the world."
            };
        }
        return {
            total,
            ...profile
        };
    },
    globalFeedback (total) {
        if (total < 10) return "💔 Your heart is cautious. Let it breathe — pain is not your enemy, numbness is.";
        if (total < 20) return "🌹 You're learning to love with awareness — not fantasy.";
        return "🌊 Love flows through you — no fear, no control, only presence.";
    }
};
}),
"[project]/lib/phases/phase5.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "phase5",
    ()=>phase5
]);
const phase5 = {
    id: 5,
    title: "Time",
    category: "Mortality",
    energyType: "Spirit",
    color: "#8B5CF6",
    intro: "⏳ You don't lack time — you lack presence. Let's see how you dance with the seconds you've been given.",
    questions: [
        {
            id: 1,
            text: "When you think about your future…",
            options: [
                {
                    label: "😬 You feel anxious about wasting time.",
                    value: 1,
                    feedback: "You measure life in deadlines, not days."
                },
                {
                    label: "🧭 You plan every step carefully.",
                    value: 2,
                    feedback: "Order comforts you — but sometimes cages you."
                },
                {
                    label: "🌊 You trust life to unfold naturally.",
                    value: 3,
                    feedback: "You've begun to flow with time, not against it."
                },
                {
                    label: "😐 You avoid thinking about it.",
                    value: 0,
                    feedback: "Avoidance is fear disguised as peace."
                }
            ]
        },
        {
            id: 2,
            text: "When you're bored, what do you do?",
            options: [
                {
                    label: "📱 Scroll endlessly.",
                    value: 0,
                    feedback: "You escape time instead of feeling it."
                },
                {
                    label: "💭 Reflect or daydream.",
                    value: 2,
                    feedback: "You use emptiness as fuel for imagination."
                },
                {
                    label: "🌿 Go for a walk or breathe.",
                    value: 3,
                    feedback: "You know stillness is not waste."
                },
                {
                    label: "🧩 Start something new immediately.",
                    value: 1,
                    feedback: "You fight stillness with stimulation."
                }
            ]
        },
        {
            id: 3,
            text: "Do you often feel like you're running out of time?",
            options: [
                {
                    label: "🔥 Always. It's my biggest fear.",
                    value: 0,
                    feedback: "You chase life as if it's fleeing from you."
                },
                {
                    label: "⏳ Sometimes, but it motivates me.",
                    value: 2,
                    feedback: "Mortality sharpens your focus."
                },
                {
                    label: "🌙 Rarely — I trust my rhythm.",
                    value: 3,
                    feedback: "You've stopped racing the clock."
                },
                {
                    label: "🤷 Not really. I don't think about it.",
                    value: 1,
                    feedback: "You numb the pressure with distraction."
                }
            ]
        },
        {
            id: 4,
            text: "When you wake up in the morning…",
            options: [
                {
                    label: "😩 You dread the day ahead.",
                    value: 0,
                    feedback: "You carry yesterday's fatigue into today."
                },
                {
                    label: "🧠 You start planning immediately.",
                    value: 2,
                    feedback: "You mistake control for clarity."
                },
                {
                    label: "💫 You feel grateful and grounded.",
                    value: 3,
                    feedback: "You start your day in alignment, not anxiety."
                },
                {
                    label: "😐 You just go through motions.",
                    value: 1,
                    feedback: "Habit replaces intention — quietly stealing time."
                }
            ]
        },
        {
            id: 5,
            text: "When you look back at your past year…",
            options: [
                {
                    label: "💀 I barely remember it — it flew by.",
                    value: 0,
                    feedback: "Autopilot stole your hours."
                },
                {
                    label: "📈 I grew, even through mistakes.",
                    value: 3,
                    feedback: "You see time as teacher, not thief."
                },
                {
                    label: "🔁 It felt repetitive and dull.",
                    value: 1,
                    feedback: "You lived, but without direction."
                },
                {
                    label: "💡 It had highs and lows — both meaningful.",
                    value: 2,
                    feedback: "You honor contrast — that's wisdom."
                }
            ]
        },
        {
            id: 6,
            text: "How do you react when things take longer than expected?",
            options: [
                {
                    label: "😠 I lose patience fast.",
                    value: 0,
                    feedback: "Impatience hides fear of losing control."
                },
                {
                    label: "😐 I get frustrated but adapt.",
                    value: 1,
                    feedback: "You tolerate delay without embracing it."
                },
                {
                    label: "🧘 I trust timing — it always reveals purpose.",
                    value: 3,
                    feedback: "You've made peace with divine pacing."
                },
                {
                    label: "⚙️ I try to optimize the process.",
                    value: 2,
                    feedback: "Efficiency gives you comfort — even in waiting."
                }
            ]
        },
        {
            id: 7,
            text: "Your relationship with deadlines is…",
            options: [
                {
                    label: "🔥 Stressful — I always feel late.",
                    value: 0,
                    feedback: "Time owns you through urgency."
                },
                {
                    label: "🧠 Organized — I meet them precisely.",
                    value: 2,
                    feedback: "You use structure to control uncertainty."
                },
                {
                    label: "🌿 Balanced — I deliver without pressure.",
                    value: 3,
                    feedback: "You've turned time into an ally, not an enemy."
                },
                {
                    label: "😅 Chaotic — I work best under pressure.",
                    value: 1,
                    feedback: "You confuse adrenaline for flow."
                }
            ]
        },
        {
            id: 8,
            text: "When you have free time, you…",
            options: [
                {
                    label: "📱 Fill it immediately with tasks or screens.",
                    value: 0,
                    feedback: "You fear silence — the true mirror of time."
                },
                {
                    label: "🧘 Use it to recharge intentionally.",
                    value: 3,
                    feedback: "You rest with awareness — rare mastery."
                },
                {
                    label: "😶 Waste it, then feel guilty.",
                    value: 1,
                    feedback: "You live between doing and regretting."
                },
                {
                    label: "🌞 Let it flow without guilt or goal.",
                    value: 2,
                    feedback: "Freedom is your rhythm now."
                }
            ]
        },
        {
            id: 9,
            text: "If LifeClock showed how much time you truly *live* (not just exist), you'd see that you…",
            options: [
                {
                    label: "💀 Spend most days half-awake.",
                    value: 0,
                    feedback: "Routine has replaced wonder."
                },
                {
                    label: "💫 Are present more often than before.",
                    value: 2,
                    feedback: "Awareness is growing inside you."
                },
                {
                    label: "🌞 Live fully — every day feels intentional.",
                    value: 3,
                    feedback: "You don't count days, you fill them."
                },
                {
                    label: "😐 Don't know — time feels foggy.",
                    value: 1,
                    feedback: "Disconnection disguises itself as calm."
                }
            ]
        },
        {
            id: 10,
            text: "If time were a person standing before you right now, what would you say?",
            options: [
                {
                    label: "⏰ 'Please slow down.'",
                    value: 1,
                    feedback: "You fear the speed, not the passage."
                },
                {
                    label: "🙏 'Thank you for teaching me.'",
                    value: 3,
                    feedback: "You've made peace with impermanence."
                },
                {
                    label: "😢 'I've wasted too much of you.'",
                    value: 0,
                    feedback: "Regret is your echo of awareness."
                },
                {
                    label: "💬 'Let's create something together.'",
                    value: 2,
                    feedback: "You've turned time into partnership."
                }
            ]
        }
    ],
    evaluate (answers) {
        const total = answers.reduce((sum, a)=>sum + a.value, 0);
        let profile;
        if (total <= 8) {
            profile = {
                archetype: "⌛ The Chaser",
                description: "You run against time instead of with it. You measure worth by speed, not presence.",
                message: "You don't fear death — you fear stillness."
            };
        } else if (total <= 15) {
            profile = {
                archetype: "🕰️ The Scheduler",
                description: "You try to master time through structure. You achieve much — but forget to live between tasks.",
                message: "You plan beautifully, but rarely pause to feel it."
            };
        } else if (total <= 22) {
            profile = {
                archetype: "🌿 The Harmonizer",
                description: "You understand the rhythm of things. You work with time, not against it.",
                message: "You flow between creation and rest — that's freedom."
            };
        } else {
            profile = {
                archetype: "🌞 The Timeless Soul",
                description: "You no longer chase or count. You live from depth, not duration. Every second feels eternal.",
                message: "Time doesn't move you — you move through it."
            };
        }
        return {
            total,
            ...profile
        };
    },
    globalFeedback (total) {
        if (total < 10) return "⏳ You fight time — and it always wins. Try listening instead of running.";
        if (total < 20) return "🕰️ You're learning to trust time's intelligence.";
        return "🌞 You've transcended urgency. Time is no longer your master.";
    }
};
}),
"[project]/lib/phases/phase6.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "phase6",
    ()=>phase6
]);
const phase6 = {
    id: 6,
    title: "Money",
    category: "Material",
    energyType: "Drive",
    color: "#F59E0B",
    intro: "💸 Money reveals what you truly believe about yourself. It doesn't change you — it amplifies what's already there. Let's see what it amplifies in you.",
    questions: [
        {
            id: 1,
            text: "When you think about wealth, what comes to mind first?",
            options: [
                {
                    label: "😬 Corruption and greed.",
                    value: 0,
                    feedback: "You equate power with danger — your beliefs limit your permission to receive."
                },
                {
                    label: "💼 Stability and independence.",
                    value: 2,
                    feedback: "You see money as a foundation — not a master."
                },
                {
                    label: "🔥 Freedom and adventure.",
                    value: 3,
                    feedback: "You associate wealth with possibility, not fear."
                },
                {
                    label: "💭 Success, but for others — not me.",
                    value: 1,
                    feedback: "You still see abundance as belonging to 'them,' not 'you.'"
                }
            ]
        },
        {
            id: 2,
            text: "When you receive unexpected money…",
            options: [
                {
                    label: "😐 You feel undeserving.",
                    value: 0,
                    feedback: "You still link money to moral worth."
                },
                {
                    label: "😅 You're grateful but cautious.",
                    value: 1,
                    feedback: "You enjoy abundance, but with suspicion."
                },
                {
                    label: "💫 You celebrate openly.",
                    value: 3,
                    feedback: "You let gratitude expand what arrives."
                },
                {
                    label: "🧠 You instantly plan how to use or invest it.",
                    value: 2,
                    feedback: "You pair emotion with logic — prosperity thinking."
                }
            ]
        },
        {
            id: 3,
            text: "How do you feel about people who are rich?",
            options: [
                {
                    label: "😤 Most didn't earn it fairly.",
                    value: 0,
                    feedback: "You hold judgment that blocks attraction."
                },
                {
                    label: "😐 It depends on what they do with it.",
                    value: 2,
                    feedback: "You focus on impact, not envy — emotional maturity."
                },
                {
                    label: "🤩 They inspire me to aim higher.",
                    value: 3,
                    feedback: "You see wealth as expansion, not threat."
                },
                {
                    label: "🤷 I don't think about them.",
                    value: 1,
                    feedback: "You disconnect from comparison to avoid discomfort."
                }
            ]
        },
        {
            id: 4,
            text: "When you spend money on yourself…",
            options: [
                {
                    label: "😔 You feel guilt right after.",
                    value: 0,
                    feedback: "You confuse self-worth with sacrifice."
                },
                {
                    label: "🧠 You justify it logically.",
                    value: 1,
                    feedback: "You allow pleasure only through reason."
                },
                {
                    label: "💎 You feel proud — it's a vote for your future self.",
                    value: 3,
                    feedback: "You associate money with alignment, not indulgence."
                },
                {
                    label: "💬 You compare your spending to others.",
                    value: 2,
                    feedback: "You seek validation through reflection, not intention."
                }
            ]
        },
        {
            id: 5,
            text: "What scares you most about losing money?",
            options: [
                {
                    label: "💀 Becoming powerless.",
                    value: 0,
                    feedback: "You tie survival to control."
                },
                {
                    label: "😔 Feeling ashamed.",
                    value: 1,
                    feedback: "You see money as proof of worth."
                },
                {
                    label: "🧩 Not being able to rebuild fast enough.",
                    value: 2,
                    feedback: "You fear stagnation, not loss."
                },
                {
                    label: "🌿 Nothing — I trust I can always recreate.",
                    value: 3,
                    feedback: "You've transcended the fear of lack."
                }
            ]
        },
        {
            id: 6,
            text: "When someone earns more than you…",
            options: [
                {
                    label: "😠 You feel unfairly treated.",
                    value: 0,
                    feedback: "Scarcity distorts your sense of justice."
                },
                {
                    label: "🧠 You analyze how they did it.",
                    value: 2,
                    feedback: "You turn comparison into calibration."
                },
                {
                    label: "🤝 You feel genuinely happy for them.",
                    value: 3,
                    feedback: "You understand money as a mirror, not a threat."
                },
                {
                    label: "😶 You tell yourself you don't care.",
                    value: 1,
                    feedback: "You protect pride by denying desire."
                }
            ]
        },
        {
            id: 7,
            text: "When you invest money…",
            options: [
                {
                    label: "😬 You panic and overthink.",
                    value: 0,
                    feedback: "Fear outweighs faith — you don't trust your own judgment."
                },
                {
                    label: "📊 You calculate carefully, then act.",
                    value: 2,
                    feedback: "You balance instinct and intellect — a strategist's mind."
                },
                {
                    label: "🚀 You act fast when opportunity appears.",
                    value: 3,
                    feedback: "You trust momentum — that's the investor's intuition."
                },
                {
                    label: "💭 You hesitate until it's too late.",
                    value: 1,
                    feedback: "You lose more to indecision than risk."
                }
            ]
        },
        {
            id: 8,
            text: "If you suddenly became rich overnight…",
            options: [
                {
                    label: "😨 I'd worry about losing it.",
                    value: 0,
                    feedback: "You fear abundance as much as scarcity."
                },
                {
                    label: "🧠 I'd manage it wisely and strategically.",
                    value: 2,
                    feedback: "You'd turn fortune into foundation."
                },
                {
                    label: "😎 I'd enjoy it fully and give back.",
                    value: 3,
                    feedback: "You'd let joy and generosity coexist."
                },
                {
                    label: "😐 I'd feel like an impostor.",
                    value: 1,
                    feedback: "Wealth still feels foreign to your identity."
                }
            ]
        },
        {
            id: 9,
            text: "When you think about financial freedom…",
            options: [
                {
                    label: "💼 It feels unrealistic.",
                    value: 0,
                    feedback: "You dream with doubt — that splits your focus."
                },
                {
                    label: "🧭 It feels possible if I stay consistent.",
                    value: 2,
                    feedback: "You see freedom as process, not miracle."
                },
                {
                    label: "🌞 It feels inevitable — it's my destiny.",
                    value: 3,
                    feedback: "You've integrated abundance into your identity."
                },
                {
                    label: "😅 It feels far away, but motivating.",
                    value: 1,
                    feedback: "Hope without belief delays manifestation."
                }
            ]
        },
        {
            id: 10,
            text: "If LifeClock showed how you treat money, it would reveal that you…",
            options: [
                {
                    label: "💀 Fear losing it more than not having it.",
                    value: 0,
                    feedback: "You live in defense, not creation."
                },
                {
                    label: "💬 Talk about it, but rarely act boldly.",
                    value: 1,
                    feedback: "Words replace movement — comfort zone economics."
                },
                {
                    label: "⚡ Respect it, multiply it, release it.",
                    value: 3,
                    feedback: "You master money through motion, not possession."
                },
                {
                    label: "🌿 Use it, but never let it define you.",
                    value: 2,
                    feedback: "You see money as tool, not temple."
                }
            ]
        }
    ],
    evaluate (answers) {
        const total = answers.reduce((sum, a)=>sum + a.value, 0);
        let profile;
        if (total <= 8) {
            profile = {
                archetype: "💀 The Scarcity Keeper",
                description: "You live from survival, not creation. You fear money's power — so it fears you back.",
                message: "You've made lack your identity. Let go of fear — and wealth will follow curiosity."
            };
        } else if (total <= 15) {
            profile = {
                archetype: "💭 The Cautious Earner",
                description: "You manage, save, plan — but rarely leap. You keep wealth close, but never intimate.",
                message: "Money trusts boldness more than caution."
            };
        } else if (total <= 22) {
            profile = {
                archetype: "📈 The Builder",
                description: "You use money consciously — it works for you, not through you. You balance abundance and purpose.",
                message: "You build wealth like a craft — patient, precise, powerful."
            };
        } else {
            profile = {
                archetype: "🌞 The Prosperous Mind",
                description: "You've merged wealth with wisdom. You no longer chase — you attract, circulate, and multiply with ease.",
                message: "You are no longer earning — you are expanding."
            };
        }
        return {
            total,
            ...profile
        };
    },
    globalFeedback (total) {
        if (total < 10) return "💀 You fear money's shadow — but it's only a reflection of your own power.";
        if (total < 20) return "💼 You're learning to master wealth without worshiping it.";
        return "🌞 You embody prosperity — calm, confident, creative.";
    }
};
}),
"[project]/lib/phases/phase7.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "phase7",
    ()=>phase7
]);
const phase7 = {
    id: 7,
    title: "The Body",
    category: "Presence",
    energyType: "Heart",
    color: "#10B981",
    intro: "⚙️ Your body is your first memory — and your last truth. It knows before you do when you're lying, loving, or lost. Let's listen to it.",
    questions: [
        {
            id: 1,
            text: "When you feel stress in your body, what do you usually do?",
            options: [
                {
                    label: "😶 Ignore it — I just push through.",
                    value: 0,
                    feedback: "You've taught your body silence, and it obeys too well."
                },
                {
                    label: "🧠 Rationalize it — 'It's nothing serious.'",
                    value: 1,
                    feedback: "You treat signals as noise — logic over intuition."
                },
                {
                    label: "🌿 Pause, breathe, and check in.",
                    value: 3,
                    feedback: "You've learned that calm is not luxury — it's language."
                },
                {
                    label: "💬 Complain but don't change anything.",
                    value: 2,
                    feedback: "You hear your body, but fear its truth."
                }
            ]
        },
        {
            id: 2,
            text: "How do you relate to physical pain?",
            options: [
                {
                    label: "🔥 I endure it — pain means I'm strong.",
                    value: 0,
                    feedback: "You confuse resilience with repression."
                },
                {
                    label: "💊 I fix it fast — no time for weakness.",
                    value: 1,
                    feedback: "You patch symptoms but ignore roots."
                },
                {
                    label: "🌊 I listen — pain always has a message.",
                    value: 3,
                    feedback: "You see pain as a teacher, not an enemy."
                },
                {
                    label: "🧘 I give it space and softness.",
                    value: 2,
                    feedback: "You heal through attention, not control."
                }
            ]
        },
        {
            id: 3,
            text: "Your sleep pattern says that you…",
            options: [
                {
                    label: "🌒 Fight rest — it feels like lost time.",
                    value: 0,
                    feedback: "You run from stillness like it's death."
                },
                {
                    label: "🕰️ Sleep only when everything's done.",
                    value: 1,
                    feedback: "You trade dreams for deadlines."
                },
                {
                    label: "🌙 Respect sleep — it's sacred maintenance.",
                    value: 3,
                    feedback: "You honor recovery as creation."
                },
                {
                    label: "😐 Sleep irregularly — no real rhythm.",
                    value: 2,
                    feedback: "Your inner clock reflects your chaos."
                }
            ]
        },
        {
            id: 4,
            text: "When you look at your reflection naked, you…",
            options: [
                {
                    label: "😔 Feel critical or ashamed.",
                    value: 0,
                    feedback: "You see flaws, not form."
                },
                {
                    label: "😐 Feel neutral — it's just a body.",
                    value: 1,
                    feedback: "You've detached from embodiment to avoid judgment."
                },
                {
                    label: "🌿 Feel gratitude — it carries you daily.",
                    value: 3,
                    feedback: "You see your body as temple, not cage."
                },
                {
                    label: "💭 Focus on what to 'fix.'",
                    value: 2,
                    feedback: "Improvement replaces intimacy."
                }
            ]
        },
        {
            id: 5,
            text: "Your relationship with food is mostly…",
            options: [
                {
                    label: "🍔 Emotional — I eat when stressed or sad.",
                    value: 0,
                    feedback: "You use nourishment as anesthesia."
                },
                {
                    label: "🥗 Functional — just fuel for the machine.",
                    value: 1,
                    feedback: "You've turned life into logistics."
                },
                {
                    label: "🌾 Conscious — I respect what I consume.",
                    value: 3,
                    feedback: "You've merged biology with awareness."
                },
                {
                    label: "😅 Erratic — I forget to eat or overdo it.",
                    value: 2,
                    feedback: "Your rhythm follows emotion, not energy."
                }
            ]
        },
        {
            id: 6,
            text: "When your body sends signals of fatigue, you…",
            options: [
                {
                    label: "💪 Push harder — discipline first.",
                    value: 0,
                    feedback: "You confuse burnout with bravery."
                },
                {
                    label: "😴 Rest briefly, then resume.",
                    value: 1,
                    feedback: "You rest to restart, not to restore."
                },
                {
                    label: "🌙 Truly rest — no guilt.",
                    value: 3,
                    feedback: "You trust pause as part of performance."
                },
                {
                    label: "📅 Schedule rest later.",
                    value: 2,
                    feedback: "You manage fatigue like a task, not a need."
                }
            ]
        },
        {
            id: 7,
            text: "When your heart races or your breath shortens, you…",
            options: [
                {
                    label: "😬 Panic — something's wrong.",
                    value: 0,
                    feedback: "You meet sensations with fear, not curiosity."
                },
                {
                    label: "🧠 Analyze the cause calmly.",
                    value: 2,
                    feedback: "You bring reason to reaction — grounded awareness."
                },
                {
                    label: "🧘 Breathe deeper — you know it passes.",
                    value: 3,
                    feedback: "You've befriended your body's storms."
                },
                {
                    label: "😐 Ignore it — it happens often.",
                    value: 1,
                    feedback: "You've normalized alarm — dangerous peace."
                }
            ]
        },
        {
            id: 8,
            text: "How do you use movement or exercise?",
            options: [
                {
                    label: "🏋️ To punish myself or prove worth.",
                    value: 0,
                    feedback: "You turn vitality into penance."
                },
                {
                    label: "🚶 To maintain balance and clarity.",
                    value: 3,
                    feedback: "You move to remember you're alive."
                },
                {
                    label: "⚡ To feel control over my body.",
                    value: 2,
                    feedback: "You channel control through repetition — better, but rigid."
                },
                {
                    label: "😅 Rarely — I don't prioritize it.",
                    value: 1,
                    feedback: "Disconnection breeds stagnation."
                }
            ]
        },
        {
            id: 9,
            text: "Your body is speaking — what word describes its voice?",
            options: [
                {
                    label: "💀 Silence.",
                    value: 0,
                    feedback: "You've muted the messenger."
                },
                {
                    label: "⚡ Noise.",
                    value: 1,
                    feedback: "Your signals scream from neglect."
                },
                {
                    label: "🌿 Whispers.",
                    value: 2,
                    feedback: "You're starting to listen."
                },
                {
                    label: "🌞 Music.",
                    value: 3,
                    feedback: "Harmony — body and mind finally in tune."
                }
            ]
        },
        {
            id: 10,
            text: "If LifeClock could scan your body's energy right now, it would say:",
            options: [
                {
                    label: "💀 'You're surviving, not living.'",
                    value: 0,
                    feedback: "Vitality lost to vigilance."
                },
                {
                    label: "🧠 'You're thinking too much to feel.'",
                    value: 1,
                    feedback: "Mind over matter — and it shows."
                },
                {
                    label: "🌊 'You're flowing — integrated and aware.'",
                    value: 3,
                    feedback: "You inhabit yourself — that's rare."
                },
                {
                    label: "🌙 'You're halfway home — almost aligned.'",
                    value: 2,
                    feedback: "You sense harmony, but haven't surrendered yet."
                }
            ]
        }
    ],
    evaluate (answers) {
        const total = answers.reduce((sum, a)=>sum + a.value, 0);
        let profile;
        if (total <= 8) {
            profile = {
                archetype: "💀 The Disconnected Vessel",
                description: "You live in your head, far from your body. Exhaustion is your language — numbness your armor.",
                message: "You think — therefore you forget to feel."
            };
        } else if (total <= 15) {
            profile = {
                archetype: "⚡ The Overcontroller",
                description: "You treat your body like a machine. You manage it, not inhabit it.",
                message: "You perform wellness instead of embodying it."
            };
        } else if (total <= 22) {
            profile = {
                archetype: "🌿 The Listener",
                description: "You respect your body's wisdom and rhythm. You trust sensations more than schedules.",
                message: "You've made peace between instinct and intellect."
            };
        } else {
            profile = {
                archetype: "🌞 The Embodied Spirit",
                description: "You move through life in full awareness. Your body and soul are one instrument — tuned to truth.",
                message: "You no longer live inside your body. You *are* your body."
            };
        }
        return {
            total,
            ...profile
        };
    },
    globalFeedback (total) {
        if (total < 10) return "💀 You've silenced your body — but it never stops speaking.";
        if (total < 20) return "⚡ You're learning to respect the body as ally, not obstacle.";
        return "🌞 You live inside your rhythm — grounded, alive, whole.";
    }
};
}),
"[project]/lib/phases/phase8.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "phase8",
    ()=>phase8
]);
const phase8 = {
    id: 8,
    title: "Discipline",
    category: "Mastery",
    energyType: "Mind",
    color: "#0EA5E9",
    intro: "⚔️ Discipline isn't punishment — it's proof. The difference between potential and destiny is repetition. Let's see how often you keep your own promises.",
    questions: [
        {
            id: 1,
            text: "When motivation fades, what happens?",
            options: [
                {
                    label: "💀 I stop — I wait for it to come back.",
                    value: 0,
                    feedback: "You depend on emotion, not decision."
                },
                {
                    label: "⚙️ I push through a little, but it's hard.",
                    value: 1,
                    feedback: "You fight resistance, but not yet yourself."
                },
                {
                    label: "🔥 I act anyway — I trust my process.",
                    value: 3,
                    feedback: "You've replaced mood with momentum."
                },
                {
                    label: "🧠 I plan around it strategically.",
                    value: 2,
                    feedback: "You systematize effort — disciplined intelligence."
                }
            ]
        },
        {
            id: 2,
            text: "When you fail at something important…",
            options: [
                {
                    label: "😩 I give up for a while.",
                    value: 0,
                    feedback: "You confuse rest with retreat."
                },
                {
                    label: "📖 I analyze what went wrong.",
                    value: 2,
                    feedback: "Reflection keeps your failure alive — but useful."
                },
                {
                    label: "⚡ I get back up immediately.",
                    value: 3,
                    feedback: "You've built recovery into identity."
                },
                {
                    label: "😐 I pretend it doesn't matter.",
                    value: 1,
                    feedback: "You numb pain to avoid learning."
                }
            ]
        },
        {
            id: 3,
            text: "How consistent are you with your routines?",
            options: [
                {
                    label: "😬 Only when I feel good.",
                    value: 0,
                    feedback: "Emotion dictates rhythm — chaos disguised as choice."
                },
                {
                    label: "🧩 Most of the time — I try my best.",
                    value: 2,
                    feedback: "You're building muscle — one imperfect rep at a time."
                },
                {
                    label: "🔥 Always — it's who I am now.",
                    value: 3,
                    feedback: "You've become the routine — discipline embodied."
                },
                {
                    label: "😐 I hate routines — they bore me.",
                    value: 1,
                    feedback: "Freedom without structure is erosion."
                }
            ]
        },
        {
            id: 4,
            text: "When no one is watching, you…",
            options: [
                {
                    label: "😶 Relax the rules — it doesn't matter.",
                    value: 0,
                    feedback: "Integrity ends where eyes begin."
                },
                {
                    label: "🧠 Stay disciplined, but allow small escapes.",
                    value: 2,
                    feedback: "Moderation is your quiet rebellion."
                },
                {
                    label: "⚔️ Stay sharp — self-respect is the audience.",
                    value: 3,
                    feedback: "You've learned that private victories shape public fate."
                },
                {
                    label: "😅 Do just enough to not feel guilty.",
                    value: 1,
                    feedback: "Your conscience keeps you from collapse — barely."
                }
            ]
        },
        {
            id: 5,
            text: "When faced with long, hard goals…",
            options: [
                {
                    label: "😩 I lose focus after a few weeks.",
                    value: 0,
                    feedback: "You mistake duration for difficulty."
                },
                {
                    label: "⚙️ I break them into small steps.",
                    value: 2,
                    feedback: "You engineer endurance."
                },
                {
                    label: "🔥 I commit fully until it's done.",
                    value: 3,
                    feedback: "Devotion has replaced doubt."
                },
                {
                    label: "🧊 I procrastinate until urgency hits.",
                    value: 1,
                    feedback: "You flirt with chaos to feel alive."
                }
            ]
        },
        {
            id: 6,
            text: "What do you do when you don't feel like doing anything?",
            options: [
                {
                    label: "😴 I rest and give myself permission.",
                    value: 1,
                    feedback: "You protect energy — but risk inertia."
                },
                {
                    label: "💪 I act small — just one task.",
                    value: 3,
                    feedback: "Momentum is built, not found."
                },
                {
                    label: "🧠 I trick myself into starting.",
                    value: 2,
                    feedback: "You use psychology as a tool — wise warrior."
                },
                {
                    label: "💀 I do nothing — I shut down.",
                    value: 0,
                    feedback: "Inaction becomes identity if repeated too often."
                }
            ]
        },
        {
            id: 7,
            text: "Your relationship with self-discipline feels like…",
            options: [
                {
                    label: "🔗 A prison — I hate pressure.",
                    value: 0,
                    feedback: "You confuse structure with slavery."
                },
                {
                    label: "💥 A battle — I win sometimes, lose others.",
                    value: 1,
                    feedback: "Conflict precedes command."
                },
                {
                    label: "🧭 A compass — it keeps me aligned.",
                    value: 3,
                    feedback: "Discipline has evolved into devotion."
                },
                {
                    label: "⚙️ A craft — I refine it every day.",
                    value: 2,
                    feedback: "You're shaping habit into art."
                }
            ]
        },
        {
            id: 8,
            text: "When you make a promise to yourself…",
            options: [
                {
                    label: "😔 I break it often — I forgive myself later.",
                    value: 0,
                    feedback: "Self-forgiveness without correction breeds decay."
                },
                {
                    label: "🧠 I try to keep it, but I get distracted.",
                    value: 1,
                    feedback: "You mean well — intention without system."
                },
                {
                    label: "🔥 I keep it, even when it hurts.",
                    value: 3,
                    feedback: "Your word is weight — unbreakable steel."
                },
                {
                    label: "⚙️ I build accountability systems.",
                    value: 2,
                    feedback: "You've turned promise into process."
                }
            ]
        },
        {
            id: 9,
            text: "If you fail three days in a row, you…",
            options: [
                {
                    label: "💀 Feel worthless — start over someday.",
                    value: 0,
                    feedback: "Shame is not a strategy."
                },
                {
                    label: "🧩 Reset the system and try again.",
                    value: 2,
                    feedback: "You iterate, not implode."
                },
                {
                    label: "🔥 Return immediately — failure is feedback.",
                    value: 3,
                    feedback: "You've mastered rebound speed — the secret of consistency."
                },
                {
                    label: "😶 Ignore it — pretend it didn't happen.",
                    value: 1,
                    feedback: "Avoidance delays accountability."
                }
            ]
        },
        {
            id: 10,
            text: "If LifeClock could measure your discipline, it would reveal that you…",
            options: [
                {
                    label: "😴 Rely on luck, not structure.",
                    value: 0,
                    feedback: "Entropy disguised as faith."
                },
                {
                    label: "🧠 Try to stay consistent, but drift easily.",
                    value: 1,
                    feedback: "You live between effort and excuse."
                },
                {
                    label: "⚙️ Create systems to protect focus.",
                    value: 2,
                    feedback: "You engineer freedom through routine."
                },
                {
                    label: "🔥 Embody discipline — no longer forced, but chosen.",
                    value: 3,
                    feedback: "You've turned habit into holiness."
                }
            ]
        }
    ],
    evaluate (answers) {
        const total = answers.reduce((sum, a)=>sum + a.value, 0);
        let profile;
        if (total <= 8) {
            profile = {
                archetype: "💤 The Drifter",
                description: "You move when moved. You confuse flow with drift — freedom with avoidance.",
                message: "Your potential sleeps inside repetition. Wake it with rhythm, not rage."
            };
        } else if (total <= 15) {
            profile = {
                archetype: "⚙️ The Apprentice",
                description: "You've tasted structure, but not yet obedience to yourself. You train your will daily.",
                message: "Keep building. Discipline isn't domination — it's liberation."
            };
        } else if (total <= 22) {
            profile = {
                archetype: "🔥 The Craftsman",
                description: "You design your life deliberately. You act by principle, not impulse.",
                message: "You no longer chase motivation — you manufacture it."
            };
        } else {
            profile = {
                archetype: "⚔️ The Warrior Monk",
                description: "You've merged stillness and strength. Routine is sacred, and every action carries meaning.",
                message: "You no longer do — you *become*."
            };
        }
        return {
            total,
            ...profile
        };
    },
    globalFeedback (total) {
        if (total < 10) return "💤 You drift in cycles of guilt and rest. Discipline is not pain — it's precision.";
        if (total < 20) return "⚙️ You're sculpting structure from chaos. Keep forging — repetition reveals truth.";
        return "⚔️ You've mastered the edge between will and peace. Discipline now breathes inside you.";
    }
};
}),
"[project]/lib/phases/phase9.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "phase9",
    ()=>phase9
]);
const phase9 = {
    id: 9,
    title: "Faith",
    category: "Transcendence",
    energyType: "Spirit",
    color: "#FEF3C7",
    intro: "🌙 Faith begins where control ends. It's not about believing in something — it's about remembering that you're part of everything. Let's see how much trust flows through you.",
    questions: [
        {
            id: 1,
            text: "When life doesn't go as planned…",
            options: [
                {
                    label: "😡 I fight until I force an outcome.",
                    value: 0,
                    feedback: "You wrestle with life instead of dancing with it."
                },
                {
                    label: "😔 I lose hope for a while.",
                    value: 1,
                    feedback: "You confuse disappointment with destiny."
                },
                {
                    label: "🌿 I trust it has meaning, even if I don't see it yet.",
                    value: 3,
                    feedback: "You've learned the serenity of uncertainty."
                },
                {
                    label: "🧠 I try to rationalize everything.",
                    value: 2,
                    feedback: "You think your way through the unknown — not always a bridge, sometimes a wall."
                }
            ]
        },
        {
            id: 2,
            text: "Do you believe things happen for a reason?",
            options: [
                {
                    label: "💀 No — life is random.",
                    value: 0,
                    feedback: "Your logic shields you from chaos, but also from wonder."
                },
                {
                    label: "🤔 Maybe — I like to think so.",
                    value: 1,
                    feedback: "You hope for meaning but still negotiate with doubt."
                },
                {
                    label: "🌌 Yes — everything connects in invisible ways.",
                    value: 3,
                    feedback: "You see pattern in paradox — faith as perception."
                },
                {
                    label: "🧠 Only when it benefits me.",
                    value: 2,
                    feedback: "Conditional faith — controlled surrender."
                }
            ]
        },
        {
            id: 3,
            text: "When something miraculous or lucky happens, you…",
            options: [
                {
                    label: "😐 Call it coincidence.",
                    value: 0,
                    feedback: "You fear believing too much."
                },
                {
                    label: "😅 Smile, but doubt it.",
                    value: 1,
                    feedback: "You flirt with magic, but keep your guard."
                },
                {
                    label: "🌟 Feel gratitude and awe.",
                    value: 3,
                    feedback: "You've reopened the child's eye — pure wonder."
                },
                {
                    label: "🧠 Try to explain it rationally.",
                    value: 2,
                    feedback: "You honor the mystery, but still measure it."
                }
            ]
        },
        {
            id: 4,
            text: "What does 'faith' mean to you?",
            options: [
                {
                    label: "💀 Blind belief — not for me.",
                    value: 0,
                    feedback: "You reject surrender as weakness."
                },
                {
                    label: "💬 Hope in something greater.",
                    value: 1,
                    feedback: "You reach upward, but without full release."
                },
                {
                    label: "🌊 Trust in life's intelligence.",
                    value: 3,
                    feedback: "You let the river carry you, not drown you."
                },
                {
                    label: "🧠 A mindset that helps resilience.",
                    value: 2,
                    feedback: "You intellectualize the sacred."
                }
            ]
        },
        {
            id: 5,
            text: "When you can't control an outcome…",
            options: [
                {
                    label: "😬 I panic or overthink.",
                    value: 0,
                    feedback: "You still confuse surrender with danger."
                },
                {
                    label: "🧠 I plan alternatives immediately.",
                    value: 2,
                    feedback: "You negotiate with the void."
                },
                {
                    label: "🧘 I breathe and wait.",
                    value: 3,
                    feedback: "You've mastered the art of patience."
                },
                {
                    label: "😐 I distract myself.",
                    value: 1,
                    feedback: "Avoidance hides as calm."
                }
            ]
        },
        {
            id: 6,
            text: "When someone betrays your trust…",
            options: [
                {
                    label: "💀 I close off completely.",
                    value: 0,
                    feedback: "You protect safety by isolating love."
                },
                {
                    label: "😔 I forgive but never forget.",
                    value: 1,
                    feedback: "Memory outweighs mercy."
                },
                {
                    label: "🌿 I release and move forward.",
                    value: 3,
                    feedback: "You've learned that bitterness poisons the holder first."
                },
                {
                    label: "🧠 I observe and detach.",
                    value: 2,
                    feedback: "Forgiveness through distance — wisdom's defense."
                }
            ]
        },
        {
            id: 7,
            text: "How do you interpret silence from the universe?",
            options: [
                {
                    label: "😡 As rejection.",
                    value: 0,
                    feedback: "You see delay as denial."
                },
                {
                    label: "🤔 As uncertainty.",
                    value: 1,
                    feedback: "You wait, but without presence."
                },
                {
                    label: "🌙 As redirection.",
                    value: 3,
                    feedback: "You've made peace with divine timing."
                },
                {
                    label: "🧘 As space to listen.",
                    value: 2,
                    feedback: "You turn absence into meditation."
                }
            ]
        },
        {
            id: 8,
            text: "Do you believe in destiny?",
            options: [
                {
                    label: "💀 No — we make everything ourselves.",
                    value: 0,
                    feedback: "You worship control, not creation."
                },
                {
                    label: "🧠 Partly — we shape paths within fate.",
                    value: 2,
                    feedback: "You merge free will with flow — a rare equilibrium."
                },
                {
                    label: "🌞 Yes — I feel guided by something beyond logic.",
                    value: 3,
                    feedback: "You've surrendered to orchestration."
                },
                {
                    label: "😐 I used to, but not anymore.",
                    value: 1,
                    feedback: "Disillusionment hides an old believer."
                }
            ]
        },
        {
            id: 9,
            text: "When you think about death, you feel…",
            options: [
                {
                    label: "😨 Fear — I avoid the thought.",
                    value: 0,
                    feedback: "You resist the only truth that never betrays."
                },
                {
                    label: "🧠 Curiosity — I wonder what's beyond.",
                    value: 2,
                    feedback: "You question with calm reverence."
                },
                {
                    label: "🌞 Peace — it's just another transformation.",
                    value: 3,
                    feedback: "You've transcended the illusion of ending."
                },
                {
                    label: "😔 Sadness — I'm not ready yet.",
                    value: 1,
                    feedback: "Attachment softens faith's horizon."
                }
            ]
        },
        {
            id: 10,
            text: "If LifeClock revealed your level of faith, it would show that you…",
            options: [
                {
                    label: "💀 Rely only on yourself.",
                    value: 0,
                    feedback: "Independence without trust is exhaustion."
                },
                {
                    label: "😐 Believe sometimes — when things are easy.",
                    value: 1,
                    feedback: "Your faith is fair-weather — still conditional."
                },
                {
                    label: "🧘 Trust life even when it makes no sense.",
                    value: 3,
                    feedback: "You've fused courage with surrender."
                },
                {
                    label: "🌿 Balance belief and action naturally.",
                    value: 2,
                    feedback: "You move between trust and will — sacred rhythm."
                }
            ]
        }
    ],
    evaluate (answers) {
        const total = answers.reduce((sum, a)=>sum + a.value, 0);
        let profile;
        if (total <= 8) {
            profile = {
                archetype: "💀 The Rational Skeptic",
                description: "You believe only in what you can measure. Control feels safer than mystery.",
                message: "Logic gave you clarity, but stole your peace. Mystery is not your enemy — it's your missing limb."
            };
        } else if (total <= 15) {
            profile = {
                archetype: "🕯️ The Questioner",
                description: "You sense something greater, but hesitate to name it. You live between intellect and intuition.",
                message: "Faith doesn't start with answers — it starts with surrender."
            };
        } else if (total <= 22) {
            profile = {
                archetype: "🌿 The Believer",
                description: "You trust the invisible rhythm of existence. You see alignment in chaos.",
                message: "Your calm is proof that you no longer need proof."
            };
        } else {
            profile = {
                archetype: "🌞 The Infinite Soul",
                description: "You've dissolved the boundary between you and life. You act as the universe, not within it.",
                message: "You no longer believe — you *remember*."
            };
        }
        return {
            total,
            ...profile
        };
    },
    globalFeedback (total) {
        if (total < 10) return "💀 You still fight the unknown. Faith begins where control breaks.";
        if (total < 20) return "🕯️ You're opening to the invisible. Doubt is not weakness — it's the door.";
        return "🌞 You've merged trust and truth. You no longer seek — you are found.";
    }
};
}),
"[project]/lib/phases/phase10.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "phase10",
    ()=>phase10
]);
const phase10 = {
    id: 10,
    title: "Legacy",
    category: "Transmission",
    energyType: "Spirit",
    color: "#9333EA",
    intro: "🌅 Every heartbeat writes a sentence in the story of your life. Legacy isn't what you leave behind — it's what you awaken in others while you're still here. Let's see what story your time is writing.",
    questions: [
        {
            id: 1,
            text: "When you imagine your last day on Earth, what emotion dominates?",
            options: [
                {
                    label: "😨 Fear — I'm not ready.",
                    value: 0,
                    feedback: "You fear unfinished symphonies — not death itself."
                },
                {
                    label: "😔 Regret — I could have done more.",
                    value: 1,
                    feedback: "You feel the ache of unused potential."
                },
                {
                    label: "🌿 Peace — I gave what I came to give.",
                    value: 3,
                    feedback: "You measure life in depth, not years."
                },
                {
                    label: "🔥 Pride — I lived intensely.",
                    value: 2,
                    feedback: "You equate impact with fire, not roots."
                }
            ]
        },
        {
            id: 2,
            text: "When people remember you, what would you want them to feel?",
            options: [
                {
                    label: "💡 Inspired to act.",
                    value: 3,
                    feedback: "You wish to ignite light in others — true legacy."
                },
                {
                    label: "❤️ Loved and connected.",
                    value: 2,
                    feedback: "You want your memory to heal, not impress."
                },
                {
                    label: "🏆 Respect for my success.",
                    value: 1,
                    feedback: "You crave recognition more than remembrance."
                },
                {
                    label: "😐 Nothing — I don't care what happens after.",
                    value: 0,
                    feedback: "Indifference hides fear of being forgotten."
                }
            ]
        },
        {
            id: 3,
            text: "When you help someone, you usually…",
            options: [
                {
                    label: "💬 Expect them to notice or thank me.",
                    value: 1,
                    feedback: "You trade help for validation — a silent contract."
                },
                {
                    label: "🌿 Do it because it feels right.",
                    value: 3,
                    feedback: "You understand giving as self-extension, not loss."
                },
                {
                    label: "🤔 Analyze if they 'deserve' it.",
                    value: 2,
                    feedback: "You give with discernment — wise but conditional."
                },
                {
                    label: "😐 Rarely do it — I'm focused on my path.",
                    value: 0,
                    feedback: "You see isolation as efficiency."
                }
            ]
        },
        {
            id: 4,
            text: "How do you measure success now?",
            options: [
                {
                    label: "💰 In results and possessions.",
                    value: 0,
                    feedback: "You still weigh worth in weight and numbers."
                },
                {
                    label: "🏆 In respect and influence.",
                    value: 1,
                    feedback: "You value echo more than essence."
                },
                {
                    label: "🌿 In alignment and peace.",
                    value: 3,
                    feedback: "Your metric is harmony — the rarest wealth."
                },
                {
                    label: "💡 In growth and lessons learned.",
                    value: 2,
                    feedback: "You measure evolution, not accumulation."
                }
            ]
        },
        {
            id: 5,
            text: "When you see young people chasing what you once did, you feel…",
            options: [
                {
                    label: "😠 Irritated — they don't understand life yet.",
                    value: 0,
                    feedback: "You've turned experience into superiority."
                },
                {
                    label: "😌 Nostalgic — I remember that fire.",
                    value: 1,
                    feedback: "You miss the chaos that built you."
                },
                {
                    label: "🌿 Proud — the torch keeps burning.",
                    value: 3,
                    feedback: "You recognize continuity as immortality."
                },
                {
                    label: "🧠 Detached — it's their journey, not mine.",
                    value: 2,
                    feedback: "You accept separation with serenity."
                }
            ]
        },
        {
            id: 6,
            text: "When you achieve something great, what's your instinct?",
            options: [
                {
                    label: "🔥 Celebrate loudly — I've earned it.",
                    value: 1,
                    feedback: "You equate victory with validation."
                },
                {
                    label: "🌙 Reflect quietly on the path.",
                    value: 3,
                    feedback: "You find joy in process, not applause."
                },
                {
                    label: "💬 Teach others how to do it too.",
                    value: 2,
                    feedback: "You multiply success by sharing it."
                },
                {
                    label: "😐 Move on to the next goal.",
                    value: 0,
                    feedback: "You skip celebration — stuck in doing."
                }
            ]
        },
        {
            id: 7,
            text: "If you could leave one message for humanity, it would be:",
            options: [
                {
                    label: "💀 'Wake up — time is running out.'",
                    value: 0,
                    feedback: "You teach urgency, not trust."
                },
                {
                    label: "🌞 'Remember — you are already enough.'",
                    value: 3,
                    feedback: "You transmit peace through presence."
                },
                {
                    label: "⚙️ 'Build, create, and never settle.'",
                    value: 2,
                    feedback: "You push humanity toward motion — noble fire."
                },
                {
                    label: "❤️ 'Love, even when it hurts.'",
                    value: 1,
                    feedback: "You pass down compassion through courage."
                }
            ]
        },
        {
            id: 8,
            text: "When you think of your life's impact, you…",
            options: [
                {
                    label: "😔 Doubt that it matters.",
                    value: 0,
                    feedback: "You underestimate how presence ripples beyond logic."
                },
                {
                    label: "🧠 Hope it mattered to a few people.",
                    value: 1,
                    feedback: "You think legacy in small, tender scales."
                },
                {
                    label: "🌿 Feel peace — every act counts.",
                    value: 3,
                    feedback: "You trust resonance more than recognition."
                },
                {
                    label: "🔥 Feel driven to make it huge.",
                    value: 2,
                    feedback: "Your legacy still wears ambition's flame."
                }
            ]
        },
        {
            id: 9,
            text: "If the world forgot your name tomorrow…",
            options: [
                {
                    label: "💀 I'd feel erased.",
                    value: 0,
                    feedback: "You confuse being remembered with being real."
                },
                {
                    label: "😔 I'd accept it — but it would hurt.",
                    value: 1,
                    feedback: "Attachment fades slower than form."
                },
                {
                    label: "🌙 I'd smile — life remembers in other ways.",
                    value: 3,
                    feedback: "You've let go of the illusion of permanence."
                },
                {
                    label: "🧠 I'd start again — legacy is ongoing.",
                    value: 2,
                    feedback: "You understand immortality as iteration."
                }
            ]
        },
        {
            id: 10,
            text: "If LifeClock could show your legacy, it would reveal that you…",
            options: [
                {
                    label: "💀 Chased noise but lost the melody.",
                    value: 0,
                    feedback: "You achieved more than you became."
                },
                {
                    label: "⚡ Built, but forgot to breathe.",
                    value: 1,
                    feedback: "You left monuments — not memories."
                },
                {
                    label: "🌿 Inspired others to rise.",
                    value: 3,
                    feedback: "You turned your life into a signal, not a statue."
                },
                {
                    label: "🌞 Became a quiet example of balance.",
                    value: 2,
                    feedback: "You proved peace can lead, too."
                }
            ]
        }
    ],
    evaluate (answers) {
        const total = answers.reduce((sum, a)=>sum + a.value, 0);
        let profile;
        if (total <= 8) {
            profile = {
                archetype: "💀 The Achiever Lost in Noise",
                description: "You built towers but forgot the sky. You lived for impact, not imprint.",
                message: "Your story is still loud — but not yet heard. Build less — mean more."
            };
        } else if (total <= 15) {
            profile = {
                archetype: "🔥 The Builder of Echoes",
                description: "You seek remembrance, not resonance. Your fire inspires, but burns fast.",
                message: "Legacy is not applause — it's continuity."
            };
        } else if (total <= 22) {
            profile = {
                archetype: "🌿 The Gardener of Souls",
                description: "You plant seeds you'll never see bloom. You create silently, trusting time.",
                message: "You've learned that what lasts is what you give away."
            };
        } else {
            profile = {
                archetype: "🌞 The Eternal Flame",
                description: "You've transcended legacy. You *are* the transmission — love, wisdom, and creation embodied.",
                message: "You don't leave a mark. You leave a light."
            };
        }
        return {
            total,
            ...profile
        };
    },
    globalFeedback (total) {
        if (total < 10) return "💀 You've achieved much, but significance awaits depth.";
        if (total < 20) return "🔥 You're shifting from ambition to meaning. Keep refining the signal.";
        return "🌞 You've become what you sought to create — timeless presence.";
    }
};
}),
"[project]/lib/phases/index.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "phases",
    ()=>phases
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$phases$2f$phase1$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/phases/phase1.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$phases$2f$phase2$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/phases/phase2.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$phases$2f$phase3$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/phases/phase3.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$phases$2f$phase4$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/phases/phase4.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$phases$2f$phase5$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/phases/phase5.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$phases$2f$phase6$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/phases/phase6.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$phases$2f$phase7$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/phases/phase7.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$phases$2f$phase8$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/phases/phase8.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$phases$2f$phase9$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/phases/phase9.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$phases$2f$phase10$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/phases/phase10.ts [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
const phases = [
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$phases$2f$phase1$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["phase1"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$phases$2f$phase2$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["phase2"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$phases$2f$phase3$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["phase3"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$phases$2f$phase4$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["phase4"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$phases$2f$phase5$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["phase5"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$phases$2f$phase6$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["phase6"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$phases$2f$phase7$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["phase7"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$phases$2f$phase8$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["phase8"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$phases$2f$phase9$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["phase9"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$phases$2f$phase10$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["phase10"]
];
}),
"[project]/app/quiz/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>QuizPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$chat$2d$message$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/chat-message.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$typing$2d$indicator$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/typing-indicator.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$progress$2d$bar$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/progress-bar.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$phase$2d$transition$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/phase-transition.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$phases$2f$index$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/phases/index.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
const phaseTransitions = [
    {
        id: 1,
        name: "The Mirror",
        color: "#94A3B8",
        text: "The mirror reflects what you hide...",
        sound: "phase1"
    },
    {
        id: 2,
        name: "The Control",
        color: "#3B82F6",
        text: "Control is an illusion you maintain...",
        sound: "phase2"
    },
    {
        id: 3,
        name: "The Desire",
        color: "#EF4444",
        text: "Desire reveals your true north...",
        sound: "phase3"
    },
    {
        id: 4,
        name: "Love",
        color: "#EC4899",
        text: "Love is the architecture of your soul...",
        sound: "phase4"
    },
    {
        id: 5,
        name: "Time",
        color: "#8B5CF6",
        text: "Time bends to those who understand it...",
        sound: "phase5"
    },
    {
        id: 6,
        name: "Money",
        color: "#F59E0B",
        text: "Money flows where energy goes...",
        sound: "phase6"
    },
    {
        id: 7,
        name: "The Body",
        color: "#10B981",
        text: "Your body remembers what your mind forgets...",
        sound: "phase7"
    },
    {
        id: 8,
        name: "Discipline",
        color: "#0EA5E9",
        text: "Discipline is freedom in disguise...",
        sound: "phase8"
    },
    {
        id: 9,
        name: "Faith",
        color: "#FEF3C7",
        text: "Faith is seeing light with your heart...",
        sound: "phase9"
    },
    {
        id: 10,
        name: "Legacy",
        color: "#9333EA",
        text: "Legacy is written in the lives you touch...",
        sound: "phase10"
    }
];
function QuizPage() {
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const [messages, setMessages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [currentPhaseIndex, setCurrentPhaseIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const [currentQuestionIndex, setCurrentQuestionIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const [isTyping, setIsTyping] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [answers, setAnswers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [canAnswer, setCanAnswer] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showOptions, setShowOptions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const messagesEndRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [lastUserMessageIndex, setLastUserMessageIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(-1);
    const [allPhaseResults, setAllPhaseResults] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [showPhaseTransition, setShowPhaseTransition] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [transitionPhase, setTransitionPhase] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [userName, setUserName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const currentPhase = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$phases$2f$index$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["phases"][currentPhaseIndex];
    const currentQuestion = currentPhase.questions[currentQuestionIndex];
    const totalQuestions = currentPhase.questions.length;
    const progress = (currentQuestionIndex + 1) / totalQuestions * 100;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        messagesEndRef.current?.scrollIntoView({
            behavior: "smooth"
        });
    }, [
        messages,
        isTyping
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const timer = setTimeout(()=>{
            startPhase();
        }, 1000);
        return ()=>clearTimeout(timer);
    }, []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const onboardingData = localStorage.getItem("lifeclockOnboarding");
        if (onboardingData) {
            try {
                const data = JSON.parse(onboardingData);
                setUserName(data.name || "");
            } catch (e) {
                console.error("[v0] Failed to parse onboarding data:", e);
            }
        }
    }, []);
    const playSound = (sound)=>{
        try {
            const audio = new Audio(`/sounds/${sound}.mp3`);
            audio.volume = 0.3;
            audio.play().catch(()=>{});
        } catch (e) {}
    };
    const vibrate = (duration)=>{
        if (typeof navigator !== "undefined" && navigator.vibrate) {
            navigator.vibrate(duration);
        }
    };
    const startPhase = async ()=>{
        setIsTyping(true);
        await new Promise((resolve)=>setTimeout(resolve, 1500));
        setMessages([
            {
                role: "assistant",
                text: currentPhase.intro,
                messageType: "revelation"
            }
        ]);
        setIsTyping(false);
        playSound("pop");
        vibrate(40);
        await new Promise((resolve)=>setTimeout(resolve, 2500));
        askQuestion();
    };
    const askQuestion = ()=>{
        setIsTyping(true);
        setCanAnswer(false);
        setShowOptions(false);
        setTimeout(()=>{
            setMessages((prev)=>[
                    ...prev,
                    {
                        role: "assistant",
                        text: replaceVariables(currentQuestion.text)
                    }
                ]);
            setIsTyping(false);
            playSound("pop");
            vibrate(40);
            setTimeout(()=>{
                setShowOptions(true);
                setCanAnswer(true);
            }, 800);
        }, 1200);
    };
    const getCurrentTime = ()=>{
        const now = new Date();
        return `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}`;
    };
    const handleAnswer = (option)=>{
        if (!canAnswer) return;
        setCanAnswer(false);
        setShowOptions(false);
        playSound("send");
        vibrate(40);
        const userMessage = {
            role: "user",
            text: option.label,
            timestamp: getCurrentTime(),
            showReadReceipt: true
        };
        setMessages((prev)=>{
            const newMessages = [
                ...prev,
                userMessage
            ];
            setLastUserMessageIndex(newMessages.length - 1);
            return newMessages;
        });
        const answer = {
            value: option.value,
            feedback: option.feedback
        };
        setAnswers((prev)=>[
                ...prev,
                answer
            ]);
        setIsTyping(true);
        setTimeout(()=>{
            setMessages((prev)=>[
                    ...prev,
                    {
                        role: "assistant",
                        text: option.feedback,
                        messageType: "introspection"
                    }
                ]);
            setIsTyping(false);
            playSound("pop");
            vibrate(40);
            setTimeout(()=>{
                setMessages((prev)=>prev.map((msg, idx)=>idx === lastUserMessageIndex ? {
                            ...msg,
                            showReadReceipt: false
                        } : msg));
            }, 1500);
            const nextQuestionIndex = currentQuestionIndex + 1;
            if (nextQuestionIndex < totalQuestions) {
                setCurrentQuestionIndex(nextQuestionIndex);
                setTimeout(()=>{
                    askQuestion();
                }, 2000);
            } else {
                finishPhase();
            }
        }, 1000);
    };
    const finishPhase = async ()=>{
        const evaluation = currentPhase.evaluate(answers);
        const globalFeedback = currentPhase.globalFeedback(evaluation.total);
        const phaseResult = {
            id: currentPhase.id,
            title: currentPhase.title,
            total: evaluation.total,
            archetype: evaluation.archetype,
            energyType: currentPhase.energyType
        };
        await new Promise((resolve)=>setTimeout(resolve, 2000));
        setIsTyping(true);
        await new Promise((resolve)=>setTimeout(resolve, 1500));
        setMessages((prev)=>[
                ...prev,
                {
                    role: "assistant",
                    text: globalFeedback,
                    messageType: "revelation"
                }
            ]);
        setIsTyping(false);
        playSound("chime");
        vibrate(80);
        await new Promise((resolve)=>setTimeout(resolve, 2500));
        setIsTyping(true);
        await new Promise((resolve)=>setTimeout(resolve, 1500));
        setMessages((prev)=>[
                ...prev,
                {
                    role: "assistant",
                    text: `Your archetype: ${evaluation.archetype}`,
                    messageType: "revelation"
                }
            ]);
        setIsTyping(false);
        playSound("complete");
        vibrate(80);
        await new Promise((resolve)=>setTimeout(resolve, 2000));
        setMessages((prev)=>[
                ...prev,
                {
                    role: "assistant",
                    text: evaluation.description,
                    messageType: "introspection"
                }
            ]);
        await new Promise((resolve)=>setTimeout(resolve, 2500));
        setMessages((prev)=>[
                ...prev,
                {
                    role: "assistant",
                    text: evaluation.message,
                    messageType: "motivation"
                }
            ]);
        const updatedResults = [
            ...allPhaseResults,
            phaseResult
        ];
        setAllPhaseResults(updatedResults);
        await new Promise((resolve)=>setTimeout(resolve, 3000));
        if (currentPhaseIndex < __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$phases$2f$index$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["phases"].length - 1) {
            const nextPhaseIndex = currentPhaseIndex + 1;
            setTransitionPhase(phaseTransitions[nextPhaseIndex]);
            setShowPhaseTransition(true);
        } else {
            localStorage.setItem("lifeclock-all-results", JSON.stringify(updatedResults));
            setTimeout(()=>{
                router.push("/generating");
            }, 2000);
        }
    };
    const handleTransitionComplete = ()=>{
        setShowPhaseTransition(false);
        setCurrentPhaseIndex(currentPhaseIndex + 1);
        setCurrentQuestionIndex(0);
        setAnswers([]);
        setMessages([]);
        setTimeout(()=>{
            startPhase();
        }, 500);
    };
    const replaceVariables = (text)=>{
        return text.replace(/\{name\}/g, userName);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex h-screen flex-col bg-[#000000] relative",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `absolute inset-0 opacity-5 pointer-events-none quiz-overlay quiz-overlay-phase-${currentPhase.id}`
            }, void 0, false, {
                fileName: "[project]/app/quiz/page.tsx",
                lineNumber: 305,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                children: showPhaseTransition && transitionPhase && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$phase$2d$transition$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    phase: transitionPhase,
                    onComplete: handleTransitionComplete
                }, void 0, false, {
                    fileName: "[project]/app/quiz/page.tsx",
                    lineNumber: 311,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/quiz/page.tsx",
                lineNumber: 309,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "border-b border-white/5 bg-black/50 p-4 backdrop-blur-sm",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mx-auto max-w-md",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-2 flex items-center justify-center gap-2",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: `text-xs font-medium quiz-phase-title quiz-overlay-phase-${currentPhase.id}`,
                                children: currentPhase.title
                            }, void 0, false, {
                                fileName: "[project]/app/quiz/page.tsx",
                                lineNumber: 318,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/quiz/page.tsx",
                            lineNumber: 317,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$progress$2d$bar$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            current: currentQuestionIndex + 1,
                            total: totalQuestions,
                            customProgress: progress,
                            phaseColor: currentPhase.color
                        }, void 0, false, {
                            fileName: "[project]/app/quiz/page.tsx",
                            lineNumber: 322,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/quiz/page.tsx",
                    lineNumber: 316,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/quiz/page.tsx",
                lineNumber: 315,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "hide-scrollbar flex-1 overflow-y-auto p-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mx-auto flex max-w-md flex-col space-y-1.5 pb-[400px]",
                    children: [
                        messages.map((message, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$chat$2d$message$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                role: message.role,
                                text: message.text,
                                messageType: message.messageType,
                                showReadReceipt: message.showReadReceipt && index === lastUserMessageIndex,
                                timestamp: message.timestamp
                            }, index, false, {
                                fileName: "[project]/app/quiz/page.tsx",
                                lineNumber: 334,
                                columnNumber: 13
                            }, this)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                            children: isTyping && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$typing$2d$indicator$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/app/quiz/page.tsx",
                                lineNumber: 344,
                                columnNumber: 41
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/quiz/page.tsx",
                            lineNumber: 344,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            ref: messagesEndRef
                        }, void 0, false, {
                            fileName: "[project]/app/quiz/page.tsx",
                            lineNumber: 346,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/quiz/page.tsx",
                    lineNumber: 332,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/quiz/page.tsx",
                lineNumber: 331,
                columnNumber: 7
            }, this),
            showOptions && canAnswer && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                className: "fixed bottom-0 left-0 right-0 border-t border-white/5 bg-linear-to-t from-black from-60% via-black/95 to-transparent p-4 pb-6 backdrop-blur-lg",
                initial: {
                    opacity: 0,
                    y: 20
                },
                animate: {
                    opacity: 1,
                    y: 0
                },
                transition: {
                    duration: 0.3
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mx-auto max-w-md",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-3",
                        children: currentQuestion.options.map((option, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].button, {
                                onClick: ()=>handleAnswer(option),
                                initial: {
                                    opacity: 0,
                                    y: 10
                                },
                                animate: {
                                    opacity: 1,
                                    y: 0
                                },
                                transition: {
                                    delay: index * 0.1
                                },
                                whileTap: {
                                    scale: 0.97
                                },
                                whileHover: {
                                    scale: 1.01
                                },
                                className: "group relative overflow-hidden rounded-2xl bg-[#2C2C2E] px-6 py-4 text-left text-[17px] font-medium text-[#E5E5EA] shadow-lg transition-all hover:bg-[#3A3A3C] active:shadow-xl",
                                style: {
                                    fontFamily: "SF Pro Text, -apple-system, system-ui, sans-serif",
                                    boxShadow: `0 2px 8px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.05), 0 0 0 1px ${currentPhase.color}20`,
                                    borderLeft: `2px solid ${currentPhase.color}40`
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                                        className: "absolute inset-0",
                                        style: {
                                            background: `linear-gradient(to right, transparent, ${currentPhase.color}10, transparent)`
                                        },
                                        initial: {
                                            x: "-100%"
                                        },
                                        whileHover: {
                                            x: "100%"
                                        },
                                        transition: {
                                            duration: 0.6
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/app/quiz/page.tsx",
                                        lineNumber: 375,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "relative",
                                        children: option.label
                                    }, void 0, false, {
                                        fileName: "[project]/app/quiz/page.tsx",
                                        lineNumber: 384,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, index, true, {
                                fileName: "[project]/app/quiz/page.tsx",
                                lineNumber: 360,
                                columnNumber: 17
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/app/quiz/page.tsx",
                        lineNumber: 358,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/quiz/page.tsx",
                    lineNumber: 357,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/quiz/page.tsx",
                lineNumber: 351,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/quiz/page.tsx",
        lineNumber: 304,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__4e6217f0._.js.map