module.exports = [
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/punycode [external] (punycode, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("punycode", () => require("punycode"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[project]/lifeclock-20251031-141611/lib/supabase/client.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createClient",
    ()=>createClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/@supabase/ssr/dist/module/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/@supabase/ssr/dist/module/createBrowserClient.js [app-ssr] (ecmascript)");
;
function createClient() {
    // Debug temporaire: vérifier la présence des variables NEXT_PUBLIC_* côté client
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createBrowserClient"])(("TURBOPACK compile-time value", "https://haqxwwynqamhbroidxov.supabase.co"), ("TURBOPACK compile-time value", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhhcXh3d3lucWFtaGJyb2lkeG92Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE4NDE1NzEsImV4cCI6MjA3NzQxNzU3MX0.ZAnwfSwR0gHNz-SUP9B2zWkoL7fur6LyRV0FcPyJMe8"));
}
}),
"[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AdminReferralsPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/lib/supabase/client.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
const AUTH_STORAGE_KEY = "lifeclock-admin-authenticated";
const PRICE_PER_SALE = 47;
function AdminReferralsPage() {
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const [referrals, setReferrals] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [affiliatesInfo, setAffiliatesInfo] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(new Map());
    const [isAuthenticated, setIsAuthenticated] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [username, setUsername] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [password, setPassword] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [authError, setAuthError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    const [searchQuery, setSearchQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [filterPendingPayments, setFilterPendingPayments] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [filterCompletedPayments, setFilterCompletedPayments] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [updatingReferrals, setUpdatingReferrals] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(new Set());
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
    }, []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!isAuthenticated) return;
        const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createClient"])();
        const loadData = async ()=>{
            // Charger les referrals
            const { data: referralsData, error: referralsError } = await supabase.from("referrals").select("*").not("referred_email", "is", null).order("created_at", {
                ascending: false
            });
            if (referralsError) {
                console.error("[admin-referrals] Error loading referrals:", referralsError);
                return;
            }
            if (referralsData) {
                setReferrals(referralsData);
                // Récupérer les emails uniques des affiliés
                const uniqueEmails = Array.from(new Set(referralsData.map((r)=>r.referrer_email)));
                // Charger les infos des affiliés
                const { data: affiliatesData, error: affiliatesError } = await supabase.from("onboarding_data").select("email, name").in("email", uniqueEmails);
                if (!affiliatesError && affiliatesData) {
                    const infoMap = new Map();
                    affiliatesData.forEach((aff)=>{
                        infoMap.set(aff.email, aff);
                    });
                    setAffiliatesInfo(infoMap);
                }
            }
        };
        loadData();
        // Écouter les changements en temps réel
        const channel = supabase.channel("realtime-referrals").on("postgres_changes", {
            event: "INSERT",
            schema: "public",
            table: "referrals"
        }, async ()=>{
            // Recharger les données
            await loadData();
        }).on("postgres_changes", {
            event: "UPDATE",
            schema: "public",
            table: "referrals"
        }, async ()=>{
            // Recharger les données
            await loadData();
        }).subscribe();
        return ()=>{
            supabase.removeChannel(channel);
        };
    }, [
        isAuthenticated
    ]);
    const handleLogout = ()=>{
        setIsAuthenticated(false);
        setUsername("");
        setPassword("");
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
    };
    const handleSubmit = async (e)=>{
        e.preventDefault();
        if (!username || !password) {
            setAuthError("Veuillez remplir tous les champs");
            return;
        }
        try {
            const response = await fetch("/api/admin/auth", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    username,
                    password
                })
            });
            const data = await response.json();
            if (response.ok && data.success) {
                setIsAuthenticated(true);
                setAuthError(null);
                if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
                ;
            } else {
                setAuthError(data.error || "Identifiant ou mot de passe incorrect");
                setPassword("");
            }
        } catch (error) {
            console.error("[admin-auth] Error:", error);
            setAuthError("Erreur de connexion");
            setPassword("");
        }
    };
    const handleMarkAsPaid = async (referralId)=>{
        setUpdatingReferrals((prev)=>new Set(prev).add(referralId));
        try {
            const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createClient"])();
            const { error } = await supabase.from("referrals").update({
                status: "paid"
            }).eq("id", referralId);
            if (error) {
                console.error("[admin-referrals] Error marking as paid:", error);
                alert("Erreur lors de la mise à jour");
            }
        // Le temps réel actualisera automatiquement les données
        } catch (error) {
            console.error("[admin-referrals] Error:", error);
            alert("Erreur lors de la mise à jour");
        } finally{
            setUpdatingReferrals((prev)=>{
                const next = new Set(prev);
                next.delete(referralId);
                return next;
            });
        }
    };
    // Grouper les referrals par affilié
    const groupedAffiliates = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const grouped = new Map();
        referrals.forEach((referral)=>{
            const email = referral.referrer_email;
            if (!grouped.has(email)) {
                const info = affiliatesInfo.get(email);
                grouped.set(email, {
                    referrer_email: email,
                    referrer_code: referral.referrer_code,
                    name: info?.name || null,
                    totalReferrals: 0,
                    pendingCount: 0,
                    completedCount: 0,
                    paidCount: 0,
                    revenueGenerated: 0,
                    amountToPay: 0,
                    amountPaid: 0,
                    referrals: [],
                    latestCompletedAt: null,
                    latestPaidAt: null
                });
            }
            const stats = grouped.get(email);
            stats.referrals.push(referral);
            stats.totalReferrals++;
            if (referral.status === "pending") {
                stats.pendingCount++;
            } else if (referral.status === "completed") {
                stats.completedCount++;
                stats.amountToPay += Number(referral.commission_amount) || 0;
                if (referral.completed_at && (!stats.latestCompletedAt || referral.completed_at > stats.latestCompletedAt)) {
                    stats.latestCompletedAt = referral.completed_at;
                }
            } else if (referral.status === "paid") {
                stats.paidCount++;
                stats.amountPaid += Number(referral.commission_amount) || 0;
                if (referral.completed_at && (!stats.latestPaidAt || referral.completed_at > stats.latestPaidAt)) {
                    stats.latestPaidAt = referral.completed_at;
                }
            }
        });
        // Calculer les revenus générés et arrondir les montants
        grouped.forEach((stats)=>{
            stats.revenueGenerated = PRICE_PER_SALE * (stats.completedCount + stats.paidCount);
            stats.amountToPay = Math.round(stats.amountToPay * 100) / 100;
            stats.amountPaid = Math.round(stats.amountPaid * 100) / 100;
        });
        return Array.from(grouped.values());
    }, [
        referrals,
        affiliatesInfo
    ]);
    // Filtrer et trier les affiliés
    const filteredAndSortedAffiliates = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        let filtered = groupedAffiliates;
        // Filtre de recherche
        if (searchQuery.trim()) {
            const query = searchQuery.toLowerCase();
            filtered = filtered.filter((aff)=>aff.name?.toLowerCase().includes(query) || aff.referrer_email.toLowerCase().includes(query));
        }
        // Filtres de paiement
        if (filterPendingPayments) {
            filtered = filtered.filter((aff)=>aff.amountToPay > 0);
        }
        if (filterCompletedPayments) {
            filtered = filtered.filter((aff)=>aff.amountPaid > 0);
        }
        // Tri
        if (filterPendingPayments && !filterCompletedPayments) {
            // Tri par completed_at le plus récent pour "paiements à faire"
            filtered.sort((a, b)=>{
                if (!a.latestCompletedAt && !b.latestCompletedAt) return 0;
                if (!a.latestCompletedAt) return 1;
                if (!b.latestCompletedAt) return -1;
                return b.latestCompletedAt.localeCompare(a.latestCompletedAt);
            });
        } else if (filterCompletedPayments && !filterPendingPayments) {
            // Tri par completed_at le plus récent pour "paiements finalisés"
            filtered.sort((a, b)=>{
                if (!a.latestPaidAt && !b.latestPaidAt) return 0;
                if (!a.latestPaidAt) return 1;
                if (!b.latestPaidAt) return -1;
                return b.latestPaidAt.localeCompare(a.latestPaidAt);
            });
        } else if (filterPendingPayments && filterCompletedPayments) {
            // Si les deux filtres sont actifs, trier par le plus récent entre les deux
            filtered.sort((a, b)=>{
                const aLatest = a.latestCompletedAt || a.latestPaidAt;
                const bLatest = b.latestCompletedAt || b.latestPaidAt;
                if (!aLatest && !bLatest) return 0;
                if (!aLatest) return 1;
                if (!bLatest) return -1;
                return bLatest.localeCompare(aLatest);
            });
        }
        return filtered;
    }, [
        groupedAffiliates,
        searchQuery,
        filterPendingPayments,
        filterCompletedPayments
    ]);
    // Calculer les statistiques globales
    const globalStats = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const activeAffiliates = new Set();
        let totalReferrals = 0;
        let totalCompletedOrPaid = 0;
        let totalToPay = 0;
        let totalPaid = 0;
        referrals.forEach((ref)=>{
            if (ref.referred_email) {
                activeAffiliates.add(ref.referrer_email);
                totalReferrals++;
                if (ref.status === "completed" || ref.status === "paid") {
                    totalCompletedOrPaid++;
                }
                if (ref.status === "completed") {
                    totalToPay += Number(ref.commission_amount) || 0;
                }
                if (ref.status === "paid") {
                    totalPaid += Number(ref.commission_amount) || 0;
                }
            }
        });
        return {
            activeAffiliates: activeAffiliates.size,
            totalReferrals,
            totalRevenue: PRICE_PER_SALE * totalCompletedOrPaid,
            totalToPay: Math.round(totalToPay * 100) / 100,
            totalPaid: Math.round(totalPaid * 100) / 100
        };
    }, [
        referrals
    ]);
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-screen bg-black text-white flex items-center justify-center",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-gray-400",
                children: "Chargement..."
            }, void 0, false, {
                fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                lineNumber: 353,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
            lineNumber: 352,
            columnNumber: 7
        }, this);
    }
    if (!isAuthenticated) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-screen bg-black text-white flex items-center justify-center",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full max-w-md px-6",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "rounded-xl border border-white/10 bg-black/40 p-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-2xl font-semibold text-white mb-2",
                            children: "Accès Admin"
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                            lineNumber: 363,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-gray-400 text-sm mb-6",
                            children: "Entrez vos identifiants pour accéder au dashboard"
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                            lineNumber: 364,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                            onSubmit: handleSubmit,
                            className: "space-y-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            htmlFor: "username",
                                            className: "block text-sm text-gray-400 mb-2",
                                            children: "Identifiant"
                                        }, void 0, false, {
                                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                            lineNumber: 368,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            id: "username",
                                            type: "text",
                                            value: username,
                                            onChange: (e)=>setUsername(e.target.value),
                                            className: "w-full rounded-lg bg-[#2C2C2E] border border-white/10 px-4 py-3 text-white placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                            placeholder: "Votre identifiant",
                                            autoFocus: true
                                        }, void 0, false, {
                                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                            lineNumber: 371,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                    lineNumber: 367,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            htmlFor: "password",
                                            className: "block text-sm text-gray-400 mb-2",
                                            children: "Mot de passe"
                                        }, void 0, false, {
                                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                            lineNumber: 383,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            id: "password",
                                            type: "password",
                                            value: password,
                                            onChange: (e)=>setPassword(e.target.value),
                                            className: "w-full rounded-lg bg-[#2C2C2E] border border-white/10 px-4 py-3 text-white placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                            placeholder: "••••••••"
                                        }, void 0, false, {
                                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                            lineNumber: 386,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                    lineNumber: 382,
                                    columnNumber: 15
                                }, this),
                                authError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "rounded-lg bg-red-500/10 border border-red-500/20 px-4 py-3 text-sm text-red-400",
                                    children: authError
                                }, void 0, false, {
                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                    lineNumber: 397,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "submit",
                                    className: "w-full rounded-lg bg-blue-600 hover:bg-blue-700 px-4 py-3 text-white font-medium transition-colors",
                                    children: "Se connecter"
                                }, void 0, false, {
                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                    lineNumber: 402,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                            lineNumber: 366,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                    lineNumber: 362,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                lineNumber: 361,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
            lineNumber: 360,
            columnNumber: 7
        }, this);
    }
    const Card = ({ title, value, suffix, subtitle })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "rounded-xl border border-white/10 bg-black/40 p-5",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-sm text-gray-400",
                    children: title
                }, void 0, false, {
                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                    lineNumber: 417,
                    columnNumber: 7
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-2 text-3xl font-semibold text-white",
                    children: [
                        value,
                        suffix ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-gray-400 text-xl ml-1",
                            children: suffix
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                            lineNumber: 420,
                            columnNumber: 19
                        }, this) : null
                    ]
                }, void 0, true, {
                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                    lineNumber: 418,
                    columnNumber: 7
                }, this),
                subtitle && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-2 text-sm text-gray-500",
                    children: subtitle
                }, void 0, false, {
                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                    lineNumber: 423,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
            lineNumber: 416,
            columnNumber: 5
        }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-black text-white",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mx-auto max-w-7xl px-6 py-10",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-between mb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                    className: "text-2xl font-semibold",
                                    children: "Affiliés"
                                }, void 0, false, {
                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                    lineNumber: 433,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-gray-400 mt-1",
                                    children: "Gestion des affiliés et paiements"
                                }, void 0, false, {
                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                    lineNumber: 434,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                            lineNumber: 432,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>router.push("/admin/conversions"),
                                    className: "px-4 py-2 rounded-lg bg-gray-800 hover:bg-gray-700 border border-white/10 text-sm text-gray-300 transition-colors",
                                    children: "Conversions"
                                }, void 0, false, {
                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                    lineNumber: 437,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleLogout,
                                    className: "px-4 py-2 rounded-lg bg-gray-800 hover:bg-gray-700 border border-white/10 text-sm text-gray-300 transition-colors",
                                    children: "Déconnexion"
                                }, void 0, false, {
                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                    lineNumber: 443,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                            lineNumber: 436,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                    lineNumber: 431,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Card, {
                            title: "Affiliés actifs",
                            value: globalStats.activeAffiliates
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                            lineNumber: 454,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Card, {
                            title: "Total referrals",
                            value: globalStats.totalReferrals
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                            lineNumber: 455,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Card, {
                            title: "Revenus générés",
                            value: globalStats.totalRevenue,
                            suffix: "$"
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                            lineNumber: 456,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Card, {
                            title: "À payer",
                            value: globalStats.totalToPay,
                            suffix: "$"
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                            lineNumber: 457,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Card, {
                            title: "Déjà payé",
                            value: globalStats.totalPaid,
                            suffix: "$"
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                            lineNumber: 458,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                    lineNumber: 453,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-8 rounded-xl border border-white/10 bg-black/40 p-5",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col sm:flex-row gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "text",
                                value: searchQuery,
                                onChange: (e)=>setSearchQuery(e.target.value),
                                placeholder: "Rechercher par nom ou email...",
                                className: "flex-1 rounded-lg bg-[#2C2C2E] border border-white/10 px-4 py-2 text-white placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            }, void 0, false, {
                                fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                lineNumber: 464,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setFilterPendingPayments(!filterPendingPayments),
                                        className: `px-4 py-2 rounded-lg border border-white/10 text-sm transition-colors ${filterPendingPayments ? "bg-blue-600 hover:bg-blue-700 text-white" : "bg-gray-800 hover:bg-gray-700 text-gray-300"}`,
                                        children: "Paiements à faire"
                                    }, void 0, false, {
                                        fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                        lineNumber: 472,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setFilterCompletedPayments(!filterCompletedPayments),
                                        className: `px-4 py-2 rounded-lg border border-white/10 text-sm transition-colors ${filterCompletedPayments ? "bg-blue-600 hover:bg-blue-700 text-white" : "bg-gray-800 hover:bg-gray-700 text-gray-300"}`,
                                        children: "Paiements finalisés"
                                    }, void 0, false, {
                                        fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                        lineNumber: 482,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                lineNumber: 471,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                        lineNumber: 463,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                    lineNumber: 462,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-8 rounded-xl border border-white/10 bg-black/40 overflow-hidden",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "overflow-x-auto",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                            className: "w-full",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                    className: "bg-black/60 border-b border-white/10",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                className: "text-left px-4 py-3 text-sm text-gray-400",
                                                children: "Affilié"
                                            }, void 0, false, {
                                                fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                lineNumber: 502,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                className: "text-left px-4 py-3 text-sm text-gray-400",
                                                children: "Code"
                                            }, void 0, false, {
                                                fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                lineNumber: 503,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                className: "text-left px-4 py-3 text-sm text-gray-400",
                                                children: "Personnes amenées"
                                            }, void 0, false, {
                                                fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                lineNumber: 504,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                className: "text-left px-4 py-3 text-sm text-gray-400",
                                                children: "Revenus générés"
                                            }, void 0, false, {
                                                fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                lineNumber: 505,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                className: "text-left px-4 py-3 text-sm text-gray-400",
                                                children: "À payer"
                                            }, void 0, false, {
                                                fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                lineNumber: 506,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                className: "text-left px-4 py-3 text-sm text-gray-400",
                                                children: "Déjà payé"
                                            }, void 0, false, {
                                                fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                lineNumber: 507,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                className: "text-left px-4 py-3 text-sm text-gray-400",
                                                children: "Actions"
                                            }, void 0, false, {
                                                fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                lineNumber: 508,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                        lineNumber: 501,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                    lineNumber: 500,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                    children: filteredAndSortedAffiliates.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            colSpan: 7,
                                            className: "px-4 py-8 text-center text-gray-400",
                                            children: "Aucun affilié trouvé"
                                        }, void 0, false, {
                                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                            lineNumber: 514,
                                            columnNumber: 21
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                        lineNumber: 513,
                                        columnNumber: 19
                                    }, this) : filteredAndSortedAffiliates.map((aff)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                            className: "border-b border-white/5 hover:bg-black/20",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    className: "px-4 py-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-white",
                                                            children: aff.name || "N/A"
                                                        }, void 0, false, {
                                                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                            lineNumber: 522,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-sm text-gray-400",
                                                            children: aff.referrer_email
                                                        }, void 0, false, {
                                                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                            lineNumber: 523,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                    lineNumber: 521,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    className: "px-4 py-3 text-gray-300 font-mono text-sm",
                                                    children: aff.referrer_code
                                                }, void 0, false, {
                                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                    lineNumber: 525,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    className: "px-4 py-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-white",
                                                            children: aff.totalReferrals
                                                        }, void 0, false, {
                                                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                            lineNumber: 527,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-xs text-gray-500",
                                                            children: [
                                                                aff.pendingCount,
                                                                " pending • ",
                                                                aff.completedCount,
                                                                " completed • ",
                                                                aff.paidCount,
                                                                " paid"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                            lineNumber: 528,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                    lineNumber: 526,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    className: "px-4 py-3",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-green-400 font-semibold",
                                                        children: [
                                                            "$",
                                                            aff.revenueGenerated
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                        lineNumber: 533,
                                                        columnNumber: 25
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                    lineNumber: 532,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    className: "px-4 py-3",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-yellow-400 font-semibold",
                                                        children: [
                                                            "$",
                                                            aff.amountToPay
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                        lineNumber: 536,
                                                        columnNumber: 25
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                    lineNumber: 535,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    className: "px-4 py-3",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-blue-400 font-semibold",
                                                        children: [
                                                            "$",
                                                            aff.amountPaid
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                        lineNumber: 539,
                                                        columnNumber: 25
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                    lineNumber: 538,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    className: "px-4 py-3",
                                                    children: aff.completedCount > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: ()=>{
                                                            // Marquer tous les "completed" comme "paid"
                                                            aff.referrals.filter((r)=>r.status === "completed").forEach((r)=>handleMarkAsPaid(r.id));
                                                        },
                                                        disabled: aff.referrals.some((r)=>r.status === "completed" && updatingReferrals.has(r.id)),
                                                        className: "px-3 py-1 rounded bg-blue-600 hover:bg-blue-700 text-white text-sm disabled:opacity-50 disabled:cursor-not-allowed transition-colors",
                                                        children: [
                                                            "Marquer payé (",
                                                            aff.completedCount,
                                                            ")"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                        lineNumber: 543,
                                                        columnNumber: 27
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                    lineNumber: 541,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, aff.referrer_email, true, {
                                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                            lineNumber: 520,
                                            columnNumber: 21
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                    lineNumber: 511,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                            lineNumber: 499,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                        lineNumber: 498,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                    lineNumber: 497,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-10 rounded-xl border border-white/10 bg-black/40 p-5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-lg font-semibold mb-4",
                            children: "Détails des referrals par affilié"
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                            lineNumber: 567,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-6",
                            children: filteredAndSortedAffiliates.map((aff)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "border border-white/10 rounded-lg p-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mb-3",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "font-semibold text-white",
                                                    children: aff.name || "N/A"
                                                }, void 0, false, {
                                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                    lineNumber: 572,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-sm text-gray-400",
                                                    children: aff.referrer_email
                                                }, void 0, false, {
                                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                    lineNumber: 573,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-gray-500 mt-1",
                                                    children: [
                                                        "Code: ",
                                                        aff.referrer_code
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                    lineNumber: 574,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                            lineNumber: 571,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "overflow-x-auto",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                                className: "w-full text-sm",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                                        className: "bg-black/40 border-b border-white/10",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                                    className: "text-left px-3 py-2 text-gray-400",
                                                                    children: "Email référé"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                                    lineNumber: 580,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                                    className: "text-left px-3 py-2 text-gray-400",
                                                                    children: "Date création"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                                    lineNumber: 581,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                                    className: "text-left px-3 py-2 text-gray-400",
                                                                    children: "Date complétion"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                                    lineNumber: 582,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                                    className: "text-left px-3 py-2 text-gray-400",
                                                                    children: "Statut"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                                    lineNumber: 583,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                                    className: "text-left px-3 py-2 text-gray-400",
                                                                    children: "Commission"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                                    lineNumber: 584,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                                    className: "text-left px-3 py-2 text-gray-400",
                                                                    children: "Action"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                                    lineNumber: 585,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                            lineNumber: 579,
                                                            columnNumber: 23
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                        lineNumber: 578,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                                        children: aff.referrals.map((ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                                className: "border-b border-white/5",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                        className: "px-3 py-2 text-gray-300",
                                                                        children: ref.referred_email || "-"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                                        lineNumber: 591,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                        className: "px-3 py-2 text-gray-400",
                                                                        children: new Date(ref.created_at).toLocaleDateString()
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                                        lineNumber: 592,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                        className: "px-3 py-2 text-gray-400",
                                                                        children: ref.completed_at ? new Date(ref.completed_at).toLocaleDateString() : "-"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                                        lineNumber: 595,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                        className: "px-3 py-2",
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: `px-2 py-0.5 rounded text-xs ${ref.status === "pending" ? "bg-yellow-500/20 text-yellow-400" : ref.status === "completed" ? "bg-orange-500/20 text-orange-400" : "bg-green-500/20 text-green-400"}`,
                                                                            children: ref.status
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                                            lineNumber: 599,
                                                                            columnNumber: 29
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                                        lineNumber: 598,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                        className: "px-3 py-2 text-gray-300",
                                                                        children: [
                                                                            "$",
                                                                            ref.commission_amount
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                                        lineNumber: 611,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                        className: "px-3 py-2",
                                                                        children: ref.status === "completed" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                            onClick: ()=>handleMarkAsPaid(ref.id),
                                                                            disabled: updatingReferrals.has(ref.id),
                                                                            className: "px-2 py-1 rounded bg-blue-600 hover:bg-blue-700 text-white text-xs disabled:opacity-50 disabled:cursor-not-allowed transition-colors",
                                                                            children: updatingReferrals.has(ref.id) ? "..." : "Marquer payé"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                                            lineNumber: 614,
                                                                            columnNumber: 31
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                                        lineNumber: 612,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, ref.id, true, {
                                                                fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                                lineNumber: 590,
                                                                columnNumber: 25
                                                            }, this))
                                                    }, void 0, false, {
                                                        fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                        lineNumber: 588,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                                lineNumber: 577,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                            lineNumber: 576,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, aff.referrer_email, true, {
                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                                    lineNumber: 570,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                            lineNumber: 568,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
                    lineNumber: 566,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
            lineNumber: 430,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/lifeclock-20251031-141611/app/admin/referrals/page.tsx",
        lineNumber: 429,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__7efffcab._.js.map