module.exports = [
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/punycode [external] (punycode, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("punycode", () => require("punycode"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[project]/lifeclock-20251031-141611/lib/supabase/client.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createClient",
    ()=>createClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/@supabase/ssr/dist/module/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/@supabase/ssr/dist/module/createBrowserClient.js [app-ssr] (ecmascript)");
;
function createClient() {
    // Debug temporaire: vérifier la présence des variables NEXT_PUBLIC_* côté client
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createBrowserClient"])(("TURBOPACK compile-time value", "https://haqxwwynqamhbroidxov.supabase.co"), ("TURBOPACK compile-time value", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhhcXh3d3lucWFtaGJyb2lkeG92Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE4NDE1NzEsImV4cCI6MjA3NzQxNzU3MX0.ZAnwfSwR0gHNz-SUP9B2zWkoL7fur6LyRV0FcPyJMe8"));
}
}),
"[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AdminConversionsPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/lib/supabase/client.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
const AUTH_STORAGE_KEY = "lifeclock-admin-authenticated";
function AdminConversionsPage() {
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const [rows, setRows] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isAuthenticated, setIsAuthenticated] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [username, setUsername] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [password, setPassword] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [authError, setAuthError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        // Vérifier si déjà authentifié dans localStorage
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
    }, []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!isAuthenticated) return;
        const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createClient"])();
        const loadInitial = async ()=>{
            const { data, error } = await supabase.from("conversions").select("event_type,email,session_id,created_at").order("created_at", {
                ascending: true
            });
            if (!error && data) setRows(data);
        };
        loadInitial();
        const channel = supabase.channel("realtime-conversions").on("postgres_changes", {
            event: "INSERT",
            schema: "public",
            table: "conversions"
        }, (payload)=>{
            const rec = payload.new;
            setRows((prev)=>[
                    ...prev,
                    rec
                ]);
        }).subscribe();
        return ()=>{
            supabase.removeChannel(channel);
        };
    }, [
        isAuthenticated
    ]);
    const handleLogout = ()=>{
        setIsAuthenticated(false);
        setUsername("");
        setPassword("");
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
    };
    const handleSubmit = async (e)=>{
        e.preventDefault();
        if (!username || !password) {
            setAuthError("Veuillez remplir tous les champs");
            return;
        }
        try {
            const response = await fetch("/api/admin/auth", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    username,
                    password
                })
            });
            const data = await response.json();
            if (response.ok && data.success) {
                setIsAuthenticated(true);
                setAuthError(null);
                if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
                ;
            } else {
                setAuthError(data.error || "Identifiant ou mot de passe incorrect");
                setPassword("");
            }
        } catch (error) {
            console.error("[admin-auth] Error:", error);
            setAuthError("Erreur de connexion");
            setPassword("");
        }
    };
    const metrics = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        // Par session_id : ensemble de tous les événements pour chaque session
        const sessionEvents = new Map();
        // Construire le mapping des événements par session
        for (const r of rows){
            if (!sessionEvents.has(r.session_id)) {
                sessionEvents.set(r.session_id, new Set());
            }
            sessionEvents.get(r.session_id).add(r.event_type);
        }
        // Compter par type d'événement (sessions uniques)
        const pageSessions = new Set();
        const emailSessionsSet = new Set();
        const quizSessions = new Set();
        // Compter les emails uniques
        const emailSet = new Set();
        const payEmailSet = new Set();
        for (const r of rows){
            if (r.event_type === "page_visit") pageSessions.add(r.session_id);
            if (r.event_type === "quiz_complete") quizSessions.add(r.session_id);
            if (r.event_type === "email_given" && r.email) {
                emailSessionsSet.add(r.session_id);
                emailSet.add(r.email.toLowerCase());
            }
            if (r.event_type === "payment_complete" && r.email) {
                payEmailSet.add(r.email.toLowerCase());
            }
        }
        // Compter les sessions qui ont progressé dans le funnel
        // Sessions qui ont visité ET donné un email
        const sessionsWithEmail = new Set();
        for (const sessionId of pageSessions){
            const events = sessionEvents.get(sessionId);
            if (events?.has("email_given")) {
                sessionsWithEmail.add(sessionId);
            }
        }
        // Sessions qui ont donné un email ET complété le quiz
        const sessionsEmailToQuiz = new Set();
        for (const sessionId of emailSessionsSet){
            const events = sessionEvents.get(sessionId);
            if (events?.has("quiz_complete")) {
                sessionsEmailToQuiz.add(sessionId);
            }
        }
        // Sessions qui ont complété le quiz ET payé
        const sessionsQuizToPay = new Set();
        for (const sessionId of quizSessions){
            const events = sessionEvents.get(sessionId);
            if (events?.has("payment_complete")) {
                sessionsQuizToPay.add(sessionId);
            }
        }
        // Sessions qui ont visité ET payé (global)
        const sessionsVisitedToPaid = new Set();
        for (const sessionId of pageSessions){
            const events = sessionEvents.get(sessionId);
            if (events?.has("payment_complete")) {
                sessionsVisitedToPaid.add(sessionId);
            }
        }
        const visitors = pageSessions.size;
        const emails = emailSet.size;
        const quizzes = quizSessions.size;
        const payments = payEmailSet.size;
        const rate = (num, den)=>den > 0 ? Math.round(num / den * 100) : 0;
        return {
            visitors,
            emails,
            quizzes,
            payments,
            // Taux basés sur les sessions pour un funnel cohérent
            convPageToEmail: rate(sessionsWithEmail.size, visitors),
            convEmailToQuiz: rate(sessionsEmailToQuiz.size, emailSessionsSet.size),
            convQuizToPay: rate(sessionsQuizToPay.size, quizzes),
            convGlobal: rate(sessionsVisitedToPaid.size, visitors)
        };
    }, [
        rows
    ]);
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-screen bg-black text-white flex items-center justify-center",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-gray-400",
                children: "Chargement..."
            }, void 0, false, {
                fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                lineNumber: 206,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
            lineNumber: 205,
            columnNumber: 7
        }, this);
    }
    if (!isAuthenticated) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-screen bg-black text-white flex items-center justify-center",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full max-w-md px-6",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "rounded-xl border border-white/10 bg-black/40 p-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-2xl font-semibold text-white mb-2",
                            children: "Accès Admin"
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                            lineNumber: 216,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-gray-400 text-sm mb-6",
                            children: "Entrez vos identifiants pour accéder au dashboard"
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                            lineNumber: 217,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                            onSubmit: handleSubmit,
                            className: "space-y-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            htmlFor: "username",
                                            className: "block text-sm text-gray-400 mb-2",
                                            children: "Identifiant"
                                        }, void 0, false, {
                                            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                                            lineNumber: 221,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            id: "username",
                                            type: "text",
                                            value: username,
                                            onChange: (e)=>setUsername(e.target.value),
                                            className: "w-full rounded-lg bg-[#2C2C2E] border border-white/10 px-4 py-3 text-white placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                            placeholder: "Votre identifiant",
                                            autoFocus: true
                                        }, void 0, false, {
                                            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                                            lineNumber: 224,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                                    lineNumber: 220,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            htmlFor: "password",
                                            className: "block text-sm text-gray-400 mb-2",
                                            children: "Mot de passe"
                                        }, void 0, false, {
                                            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                                            lineNumber: 236,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            id: "password",
                                            type: "password",
                                            value: password,
                                            onChange: (e)=>setPassword(e.target.value),
                                            className: "w-full rounded-lg bg-[#2C2C2E] border border-white/10 px-4 py-3 text-white placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                            placeholder: "••••••••"
                                        }, void 0, false, {
                                            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                                            lineNumber: 239,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                                    lineNumber: 235,
                                    columnNumber: 15
                                }, this),
                                authError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "rounded-lg bg-red-500/10 border border-red-500/20 px-4 py-3 text-sm text-red-400",
                                    children: authError
                                }, void 0, false, {
                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                                    lineNumber: 250,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "submit",
                                    className: "w-full rounded-lg bg-blue-600 hover:bg-blue-700 px-4 py-3 text-white font-medium transition-colors",
                                    children: "Se connecter"
                                }, void 0, false, {
                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                                    lineNumber: 255,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                            lineNumber: 219,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                    lineNumber: 215,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                lineNumber: 214,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
            lineNumber: 213,
            columnNumber: 7
        }, this);
    }
    const Card = ({ title, value, suffix, subtitle })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "rounded-xl border border-white/10 bg-black/40 p-5",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-sm text-gray-400",
                    children: title
                }, void 0, false, {
                    fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                    lineNumber: 270,
                    columnNumber: 7
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-2 text-3xl font-semibold text-white",
                    children: [
                        value,
                        suffix ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-gray-400 text-xl ml-1",
                            children: suffix
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                            lineNumber: 273,
                            columnNumber: 19
                        }, this) : null
                    ]
                }, void 0, true, {
                    fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                    lineNumber: 271,
                    columnNumber: 7
                }, this),
                subtitle && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-2 text-sm text-gray-500",
                    children: subtitle
                }, void 0, false, {
                    fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                    lineNumber: 276,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
            lineNumber: 269,
            columnNumber: 5
        }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-black text-white",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mx-auto max-w-5xl px-6 py-10",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-between mb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                    className: "text-2xl font-semibold",
                                    children: "Conversions (Temps réel)"
                                }, void 0, false, {
                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                                    lineNumber: 286,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-gray-400 mt-1",
                                    children: "Funnel LifeClock — sessions et emails uniques"
                                }, void 0, false, {
                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                                    lineNumber: 287,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                            lineNumber: 285,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>router.push("/admin/referrals"),
                                    className: "px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 border border-white/10 text-sm text-white transition-colors",
                                    children: "Affiliés"
                                }, void 0, false, {
                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                                    lineNumber: 290,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleLogout,
                                    className: "px-4 py-2 rounded-lg bg-gray-800 hover:bg-gray-700 border border-white/10 text-sm text-gray-300 transition-colors",
                                    children: "Déconnexion"
                                }, void 0, false, {
                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                                    lineNumber: 296,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                            lineNumber: 289,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                    lineNumber: 284,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Card, {
                            title: "Visiteurs page",
                            value: metrics.visitors,
                            subtitle: `${metrics.convGlobal}% de conversion globale`
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                            lineNumber: 306,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Card, {
                            title: "Emails",
                            value: metrics.emails,
                            subtitle: `${metrics.convPageToEmail}% Page → Email`
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                            lineNumber: 311,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Card, {
                            title: "Quiz complétés",
                            value: metrics.quizzes,
                            subtitle: `${metrics.convEmailToQuiz}% Email → Quiz`
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                            lineNumber: 316,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Card, {
                            title: "Paiements",
                            value: metrics.payments,
                            subtitle: `${metrics.convQuizToPay}% Quiz → Paiement`
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                            lineNumber: 321,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                    lineNumber: 305,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Card, {
                            title: "Page → Email",
                            value: metrics.convPageToEmail,
                            suffix: "%"
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                            lineNumber: 329,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Card, {
                            title: "Email → Quiz",
                            value: metrics.convEmailToQuiz,
                            suffix: "%"
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                            lineNumber: 330,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Card, {
                            title: "Quiz → Paiement",
                            value: metrics.convQuizToPay,
                            suffix: "%"
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                            lineNumber: 331,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Card, {
                            title: "Global",
                            value: metrics.convGlobal,
                            suffix: "%"
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                            lineNumber: 332,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                    lineNumber: 328,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-10 rounded-xl border border-white/10 bg-black/40 p-5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-sm text-gray-400",
                            children: "Derniers événements"
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                            lineNumber: 336,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-3 text-sm text-gray-300 space-y-1 max-h-64 overflow-auto",
                            children: rows.slice(-50).reverse().map((r, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center justify-between",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-gray-400",
                                            children: new Date(r.created_at).toLocaleString()
                                        }, void 0, false, {
                                            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                                            lineNumber: 340,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "px-2 py-0.5 rounded bg-white/5 border border-white/10 text-white",
                                            children: r.event_type
                                        }, void 0, false, {
                                            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                                            lineNumber: 341,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-gray-400 truncate max-w-[30%]",
                                            children: r.session_id
                                        }, void 0, false, {
                                            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                                            lineNumber: 344,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-gray-400 truncate max-w-[30%]",
                                            children: r.email || "-"
                                        }, void 0, false, {
                                            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                                            lineNumber: 345,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, i, true, {
                                    fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                                    lineNumber: 339,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                            lineNumber: 337,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
                    lineNumber: 335,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
            lineNumber: 283,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/lifeclock-20251031-141611/app/admin/conversions/page.tsx",
        lineNumber: 282,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__a9f53c31._.js.map