module.exports = [
"[project]/.next-internal/server/app/onboarding/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_onboarding_page_actions_99465896.js.map