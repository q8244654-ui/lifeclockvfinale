module.exports = [
"[project]/app/onboarding/loading.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Loading
]);
function Loading() {
    return null;
}
}),
];

//# sourceMappingURL=app_onboarding_loading_tsx_70d5ca60._.js.map