module.exports = [
"[project]/lifeclock-20251031-141611/.next-internal/server/app/admin/conversions/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=b1a60__next-internal_server_app_admin_conversions_page_actions_e3e47fdf.js.map