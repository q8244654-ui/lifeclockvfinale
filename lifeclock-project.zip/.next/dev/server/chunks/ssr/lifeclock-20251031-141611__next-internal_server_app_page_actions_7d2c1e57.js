module.exports = [
"[project]/lifeclock-20251031-141611/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=lifeclock-20251031-141611__next-internal_server_app_page_actions_7d2c1e57.js.map