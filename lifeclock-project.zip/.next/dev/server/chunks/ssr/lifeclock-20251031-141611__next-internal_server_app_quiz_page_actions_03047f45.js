module.exports = [
"[project]/lifeclock-20251031-141611/.next-internal/server/app/quiz/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=lifeclock-20251031-141611__next-internal_server_app_quiz_page_actions_03047f45.js.map