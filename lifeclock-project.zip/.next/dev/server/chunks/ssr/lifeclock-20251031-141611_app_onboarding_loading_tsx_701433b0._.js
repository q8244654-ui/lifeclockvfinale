module.exports = [
"[project]/lifeclock-20251031-141611/app/onboarding/loading.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Loading
]);
function Loading() {
    return null;
}
}),
];

//# sourceMappingURL=lifeclock-20251031-141611_app_onboarding_loading_tsx_701433b0._.js.map