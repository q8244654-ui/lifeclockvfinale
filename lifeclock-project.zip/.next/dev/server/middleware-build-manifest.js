globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/bbd6e_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0b63d49a._.js",
    "static/chunks/bbd6e_next_dist_compiled_react-dom_1427af18._.js",
    "static/chunks/bbd6e_next_dist_compiled_react-server-dom-turbopack_c7985410._.js",
    "static/chunks/bbd6e_next_dist_compiled_next-devtools_index_f78f1461.js",
    "static/chunks/bbd6e_next_dist_compiled_2aae1744._.js",
    "static/chunks/bbd6e_next_dist_client_04f8643b._.js",
    "static/chunks/bbd6e_next_dist_9a178af7._.js",
    "static/chunks/bbd6e_@swc_helpers_cjs_d8c36acf._.js",
    "static/chunks/lifeclock-20251031-141611_a0ff3932._.js",
    "static/chunks/turbopack-lifeclock-20251031-141611_5a59afc8._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];