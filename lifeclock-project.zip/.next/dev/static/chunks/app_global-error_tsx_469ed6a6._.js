(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_dist_48ab86c2._.js",
  "static/chunks/app_global-error_tsx_29b32c6b._.js"
],
    source: "dynamic"
});
