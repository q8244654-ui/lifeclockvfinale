(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/lifeclock-20251031-141611/lib/utils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cn",
    ()=>cn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-client] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lifeclock-20251031-141611/components/chat-message.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ChatMessage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function ChatMessage({ role, text, delay = 0, messageType = "normal", showReadReceipt = false, timestamp }) {
    _s();
    const isAssistant = role === "assistant";
    const [showReceipt, setShowReceipt] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatMessage.useEffect": ()=>{
            if (showReadReceipt && !isAssistant) {
                const timer = setTimeout({
                    "ChatMessage.useEffect.timer": ()=>{
                        setShowReceipt(true);
                    }
                }["ChatMessage.useEffect.timer"], 1500);
                return ({
                    "ChatMessage.useEffect": ()=>clearTimeout(timer)
                })["ChatMessage.useEffect"];
            }
        }
    }["ChatMessage.useEffect"], [
        showReadReceipt,
        isAssistant
    ]);
    const messageStyles = {
        normal: {
            background: "#2C2C2E",
            color: "#E5E5EA",
            glow: "none",
            haloColor: "transparent",
            tailColor: "#2C2C2E"
        },
        motivation: {
            background: "linear-gradient(135deg, #F97316 0%, #FB923C 100%)",
            color: "#FFFFFF",
            glow: "0 0 15px rgba(249, 115, 22, 0.5)",
            haloColor: "#F97316",
            tailColor: "#F97316"
        },
        revelation: {
            background: "linear-gradient(135deg, #EF4444 0%, #F87171 100%)",
            color: "#FFFFFF",
            glow: "0 0 15px rgba(239, 68, 68, 0.5)",
            haloColor: "#EF4444",
            tailColor: "#EF4444"
        },
        introspection: {
            background: "linear-gradient(135deg, #EAB308 0%, #FCD34D 100%)",
            color: "#000000",
            glow: "0 0 15px rgba(234, 179, 8, 0.5)",
            haloColor: "#EAB308",
            tailColor: "#EAB308"
        },
        humor: {
            background: "linear-gradient(135deg, #22C55E 0%, #4ADE80 100%)",
            color: "#FFFFFF",
            glow: "0 0 15px rgba(34, 197, 94, 0.5)",
            haloColor: "#22C55E",
            tailColor: "#22C55E"
        }
    };
    const style = isAssistant && messageType !== "normal" ? messageStyles[messageType] : messageStyles.normal;
    if (isAssistant && messageType !== "normal") {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            className: "flex w-full justify-start",
            initial: {
                opacity: 0,
                y: 10,
                scale: 0.95
            },
            animate: {
                opacity: 1,
                y: 0,
                scale: 1
            },
            transition: {
                duration: 0.5,
                delay,
                type: "spring",
                stiffness: 200,
                damping: 20
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                        className: "absolute inset-0 -z-10 blur-xl",
                        animate: {
                            opacity: [
                                0.4,
                                0.6,
                                0.4
                            ],
                            scale: [
                                1,
                                1.15,
                                1
                            ]
                        },
                        transition: {
                            duration: 2.5,
                            repeat: Number.POSITIVE_INFINITY,
                            ease: "easeInOut"
                        },
                        style: {
                            background: `radial-gradient(circle, ${style.haloColor}50 0%, transparent 70%)`
                        }
                    }, void 0, false, {
                        fileName: "[project]/lifeclock-20251031-141611/components/chat-message.tsx",
                        lineNumber: 92,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                        className: "relative max-w-[80%] rounded-3xl px-4 py-2 text-pretty",
                        style: {
                            background: style.background,
                            color: style.color,
                            fontSize: "17px",
                            lineHeight: "22px",
                            boxShadow: style.glow
                        },
                        whileHover: {
                            scale: 1.02
                        },
                        transition: {
                            type: "spring",
                            stiffness: 300
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: text
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/components/chat-message.tsx",
                            lineNumber: 119,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/lifeclock-20251031-141611/components/chat-message.tsx",
                        lineNumber: 107,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/lifeclock-20251031-141611/components/chat-message.tsx",
                lineNumber: 90,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/lifeclock-20251031-141611/components/chat-message.tsx",
            lineNumber: 78,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex w-full flex-col", isAssistant ? "items-start" : "items-end"),
        initial: {
            opacity: 0,
            y: 10
        },
        animate: {
            opacity: 1,
            y: 0
        },
        transition: {
            duration: 0.3,
            delay,
            type: "spring",
            stiffness: 260,
            damping: 20
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("max-w-[80%] rounded-3xl px-4 py-2 text-pretty", isAssistant ? "imessage-bubble-assistant" : "imessage-bubble-user"),
                style: {
                    fontSize: "17px",
                    lineHeight: "22px"
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: text
                }, void 0, false, {
                    fileName: "[project]/lifeclock-20251031-141611/components/chat-message.tsx",
                    lineNumber: 149,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/lifeclock-20251031-141611/components/chat-message.tsx",
                lineNumber: 139,
                columnNumber: 7
            }, this),
            !isAssistant && showReceipt && timestamp && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                className: "mt-0.5 pr-1.5 text-right",
                initial: {
                    opacity: 0,
                    y: 3
                },
                animate: {
                    opacity: [
                        0,
                        1,
                        0.7,
                        1
                    ],
                    y: 0
                },
                transition: {
                    opacity: {
                        duration: 0.6,
                        times: [
                            0,
                            0.5,
                            0.7,
                            1
                        ]
                    },
                    y: {
                        duration: 0.6
                    }
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-[12px] text-[#8E8E93]",
                    style: {
                        fontFamily: "SF Pro Text, -apple-system, system-ui, sans-serif"
                    },
                    children: [
                        "read at ",
                        timestamp
                    ]
                }, void 0, true, {
                    fileName: "[project]/lifeclock-20251031-141611/components/chat-message.tsx",
                    lineNumber: 165,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/lifeclock-20251031-141611/components/chat-message.tsx",
                lineNumber: 153,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/lifeclock-20251031-141611/components/chat-message.tsx",
        lineNumber: 127,
        columnNumber: 5
    }, this);
}
_s(ChatMessage, "XEUhuVutyOic/LAYNs6MVJ42mq4=");
_c = ChatMessage;
var _c;
__turbopack_context__.k.register(_c, "ChatMessage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lifeclock-20251031-141611/components/typing-indicator.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TypingIndicator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
"use client";
;
;
function TypingIndicator() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex justify-start",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center gap-1.5 rounded-3xl bg-[#2C2C2E] px-4 py-2.5",
            children: [
                0,
                1,
                2
            ].map((i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    className: "h-2 w-2 rounded-full imessage-typing-dot",
                    animate: {
                        y: [
                            0,
                            -4,
                            0
                        ],
                        opacity: [
                            0.5,
                            1,
                            0.5
                        ]
                    },
                    transition: {
                        duration: 0.8,
                        repeat: Number.POSITIVE_INFINITY,
                        delay: i * 0.15,
                        ease: "easeInOut"
                    }
                }, i, false, {
                    fileName: "[project]/lifeclock-20251031-141611/components/typing-indicator.tsx",
                    lineNumber: 10,
                    columnNumber: 11
                }, this))
        }, void 0, false, {
            fileName: "[project]/lifeclock-20251031-141611/components/typing-indicator.tsx",
            lineNumber: 8,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/lifeclock-20251031-141611/components/typing-indicator.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
_c = TypingIndicator;
var _c;
__turbopack_context__.k.register(_c, "TypingIndicator");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lifeclock-20251031-141611/components/phase-transition.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PhaseTransition
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function PhaseTransition({ phase, onComplete }) {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PhaseTransition.useEffect": ()=>{
            try {
                const audio = new Audio(`/sounds/${phase.sound}`);
                audio.volume = 0.6;
                audio.play().catch({
                    "PhaseTransition.useEffect": ()=>{}
                }["PhaseTransition.useEffect"]);
            } catch (e) {}
            // Play heartbeat sound
            try {
                const heartbeat = new Audio("/sounds/heartbeat.mp3");
                heartbeat.volume = 0.5;
                heartbeat.loop = true;
                heartbeat.play().catch({
                    "PhaseTransition.useEffect": ()=>{}
                }["PhaseTransition.useEffect"]);
                // Stop heartbeat after transition
                setTimeout({
                    "PhaseTransition.useEffect": ()=>{
                        heartbeat.pause();
                        heartbeat.currentTime = 0;
                    }
                }["PhaseTransition.useEffect"], 9000);
            } catch (e) {}
            // Long vibration
            if (typeof navigator !== "undefined" && navigator.vibrate) {
                navigator.vibrate(150);
            }
            const timer = setTimeout({
                "PhaseTransition.useEffect.timer": ()=>{
                    onComplete();
                }
            }["PhaseTransition.useEffect.timer"], 9000);
            return ({
                "PhaseTransition.useEffect": ()=>clearTimeout(timer)
            })["PhaseTransition.useEffect"];
        }
    }["PhaseTransition.useEffect"], [
        phase,
        onComplete
    ]);
    const confettiColors = [
        "#0A84FF",
        "#7C3AED",
        "#EC4899",
        "#F97316",
        "#22C55E",
        "#FFD60A",
        "#06B6D4",
        "#DC2626"
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        transition: {
            duration: 1
        },
        className: "fixed inset-0 z-50 flex items-center justify-center",
        style: {
            backgroundColor: "#000000"
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                className: "absolute inset-0",
                animate: {
                    background: `radial-gradient(circle at 50% 50%, ${phase.color}60 0%, ${phase.color}20 40%, transparent 70%)`,
                    scale: [
                        1,
                        1.05,
                        1,
                        1.08,
                        1
                    ]
                },
                transition: {
                    duration: 1.2,
                    repeat: Number.POSITIVE_INFINITY,
                    ease: [
                        0.4,
                        0,
                        0.6,
                        1
                    ],
                    times: [
                        0,
                        0.2,
                        0.4,
                        0.6,
                        1
                    ]
                },
                style: {
                    filter: "blur(120px)"
                }
            }, void 0, false, {
                fileName: "[project]/lifeclock-20251031-141611/components/phase-transition.tsx",
                lineNumber: 71,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 overflow-hidden",
                children: Array.from({
                    length: 25
                }).map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                        className: "absolute rounded-full",
                        style: {
                            backgroundColor: confettiColors[Math.floor(Math.random() * confettiColors.length)],
                            width: Math.random() * 8 + 4,
                            height: Math.random() * 8 + 4,
                            left: `${Math.random() * 100}%`,
                            bottom: "-5%",
                            opacity: 0.6
                        },
                        animate: {
                            y: [
                                0,
                                -window.innerHeight - 100
                            ],
                            opacity: [
                                0,
                                0.8,
                                0
                            ],
                            scale: [
                                0.5,
                                1,
                                0.5
                            ]
                        },
                        transition: {
                            duration: 4 + Math.random() * 3,
                            delay: Math.random() * 2,
                            ease: "easeOut"
                        }
                    }, i, false, {
                        fileName: "[project]/lifeclock-20251031-141611/components/phase-transition.tsx",
                        lineNumber: 91,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/lifeclock-20251031-141611/components/phase-transition.tsx",
                lineNumber: 89,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                className: "relative z-10 mx-4 max-w-lg text-center",
                initial: {
                    scale: 0.9,
                    opacity: 0
                },
                animate: {
                    scale: [
                        1,
                        1.02,
                        1,
                        1.03,
                        1
                    ],
                    opacity: 1
                },
                transition: {
                    scale: {
                        duration: 1.2,
                        repeat: Number.POSITIVE_INFINITY,
                        ease: [
                            0.4,
                            0,
                            0.6,
                            1
                        ],
                        times: [
                            0,
                            0.2,
                            0.4,
                            0.6,
                            1
                        ]
                    },
                    opacity: {
                        duration: 1.2,
                        delay: 0.3,
                        ease: "easeOut"
                    }
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                        className: "mb-6 text-sm font-medium uppercase tracking-wider",
                        style: {
                            color: phase.color
                        },
                        initial: {
                            opacity: 0,
                            y: 20
                        },
                        animate: {
                            opacity: 1,
                            y: 0
                        },
                        transition: {
                            delay: 0.5,
                            duration: 0.8
                        },
                        children: [
                            "Phase ",
                            phase.id
                        ]
                    }, void 0, true, {
                        fileName: "[project]/lifeclock-20251031-141611/components/phase-transition.tsx",
                        lineNumber: 139,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].h1, {
                        className: "mb-4 text-balance font-rounded text-2xl font-bold leading-tight text-white",
                        initial: {
                            opacity: 0,
                            y: 20
                        },
                        animate: {
                            opacity: 1,
                            y: 0
                        },
                        transition: {
                            delay: 0.8,
                            duration: 0.8
                        },
                        children: phase.text
                    }, void 0, false, {
                        fileName: "[project]/lifeclock-20251031-141611/components/phase-transition.tsx",
                        lineNumber: 150,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].p, {
                        className: "text-base font-medium text-white/60",
                        initial: {
                            opacity: 0,
                            y: 20
                        },
                        animate: {
                            opacity: 1,
                            y: 0
                        },
                        transition: {
                            delay: 1.1,
                            duration: 0.8
                        },
                        children: phase.name
                    }, void 0, false, {
                        fileName: "[project]/lifeclock-20251031-141611/components/phase-transition.tsx",
                        lineNumber: 160,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                        className: "mx-auto mt-8 h-px w-24",
                        style: {
                            background: `linear-gradient(90deg, transparent, ${phase.color}, transparent)`,
                            boxShadow: `0 0 20px ${phase.color}`
                        },
                        initial: {
                            opacity: 0,
                            scaleX: 0
                        },
                        animate: {
                            opacity: 1,
                            scaleX: 1
                        },
                        transition: {
                            delay: 1.4,
                            duration: 1
                        }
                    }, void 0, false, {
                        fileName: "[project]/lifeclock-20251031-141611/components/phase-transition.tsx",
                        lineNumber: 170,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/lifeclock-20251031-141611/components/phase-transition.tsx",
                lineNumber: 117,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/lifeclock-20251031-141611/components/phase-transition.tsx",
        lineNumber: 63,
        columnNumber: 5
    }, this);
}
_s(PhaseTransition, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = PhaseTransition;
var _c;
__turbopack_context__.k.register(_c, "PhaseTransition");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lifeclock-20251031-141611/lib/supabase/client.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createClient",
    ()=>createClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/@supabase/ssr/dist/module/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/@supabase/ssr/dist/module/createBrowserClient.js [app-client] (ecmascript)");
;
function createClient() {
    // Debug temporaire: vérifier la présence des variables NEXT_PUBLIC_* côté client
    if ("TURBOPACK compile-time truthy", 1) {
        try {
            // N'affiche pas les valeurs complètes en console
            // Affiche uniquement des indicateurs pour diagnostiquer le chargement des variables
            // et un préfixe tronqué pour l'URL (non sensible)
            // Ces logs peuvent être retirés une fois le problème résolu
            // eslint-disable-next-line no-console
            console.log("[Supabase] URL défini:", Boolean(("TURBOPACK compile-time value", "https://haqxwwynqamhbroidxov.supabase.co")), "prefix:", ("TURBOPACK compile-time value", "https://haqxwwynqamhbroidxov.supabase.co")?.slice(0, 30) || "");
            // eslint-disable-next-line no-console
            console.log("[Supabase] ANON_KEY défini:", Boolean(("TURBOPACK compile-time value", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhhcXh3d3lucWFtaGJyb2lkeG92Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE4NDE1NzEsImV4cCI6MjA3NzQxNzU3MX0.ZAnwfSwR0gHNz-SUP9B2zWkoL7fur6LyRV0FcPyJMe8")));
        } catch  {}
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBrowserClient"])(("TURBOPACK compile-time value", "https://haqxwwynqamhbroidxov.supabase.co"), ("TURBOPACK compile-time value", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhhcXh3d3lucWFtaGJyb2lkeG92Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE4NDE1NzEsImV4cCI6MjA3NzQxNzU3MX0.ZAnwfSwR0gHNz-SUP9B2zWkoL7fur6LyRV0FcPyJMe8"));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lifeclock-20251031-141611/lib/generate-referral-code.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Generate a unique referral code based on email
__turbopack_context__.s([
    "generateReferralCode",
    ()=>generateReferralCode
]);
function generateReferralCode(email) {
    // Create a simple hash from email
    const hash = email.split("").reduce((acc, char)=>{
        return char.charCodeAt(0) + ((acc << 5) - acc);
    }, 0);
    // Convert to base36 and take first 8 characters
    const code = Math.abs(hash).toString(36).toUpperCase().slice(0, 8);
    // Add random suffix for uniqueness
    const suffix = Math.random().toString(36).substring(2, 5).toUpperCase();
    return `${code}${suffix}`;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lifeclock-20251031-141611/lib/tracking.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getSessionId",
    ()=>getSessionId,
    "hasTrackedEvent",
    ()=>hasTrackedEvent,
    "trackEvent",
    ()=>trackEvent,
    "tracking",
    ()=>tracking
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/lib/supabase/client.ts [app-client] (ecmascript)");
;
const SESSION_KEY = "lifeclock-session-id";
const TRACKED_PREFIX = "lifeclock-tracked-";
const EMAIL_TRACKED_PREFIX = "lifeclock-email-tracked-";
function getSessionId() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        const existing = localStorage.getItem(SESSION_KEY);
        if (existing) return existing;
        const id = typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}_${Math.random().toString(36).slice(2)}`;
        localStorage.setItem(SESSION_KEY, id);
        return id;
    } catch  {
        return "";
    }
}
function hasTrackedEvent(eventType) {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        const key = `${TRACKED_PREFIX}${eventType}`;
        return localStorage.getItem(key) === "1";
    } catch  {
        return false;
    }
}
function markTracked(eventType) {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        const key = `${TRACKED_PREFIX}${eventType}`;
        localStorage.setItem(key, "1");
    } catch  {}
}
function hasTrackedEmail(eventType, email) {
    if (("TURBOPACK compile-time value", "object") === "undefined" || !email) return false;
    try {
        const key = `${EMAIL_TRACKED_PREFIX}${eventType}:${email.toLowerCase()}`;
        return localStorage.getItem(key) === "1";
    } catch  {
        return false;
    }
}
function markEmailTracked(eventType, email) {
    if (("TURBOPACK compile-time value", "object") === "undefined" || !email) return;
    try {
        const key = `${EMAIL_TRACKED_PREFIX}${eventType}:${email.toLowerCase()}`;
        localStorage.setItem(key, "1");
    } catch  {}
}
async function trackEvent(eventType, email) {
    try {
        const sessionId = getSessionId();
        if (!sessionId) return;
        // Client-side dedupe guards
        if ((eventType === "page_visit" || eventType === "quiz_complete") && hasTrackedEvent(eventType)) {
            return;
        }
        if ((eventType === "email_given" || eventType === "payment_complete") && hasTrackedEmail(eventType, email)) {
            return;
        }
        const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
        const { error } = await supabase.from("conversions").insert({
            event_type: eventType,
            email: email || null,
            session_id: sessionId
        });
        if (error) {
            // Do not break UX; silent failure
            // eslint-disable-next-line no-console
            console.log("[tracking] Error:", error.message);
            return;
        }
        // Mark as tracked locally on success
        if (eventType === "page_visit" || eventType === "quiz_complete") {
            markTracked(eventType);
        }
        if (eventType === "email_given" || eventType === "payment_complete") {
            markEmailTracked(eventType, email);
        }
        // eslint-disable-next-line no-console
        console.log(`[tracking] Tracked ${eventType}`);
    } catch (e) {
        // eslint-disable-next-line no-console
        console.log("[tracking] Exception", e);
    }
}
const tracking = {
    pageVisit: async ()=>{
        await trackEvent("page_visit");
    },
    emailGiven: async (email)=>{
        await trackEvent("email_given", email);
    },
    quizComplete: async (email)=>{
        // If email available in localStorage, include it to improve attribution
        let userEmail = email || null;
        try {
            if (!userEmail && ("TURBOPACK compile-time value", "object") !== "undefined") {
                const onboarding = localStorage.getItem("lifeclockOnboarding");
                if (onboarding) {
                    const parsed = JSON.parse(onboarding);
                    userEmail = parsed?.email || null;
                }
            }
        } catch  {}
        await trackEvent("quiz_complete", userEmail || null);
    },
    paymentComplete: async (email)=>{
        await trackEvent("payment_complete", email);
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lifeclock-20251031-141611/app/onboarding/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>OnboardingPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$components$2f$chat$2d$message$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/components/chat-message.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$components$2f$typing$2d$indicator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/components/typing-indicator.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$components$2f$phase$2d$transition$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/components/phase-transition.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/lib/supabase/client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$lib$2f$generate$2d$referral$2d$code$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/lib/generate-referral-code.ts [app-client] (ecmascript)"); // Import referral code generator
var __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$lib$2f$tracking$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lifeclock-20251031-141611/lib/tracking.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
function OnboardingPage() {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const [messages, setMessages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [currentStep, setCurrentStep] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("invocation");
    const [isTyping, setIsTyping] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [canAnswer, setCanAnswer] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [inputValue, setInputValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [userData, setUserData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const messagesEndRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const scrollContainerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [isAtBottom, setIsAtBottom] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const autoScrollTimeoutRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [lastUserMessageIndex, setLastUserMessageIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(-1);
    const [hasStarted, setHasStarted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showPhaseTransition, setShowPhaseTransition] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false) // Add phase transition state
    ;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OnboardingPage.useEffect": ()=>{
            if (hasStarted) return;
            const refCode = searchParams.get("ref");
            if (refCode) {
                localStorage.setItem("lifeclock-referral-code", refCode);
                console.log("[v0] Referral code captured:", refCode);
            }
            // Track page visit once per session
            ;
            ({
                "OnboardingPage.useEffect": async ()=>{
                    try {
                        await __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$lib$2f$tracking$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tracking"].pageVisit();
                    } catch  {}
                }
            })["OnboardingPage.useEffect"]();
            setHasStarted(true);
            const timer = setTimeout({
                "OnboardingPage.useEffect.timer": ()=>{
                    startInvocation();
                }
            }["OnboardingPage.useEffect.timer"], 1000);
            return ({
                "OnboardingPage.useEffect": ()=>clearTimeout(timer)
            })["OnboardingPage.useEffect"];
        }
    }["OnboardingPage.useEffect"], []); // Empty dependency array to run only once
    // Auto-scroll system: waits ~400ms to sync with animations, scrolls only if user is at bottom
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OnboardingPage.useEffect": ()=>{
            if (!scrollContainerRef.current) return;
            if (!isAtBottom) return;
            if (autoScrollTimeoutRef.current) {
                clearTimeout(autoScrollTimeoutRef.current);
            }
            autoScrollTimeoutRef.current = setTimeout({
                "OnboardingPage.useEffect": ()=>{
                    const el = scrollContainerRef.current;
                    if (!el) return;
                    // Double-check user still at bottom just before scrolling
                    const threshold = 40;
                    const atBottomNow = el.scrollTop + el.clientHeight >= el.scrollHeight - threshold;
                    if (atBottomNow) {
                        el.scrollTo({
                            top: el.scrollHeight,
                            behavior: "smooth"
                        });
                    }
                }
            }["OnboardingPage.useEffect"], 400);
            return ({
                "OnboardingPage.useEffect": ()=>{
                    if (autoScrollTimeoutRef.current) {
                        clearTimeout(autoScrollTimeoutRef.current);
                    }
                }
            })["OnboardingPage.useEffect"];
        }
    }["OnboardingPage.useEffect"], [
        messages,
        isTyping,
        isAtBottom
    ]);
    // Track whether user is near bottom to avoid interrupting reading
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OnboardingPage.useEffect": ()=>{
            const el = scrollContainerRef.current;
            if (!el) return;
            const handleScroll = {
                "OnboardingPage.useEffect.handleScroll": ()=>{
                    const threshold = 40;
                    const atBottom = el.scrollTop + el.clientHeight >= el.scrollHeight - threshold;
                    setIsAtBottom(atBottom);
                }
            }["OnboardingPage.useEffect.handleScroll"];
            // Prime state on mount and whenever content size changes
            handleScroll();
            el.addEventListener("scroll", handleScroll, {
                passive: true
            });
            window.addEventListener("resize", handleScroll);
            return ({
                "OnboardingPage.useEffect": ()=>{
                    el.removeEventListener("scroll", handleScroll);
                    window.removeEventListener("resize", handleScroll);
                }
            })["OnboardingPage.useEffect"];
        }
    }["OnboardingPage.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OnboardingPage.useEffect": ()=>{
            if (canAnswer && inputRef.current) {
                inputRef.current.focus();
            }
        }
    }["OnboardingPage.useEffect"], [
        canAnswer
    ]);
    const playSound = (sound)=>{
        try {
            const audio = new Audio(`/sounds/${sound}.mp3`);
            audio.volume = 0.3;
            audio.play().catch(()=>{});
        } catch (e) {}
    };
    const vibrate = (duration)=>{
        if (typeof navigator !== "undefined" && navigator.vibrate) {
            navigator.vibrate(duration);
        }
    };
    const getCurrentTime = ()=>{
        const now = new Date();
        return `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}`;
    };
    const addBotMessage = (text, callback)=>{
        setIsTyping(true);
        const typingDelay = Math.random() * 700 + 600;
        setTimeout(()=>{
            setMessages((prev)=>[
                    ...prev,
                    {
                        role: "assistant",
                        text
                    }
                ]);
            setIsTyping(false);
            playSound("pop");
            vibrate(40);
            if (callback) {
                setTimeout(callback, 800);
            }
        }, typingDelay);
    };
    const startInvocation = ()=>{
        addBotMessage("Uh...", ()=>{
            addBotMessage("What are you doing here?", ()=>{
                addBotMessage("No, seriously.", ()=>{
                    addBotMessage("Why are you here, now, at this precise moment?", ()=>{
                        addBotMessage("Most people spend their lives running from these kinds of questions.", ()=>{
                            addBotMessage("You came looking for them.", ()=>{
                                addBotMessage("Interesting.", ()=>{
                                    addBotMessage("Well. Since you're here...", ()=>{
                                        addBotMessage("I'm LifeClock.", ()=>{
                                            addBotMessage("And if you stay, I'll show you something few people have the courage to see:", ()=>{
                                                addBotMessage("You. The real you.", ()=>{
                                                    addBotMessage("Not the image you project.", ()=>{
                                                        addBotMessage("Not the version you tell.", ()=>{
                                                            addBotMessage("You.", ()=>{
                                                                addBotMessage("So... are you staying?", ()=>{
                                                                    addBotMessage("Or do you prefer to keep pretending?", ()=>{
                                                                        setCanAnswer(true);
                                                                    });
                                                                });
                                                            });
                                                        });
                                                    });
                                                });
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    };
    const handleInvocationChoice = (choice)=>{
        if (!canAnswer) return;
        playSound("pop");
        vibrate(40);
        setCanAnswer(false);
        const userMessage = {
            role: "user",
            text: choice,
            timestamp: getCurrentTime(),
            showReadReceipt: true
        };
        setMessages((prev)=>{
            const newMessages = [
                ...prev,
                userMessage
            ];
            setLastUserMessageIndex(newMessages.length - 1);
            return newMessages;
        });
        addBotMessage("Perfect.", ()=>{
            setMessages((prev)=>prev.map((msg, idx)=>idx === lastUserMessageIndex ? {
                        ...msg,
                        showReadReceipt: false
                    } : msg));
            addBotMessage("What's your first name?", ()=>{
                setCurrentStep("name");
                setCanAnswer(true);
            });
        });
    };
    const handleNameSubmit = (name)=>{
        playSound("pop");
        vibrate(40);
        setCanAnswer(false);
        const userMessage = {
            role: "user",
            text: name,
            timestamp: getCurrentTime(),
            showReadReceipt: true
        };
        setMessages((prev)=>{
            const newMessages = [
                ...prev,
                userMessage
            ];
            setLastUserMessageIndex(newMessages.length - 1);
            return newMessages;
        });
        setUserData((prev)=>({
                ...prev,
                name
            }));
        let response = "";
        if (name.length <= 4) {
            response = `Nice to meet you, ${name}. Short and clear — like a spark ready to strike.`;
        } else if (name.length >= 8) {
            response = `Nice to meet you, ${name}. Long and deep — a wave that never fades.`;
        } else {
            response = `Nice to meet you, ${name}. Your name carries a rare vibration.`;
        }
        addBotMessage(response, ()=>{
            setMessages((prev)=>prev.map((msg, idx)=>idx === lastUserMessageIndex ? {
                        ...msg,
                        showReadReceipt: false
                    } : msg));
            addBotMessage(`How old are you, ${name}?`, ()=>{
                setCurrentStep("age");
                setCanAnswer(true);
            });
        });
    };
    const handleAgeSubmit = (ageStr)=>{
        const age = Number(ageStr);
        if (isNaN(age) || age < 13 || age > 120) {
            addBotMessage("I didn't understand. Enter a valid age.");
            return;
        }
        playSound("pop");
        vibrate(40);
        setCanAnswer(false);
        const userMessage = {
            role: "user",
            text: ageStr,
            timestamp: getCurrentTime(),
            showReadReceipt: true
        };
        setMessages((prev)=>{
            const newMessages = [
                ...prev,
                userMessage
            ];
            setLastUserMessageIndex(newMessages.length - 1);
            return newMessages;
        });
        setUserData((prev)=>({
                ...prev,
                age
            }));
        let response = "";
        if (age < 20) {
            response = "At the dawn of fire — you're just entering the world of conscious beings.";
        } else if (age < 30) {
            response = `${age} years old... The years when you choose what you'll become: flame or ash.`;
        } else if (age < 40) {
            response = `${age} years old. The decade of irreversible choices, where you sculpt your destiny.`;
        } else if (age < 60) {
            response = `${age} years old. The age of reckonings and rebirths.`;
        } else {
            response = `${age} years old. The time of silent mirrors, where every second becomes a sacred memory.`;
        }
        addBotMessage(response, ()=>{
            setMessages((prev)=>prev.map((msg, idx)=>idx === lastUserMessageIndex ? {
                        ...msg,
                        showReadReceipt: false
                    } : msg));
            addBotMessage("How do you define yourself?", ()=>{
                setCurrentStep("gender");
                setCanAnswer(true);
            });
        });
    };
    const handleGenderChoice = (gender)=>{
        if (!canAnswer) return;
        playSound("pop");
        vibrate(40);
        setCanAnswer(false);
        const userMessage = {
            role: "user",
            text: gender,
            timestamp: getCurrentTime(),
            showReadReceipt: true
        };
        setMessages((prev)=>{
            const newMessages = [
                ...prev,
                userMessage
            ];
            setLastUserMessageIndex(newMessages.length - 1);
            return newMessages;
        });
        setUserData((prev)=>({
                ...prev,
                gender
            }));
        let response = "";
        if (gender === "Man 🧠") {
            response = "Your energy is solar, anchored in movement and creation.";
        } else if (gender === "Woman 💫") {
            response = "Your energy is lunar, fluid, guided by cycle and intuition.";
        }
        addBotMessage(response, ()=>{
            setMessages((prev)=>prev.map((msg, idx)=>idx === lastUserMessageIndex ? {
                        ...msg,
                        showReadReceipt: false
                    } : msg));
            addBotMessage(`Last thing, ${userData.name}.`, ()=>{
                addBotMessage("To send you your complete report, I need your email.", ()=>{
                    addBotMessage("(Promise, no spam. Just your LifeClock.)", ()=>{
                        setCurrentStep("email");
                        setCanAnswer(true);
                    });
                });
            });
        });
    };
    const handleEmailSubmit = (email)=>{
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            addBotMessage("Hmm, this email doesn't seem correct.");
            return;
        }
        // Track email given (by unique email)
        ;
        (async ()=>{
            try {
                await __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$lib$2f$tracking$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tracking"].emailGiven(email);
            } catch  {}
        })();
        playSound("pop");
        vibrate(40);
        setCanAnswer(false);
        const userMessage = {
            role: "user",
            text: email,
            timestamp: getCurrentTime(),
            showReadReceipt: true
        };
        setMessages((prev)=>{
            const newMessages = [
                ...prev,
                userMessage
            ];
            setLastUserMessageIndex(newMessages.length - 1);
            return newMessages;
        });
        setUserData((prev)=>({
                ...prev,
                email
            }));
        addBotMessage(`Perfect, ${userData.name}.`, ()=>{
            setMessages((prev)=>prev.map((msg, idx)=>idx === lastUserMessageIndex ? {
                        ...msg,
                        showReadReceipt: false
                    } : msg));
            const signature = `${userData.name?.toUpperCase()}-${(userData.age || 0) * 3}-${userData.gender?.[0] || "X"}`;
            setUserData((prev)=>({
                    ...prev,
                    signature
                }));
            addBotMessage("Your clock is synchronized.", ()=>{
                addBotMessage(`Your temporal signature: ${signature}`, ()=>{
                    addBotMessage(`Before you: 10 doors.\nEach reveals a facet of your being.`, ()=>{
                        addBotMessage("The journey takes 15 minutes.", ()=>{
                            addBotMessage("But what you'll discover will last a lifetime.", ()=>{
                                const readyQuestion = userData.gender === "Man 🧠" ? "Are you ready to cross the first door?" : "Are you ready to cross the first door?";
                                addBotMessage(readyQuestion, ()=>{
                                    addBotMessage(`The first Door opens now. 🌒`, ()=>{
                                        const finalData = {
                                            name: userData.name || "",
                                            age: userData.age || 0,
                                            gender: userData.gender || "",
                                            email: email,
                                            signature,
                                            referral_code: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$lib$2f$generate$2d$referral$2d$code$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateReferralCode"])(email)
                                        };
                                        localStorage.setItem("lifeclockOnboarding", JSON.stringify(finalData));
                                        const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
                                        (async ()=>{
                                            try {
                                                const { error } = await supabase.from("onboarding_data").insert({
                                                    name: finalData.name,
                                                    age: finalData.age,
                                                    gender: finalData.gender,
                                                    email: finalData.email,
                                                    referral_code: finalData.referral_code
                                                });
                                                if (error) {
                                                    console.error("[v0] Error saving to Supabase:", {
                                                        message: error.message,
                                                        details: error?.details,
                                                        hint: error?.hint,
                                                        code: error?.code
                                                    });
                                                } else {
                                                    console.log("[v0] Onboarding data saved to Supabase");
                                                }
                                            } catch (e) {
                                                console.error("[v0] Exception saving to Supabase:", e);
                                            }
                                        })();
                                        const refCode = localStorage.getItem("lifeclock-referral-code");
                                        if (refCode) {
                                            supabase.from("onboarding_data").select("email").eq("referral_code", refCode).single().then(({ data: referrerData, error: referrerError })=>{
                                                if (!referrerError && referrerData) {
                                                    supabase.from("referrals").insert({
                                                        referrer_email: referrerData.email,
                                                        referrer_code: refCode,
                                                        referred_email: finalData.email,
                                                        status: "pending"
                                                    }).then(({ error: refError })=>{
                                                        if (refError) {
                                                            console.error("[v0] Error tracking referral:", refError);
                                                        } else {
                                                            console.log("[v0] Referral tracked successfully");
                                                        }
                                                    });
                                                }
                                            });
                                        }
                                        setTimeout(()=>{
                                            playSound("complete");
                                            vibrate(80);
                                            setShowPhaseTransition(true);
                                        }, 2000);
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    };
    const handleSubmit = (e)=>{
        e.preventDefault();
        if (!canAnswer || !inputValue.trim()) return;
        if (currentStep === "name") {
            handleNameSubmit(inputValue);
        } else if (currentStep === "age") {
            handleAgeSubmit(inputValue);
        } else if (currentStep === "email") {
            handleEmailSubmit(inputValue);
        }
        setInputValue("");
    };
    const handleTransitionComplete = ()=>{
        setShowPhaseTransition(false);
        router.push("/quiz");
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex h-screen flex-col bg-[#000000]",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                children: showPhaseTransition && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$components$2f$phase$2d$transition$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    phase: {
                        id: 1,
                        name: "The Mirror",
                        color: "#94A3B8",
                        text: "The mirror reflects what you hide...",
                        sound: "phase1"
                    },
                    onComplete: handleTransitionComplete
                }, void 0, false, {
                    fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                    lineNumber: 527,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                lineNumber: 525,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "border-b border-white/5 bg-black/50 p-4 backdrop-blur-sm",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mx-auto max-w-md",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-xs text-[#AEAEB2]",
                                children: "Hourglass synchronization"
                            }, void 0, false, {
                                fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                                lineNumber: 543,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-xs",
                                children: "⏳"
                            }, void 0, false, {
                                fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                                lineNumber: 544,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                        lineNumber: 542,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                    lineNumber: 541,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                lineNumber: 540,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: scrollContainerRef,
                className: "hide-scrollbar flex-1 overflow-y-auto p-4",
                style: {
                    willChange: "transform",
                    contain: "layout paint"
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mx-auto flex max-w-md flex-col space-y-1.5 pb-[420px]",
                    children: [
                        messages.map((message, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$components$2f$chat$2d$message$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                role: message.role,
                                text: message.text,
                                showReadReceipt: message.showReadReceipt && index === lastUserMessageIndex,
                                timestamp: message.timestamp
                            }, index, false, {
                                fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                                lineNumber: 556,
                                columnNumber: 13
                            }, this)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                            children: isTyping && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$components$2f$typing$2d$indicator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                                lineNumber: 565,
                                columnNumber: 41
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                            lineNumber: 565,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            ref: messagesEndRef
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                            lineNumber: 567,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                    lineNumber: 554,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                lineNumber: 549,
                columnNumber: 7
            }, this),
            canAnswer && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                className: "fixed bottom-0 left-0 right-0 border-t border-white/5 bg-gradient-to-t from-black from-70% via-black/95 to-transparent p-4 pt-8 pb-6 backdrop-blur-lg",
                initial: {
                    opacity: 0,
                    y: 20
                },
                animate: {
                    opacity: 1,
                    y: 0
                },
                transition: {
                    duration: 0.3
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mx-auto max-w-md",
                    children: [
                        currentStep === "invocation" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-3",
                            children: [
                                "I'm staying.",
                                "Show me.",
                                "I'm scared, but I want to know."
                            ].map((option, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].button, {
                                    onClick: ()=>handleInvocationChoice(option),
                                    initial: {
                                        opacity: 0,
                                        y: 10
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        delay: index * 0.1
                                    },
                                    whileTap: {
                                        scale: 0.97
                                    },
                                    whileHover: {
                                        scale: 1.01
                                    },
                                    className: "group relative overflow-hidden rounded-2xl bg-[#2C2C2E] px-6 py-4 text-[17px] font-medium text-[#E5E5EA] shadow-lg transition-all hover:bg-[#3A3A3C] active:shadow-xl",
                                    style: {
                                        fontFamily: "SF Pro Text, -apple-system, system-ui, sans-serif",
                                        boxShadow: "0 2px 8px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.05)"
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                            className: "absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent",
                                            initial: {
                                                x: "-100%"
                                            },
                                            whileHover: {
                                                x: "100%"
                                            },
                                            transition: {
                                                duration: 0.6
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                                            lineNumber: 596,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "relative",
                                            children: option
                                        }, void 0, false, {
                                            fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                                            lineNumber: 602,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, option, true, {
                                    fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                                    lineNumber: 582,
                                    columnNumber: 19
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                            lineNumber: 580,
                            columnNumber: 15
                        }, this),
                        currentStep === "gender" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-3",
                            children: [
                                "Man 🧠",
                                "Woman 💫"
                            ].map((option, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].button, {
                                    onClick: ()=>handleGenderChoice(option),
                                    initial: {
                                        opacity: 0,
                                        y: 10
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        delay: index * 0.1
                                    },
                                    whileTap: {
                                        scale: 0.97
                                    },
                                    whileHover: {
                                        scale: 1.01
                                    },
                                    className: "group relative overflow-hidden rounded-2xl bg-[#2C2C2E] px-6 py-4 text-[17px] font-medium text-[#E5E5EA] shadow-lg transition-all hover:bg-[#3A3A3C] active:shadow-xl",
                                    style: {
                                        fontFamily: "SF Pro Text, -apple-system, system-ui, sans-serif",
                                        boxShadow: "0 2px 8px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.05)"
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                            className: "absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent",
                                            initial: {
                                                x: "-100%"
                                            },
                                            whileHover: {
                                                x: "100%"
                                            },
                                            transition: {
                                                duration: 0.6
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                                            lineNumber: 625,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "relative",
                                            children: option
                                        }, void 0, false, {
                                            fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                                            lineNumber: 631,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, option, true, {
                                    fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                                    lineNumber: 611,
                                    columnNumber: 19
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                            lineNumber: 609,
                            columnNumber: 15
                        }, this),
                        (currentStep === "name" || currentStep === "age" || currentStep === "email") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                            onSubmit: handleSubmit,
                            className: "flex items-center gap-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    ref: inputRef,
                                    type: currentStep === "email" ? "email" : currentStep === "age" ? "number" : "text",
                                    value: inputValue,
                                    onChange: (e)=>setInputValue(e.target.value),
                                    placeholder: currentStep === "name" ? "Your first name…" : currentStep === "age" ? "Your age…" : "your@email.com",
                                    min: currentStep === "age" ? 13 : undefined,
                                    max: currentStep === "age" ? 120 : undefined,
                                    className: "flex-1 rounded-3xl bg-[#2C2C2E] px-5 py-3.5 text-[17px] text-[#E5E5EA] placeholder:text-[#8E8E93] outline-none ring-2 ring-transparent shadow-lg transition-all focus:bg-[#3A3A3C] focus:ring-[#0A84FF]",
                                    style: {
                                        fontFamily: "SF Pro Text, -apple-system, system-ui, sans-serif",
                                        boxShadow: "0 2px 8px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.05)"
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                                    lineNumber: 639,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].button, {
                                    type: "submit",
                                    disabled: !inputValue.trim(),
                                    whileTap: {
                                        scale: 0.9
                                    },
                                    whileHover: {
                                        scale: inputValue.trim() ? 1.05 : 1
                                    },
                                    className: "flex h-12 w-12 items-center justify-center rounded-full text-white shadow-lg transition-all disabled:opacity-40",
                                    style: {
                                        background: inputValue.trim() ? "linear-gradient(135deg, #007AFF 0%, #0A84FF 100%)" : "#2C2C2E",
                                        boxShadow: inputValue.trim() ? "0 4px 16px rgba(10, 132, 255, 0.5), 0 2px 4px rgba(0, 0, 0, 0.3)" : "0 2px 8px rgba(0, 0, 0, 0.3)"
                                    },
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        width: "20",
                                        height: "20",
                                        viewBox: "0 0 20 20",
                                        fill: "none",
                                        className: "transition-transform group-hover:translate-y-[-2px]",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            d: "M10 4L10 16M10 4L6 8M10 4L14 8",
                                            stroke: "currentColor",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round"
                                        }, void 0, false, {
                                            fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                                            lineNumber: 676,
                                            columnNumber: 21
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                                        lineNumber: 669,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                                    lineNumber: 656,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                            lineNumber: 638,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                    lineNumber: 578,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
                lineNumber: 572,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/lifeclock-20251031-141611/app/onboarding/page.tsx",
        lineNumber: 524,
        columnNumber: 5
    }, this);
}
_s(OnboardingPage, "EOpaOIiT7+sZK4xSoQHsmIDOJJo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$lifeclock$2d$20251031$2d$141611$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"]
    ];
});
_c = OnboardingPage;
var _c;
__turbopack_context__.k.register(_c, "OnboardingPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=lifeclock-20251031-141611_389e78ca._.js.map