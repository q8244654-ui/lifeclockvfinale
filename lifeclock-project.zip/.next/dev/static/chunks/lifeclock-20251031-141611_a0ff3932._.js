(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0b63d49a._.js",
  "static/chunks/bbd6e_next_dist_compiled_react-dom_1427af18._.js",
  "static/chunks/bbd6e_next_dist_compiled_react-server-dom-turbopack_c7985410._.js",
  "static/chunks/bbd6e_next_dist_compiled_next-devtools_index_f78f1461.js",
  "static/chunks/bbd6e_next_dist_compiled_2aae1744._.js",
  "static/chunks/bbd6e_next_dist_client_04f8643b._.js",
  "static/chunks/bbd6e_next_dist_9a178af7._.js",
  "static/chunks/bbd6e_@swc_helpers_cjs_d8c36acf._.js"
],
    source: "entry"
});
