(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/bbd6e_@supabase_node-fetch_browser_8eba92b3.js",
  "static/chunks/bbd6e_078697bb._.js",
  "static/chunks/lifeclock-20251031-141611_bc13fccb._.js"
],
    source: "dynamic"
});
