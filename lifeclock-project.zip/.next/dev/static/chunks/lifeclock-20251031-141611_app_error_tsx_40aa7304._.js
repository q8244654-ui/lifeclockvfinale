(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/bbd6e_6e8f6e88._.js",
  "static/chunks/lifeclock-20251031-141611_app_error_tsx_e5270dab._.js"
],
    source: "dynamic"
});
