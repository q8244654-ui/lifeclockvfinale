(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/bbd6e_next_dist_34c502a6._.js",
  "static/chunks/lifeclock-20251031-141611_app_global-error_tsx_1bf410ca._.js"
],
    source: "dynamic"
});
