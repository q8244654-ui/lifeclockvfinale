(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__2c4e73ad._.css",
  "static/chunks/bbd6e_@vercel_analytics_dist_react_index_mjs_61baac94._.js"
],
    source: "dynamic"
});
