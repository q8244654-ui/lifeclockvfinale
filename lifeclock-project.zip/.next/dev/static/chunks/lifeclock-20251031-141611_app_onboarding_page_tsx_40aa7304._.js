(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/bbd6e_@supabase_node-fetch_browser_8eba92b3.js",
  "static/chunks/bbd6e_motion-dom_dist_es_87429fac._.js",
  "static/chunks/bbd6e_framer-motion_dist_es_381dee2a._.js",
  "static/chunks/bbd6e_@supabase_storage-js_dist_module_a31c473a._.js",
  "static/chunks/bbd6e_@supabase_auth-js_dist_module_38c37597._.js",
  "static/chunks/bbd6e_f7e5d97a._.js",
  "static/chunks/lifeclock-20251031-141611_a5012b39._.js"
],
    source: "dynamic"
});
