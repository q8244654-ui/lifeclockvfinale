(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/lifeclock-20251031-141611_fd5235fa._.js",
  "static/chunks/bbd6e_d6a281d2._.js"
],
    source: "dynamic"
});
