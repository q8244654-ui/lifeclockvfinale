import Stripe from "stripe"
import { NextResponse } from "next/server"
import { createCheckoutSessionSchema } from "@/lib/validators/stripe"

const stripeSecretKey = process.env.STRIPE_SECRET_KEY
const priceId = process.env.LIFECLOCK_PRICE_ID

if (!stripeSecretKey) {
  throw new Error("Missing STRIPE_SECRET_KEY")
}
if (!priceId) {
  throw new Error("Missing LIFECLOCK_PRICE_ID")
}

const stripe = new Stripe(stripeSecretKey, {
  apiVersion: "2024-06-20",
})

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { referralCode, email } = createCheckoutSessionSchema.parse(body)

    const origin = request.headers.get("origin") || request.headers.get("referer") || ""
    const baseUrl = origin || process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000"

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      success_url: `${baseUrl}/generating`,
      cancel_url: `${baseUrl}/result`,
      metadata: {
        referral_code: referralCode || "",
        referred_email: email || "",
      },
    })

    return NextResponse.json({ url: session.url })
  } catch (error) {
    console.error("[v0] create-checkout-session error:", error)
    return NextResponse.json({ error: "Unable to create checkout session" }, { status: 500 })
  }
}


