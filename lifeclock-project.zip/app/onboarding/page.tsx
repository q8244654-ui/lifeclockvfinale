"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { motion, AnimatePresence } from "framer-motion"
import ChatMessage from "@/components/chat-message"
import TypingIndicator from "@/components/typing-indicator"
import PhaseTransition from "@/components/phase-transition"
import { createClient } from "@/lib/supabase/client"
import { generateReferralCode } from "@/lib/generate-referral-code" // Import referral code generator
import { tracking } from "@/lib/tracking"

interface Message {
  role: "assistant" | "user"
  text: string
  timestamp?: string
  showReadReceipt?: boolean
}

interface OnboardingData {
  name: string
  age: number
  gender: string
  email: string
  signature: string
  referral_code: string
}

type Step = "invocation" | "name" | "age" | "gender" | "email" | "signature" | "complete"

export default function OnboardingPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [messages, setMessages] = useState<Message[]>([])
  const [currentStep, setCurrentStep] = useState<Step>("invocation")
  const [isTyping, setIsTyping] = useState(false)
  const [canAnswer, setCanAnswer] = useState(false)
  const [inputValue, setInputValue] = useState("")
  const [userData, setUserData] = useState<Partial<OnboardingData>>({})
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const scrollContainerRef = useRef<HTMLDivElement>(null)
  const [isAtBottom, setIsAtBottom] = useState(true)
  const autoScrollTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const [lastUserMessageIndex, setLastUserMessageIndex] = useState<number>(-1)
  const [hasStarted, setHasStarted] = useState(false)
  const [showPhaseTransition, setShowPhaseTransition] = useState(false) // Add phase transition state

  useEffect(() => {
    if (hasStarted) return

    const refCode = searchParams.get("ref")
    if (refCode) {
      localStorage.setItem("lifeclock-referral-code", refCode)
      console.log("[v0] Referral code captured:", refCode)
    }

    // Track page visit once per session
    ;(async () => {
      try {
        await tracking.pageVisit()
      } catch {}
    })()

    setHasStarted(true)
    const timer = setTimeout(() => {
      startInvocation()
    }, 1000)
    return () => clearTimeout(timer)
  }, []) // Empty dependency array to run only once

  // Auto-scroll system: waits ~400ms to sync with animations, scrolls only if user is at bottom
  useEffect(() => {
    if (!scrollContainerRef.current) return
    if (!isAtBottom) return
    if (autoScrollTimeoutRef.current) {
      clearTimeout(autoScrollTimeoutRef.current)
    }
    autoScrollTimeoutRef.current = setTimeout(() => {
      const el = scrollContainerRef.current
      if (!el) return
      // Double-check user still at bottom just before scrolling
      const threshold = 40
      const atBottomNow = el.scrollTop + el.clientHeight >= el.scrollHeight - threshold
      if (atBottomNow) {
        el.scrollTo({ top: el.scrollHeight, behavior: "smooth" })
      }
    }, 400)
    return () => {
      if (autoScrollTimeoutRef.current) {
        clearTimeout(autoScrollTimeoutRef.current)
      }
    }
  }, [messages, isTyping, isAtBottom])

  // Track whether user is near bottom to avoid interrupting reading
  useEffect(() => {
    const el = scrollContainerRef.current
    if (!el) return
    const handleScroll = () => {
      const threshold = 40
      const atBottom = el.scrollTop + el.clientHeight >= el.scrollHeight - threshold
      setIsAtBottom(atBottom)
    }
    // Prime state on mount and whenever content size changes
    handleScroll()
    el.addEventListener("scroll", handleScroll, { passive: true })
    window.addEventListener("resize", handleScroll)
    return () => {
      el.removeEventListener("scroll", handleScroll)
      window.removeEventListener("resize", handleScroll)
    }
  }, [])

  useEffect(() => {
    if (canAnswer && inputRef.current) {
      inputRef.current.focus()
    }
  }, [canAnswer])

  const playSound = (sound: string) => {
    try {
      const audio = new Audio(`/sounds/${sound}.mp3`)
      audio.volume = 0.3
      audio.play().catch(() => {})
    } catch (e) {}
  }

  const vibrate = (duration: number) => {
    if (typeof navigator !== "undefined" && navigator.vibrate) {
      navigator.vibrate(duration)
    }
  }

  const getCurrentTime = () => {
    const now = new Date()
    return `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}`
  }

  const addBotMessage = (text: string, callback?: () => void) => {
    setIsTyping(true)
    const typingDelay = Math.random() * 700 + 600

    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          text,
        },
      ])
      setIsTyping(false)
      playSound("pop")
      vibrate(40)

      if (callback) {
        setTimeout(callback, 800)
      }
    }, typingDelay)
  }

  const startInvocation = () => {
    addBotMessage("Uh...", () => {
      addBotMessage("What are you doing here?", () => {
        addBotMessage("No, seriously.", () => {
          addBotMessage("Why are you here, now, at this precise moment?", () => {
            addBotMessage("Most people spend their lives running from these kinds of questions.", () => {
              addBotMessage("You came looking for them.", () => {
                addBotMessage("Interesting.", () => {
                  addBotMessage("Well. Since you're here...", () => {
                    addBotMessage("I'm LifeClock.", () => {
                      addBotMessage(
                        "And if you stay, I'll show you something few people have the courage to see:",
                        () => {
                          addBotMessage("You. The real you.", () => {
                            addBotMessage("Not the image you project.", () => {
                              addBotMessage("Not the version you tell.", () => {
                                addBotMessage("You.", () => {
                                  addBotMessage("So... are you staying?", () => {
                                    addBotMessage("Or do you prefer to keep pretending?", () => {
                                      setCanAnswer(true)
                                    })
                                  })
                                })
                              })
                            })
                          })
                        },
                      )
                    })
                  })
                })
              })
            })
          })
        })
      })
    })
  }

  const handleInvocationChoice = (choice: string) => {
    if (!canAnswer) return

    playSound("pop")
    vibrate(40)
    setCanAnswer(false)

    const userMessage: Message = {
      role: "user",
      text: choice,
      timestamp: getCurrentTime(),
      showReadReceipt: true,
    }

    setMessages((prev) => {
      const newMessages = [...prev, userMessage]
      setLastUserMessageIndex(newMessages.length - 1)
      return newMessages
    })

    addBotMessage("Perfect.", () => {
      setMessages((prev) =>
        prev.map((msg, idx) => (idx === lastUserMessageIndex ? { ...msg, showReadReceipt: false } : msg)),
      )
      addBotMessage("What's your first name?", () => {
        setCurrentStep("name")
        setCanAnswer(true)
      })
    })
  }

  const handleNameSubmit = (name: string) => {
    playSound("pop")
    vibrate(40)
    setCanAnswer(false)

    const userMessage: Message = {
      role: "user",
      text: name,
      timestamp: getCurrentTime(),
      showReadReceipt: true,
    }

    setMessages((prev) => {
      const newMessages = [...prev, userMessage]
      setLastUserMessageIndex(newMessages.length - 1)
      return newMessages
    })

    setUserData((prev) => ({ ...prev, name }))

    let response = ""
    if (name.length <= 4) {
      response = `Nice to meet you, ${name}. Short and clear — like a spark ready to strike.`
    } else if (name.length >= 8) {
      response = `Nice to meet you, ${name}. Long and deep — a wave that never fades.`
    } else {
      response = `Nice to meet you, ${name}. Your name carries a rare vibration.`
    }

    addBotMessage(response, () => {
      setMessages((prev) =>
        prev.map((msg, idx) => (idx === lastUserMessageIndex ? { ...msg, showReadReceipt: false } : msg)),
      )
      addBotMessage(`How old are you, ${name}?`, () => {
        setCurrentStep("age")
        setCanAnswer(true)
      })
    })
  }

  const handleAgeSubmit = (ageStr: string) => {
    const age = Number(ageStr)

    if (isNaN(age) || age < 13 || age > 120) {
      addBotMessage("I didn't understand. Enter a valid age.")
      return
    }

    playSound("pop")
    vibrate(40)
    setCanAnswer(false)

    const userMessage: Message = {
      role: "user",
      text: ageStr,
      timestamp: getCurrentTime(),
      showReadReceipt: true,
    }

    setMessages((prev) => {
      const newMessages = [...prev, userMessage]
      setLastUserMessageIndex(newMessages.length - 1)
      return newMessages
    })

    setUserData((prev) => ({ ...prev, age }))

    let response = ""
    if (age < 20) {
      response = "At the dawn of fire — you're just entering the world of conscious beings."
    } else if (age < 30) {
      response = `${age} years old... The years when you choose what you'll become: flame or ash.`
    } else if (age < 40) {
      response = `${age} years old. The decade of irreversible choices, where you sculpt your destiny.`
    } else if (age < 60) {
      response = `${age} years old. The age of reckonings and rebirths.`
    } else {
      response = `${age} years old. The time of silent mirrors, where every second becomes a sacred memory.`
    }

    addBotMessage(response, () => {
      setMessages((prev) =>
        prev.map((msg, idx) => (idx === lastUserMessageIndex ? { ...msg, showReadReceipt: false } : msg)),
      )
      addBotMessage("How do you define yourself?", () => {
        setCurrentStep("gender")
        setCanAnswer(true)
      })
    })
  }

  const handleGenderChoice = (gender: string) => {
    if (!canAnswer) return

    playSound("pop")
    vibrate(40)
    setCanAnswer(false)

    const userMessage: Message = {
      role: "user",
      text: gender,
      timestamp: getCurrentTime(),
      showReadReceipt: true,
    }

    setMessages((prev) => {
      const newMessages = [...prev, userMessage]
      setLastUserMessageIndex(newMessages.length - 1)
      return newMessages
    })

    setUserData((prev) => ({ ...prev, gender }))

    let response = ""
    if (gender === "Man 🧠") {
      response = "Your energy is solar, anchored in movement and creation."
    } else if (gender === "Woman 💫") {
      response = "Your energy is lunar, fluid, guided by cycle and intuition."
    }

    addBotMessage(response, () => {
      setMessages((prev) =>
        prev.map((msg, idx) => (idx === lastUserMessageIndex ? { ...msg, showReadReceipt: false } : msg)),
      )
      addBotMessage(`Last thing, ${userData.name}.`, () => {
        addBotMessage("To send you your complete report, I need your email.", () => {
          addBotMessage("(Promise, no spam. Just your LifeClock.)", () => {
            setCurrentStep("email")
            setCanAnswer(true)
          })
        })
      })
    })
  }

  const handleEmailSubmit = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      addBotMessage("Hmm, this email doesn't seem correct.")
      return
    }

    // Track email given (by unique email)
    ;(async () => {
      try {
        await tracking.emailGiven(email)
      } catch {}
    })()

    playSound("pop")
    vibrate(40)
    setCanAnswer(false)

    const userMessage: Message = {
      role: "user",
      text: email,
      timestamp: getCurrentTime(),
      showReadReceipt: true,
    }

    setMessages((prev) => {
      const newMessages = [...prev, userMessage]
      setLastUserMessageIndex(newMessages.length - 1)
      return newMessages
    })

    setUserData((prev) => ({ ...prev, email }))

    addBotMessage(`Perfect, ${userData.name}.`, () => {
      setMessages((prev) =>
        prev.map((msg, idx) => (idx === lastUserMessageIndex ? { ...msg, showReadReceipt: false } : msg)),
      )

      const signature = `${userData.name?.toUpperCase()}-${(userData.age || 0) * 3}-${userData.gender?.[0] || "X"}`
      setUserData((prev) => ({ ...prev, signature }))

      addBotMessage("Your clock is synchronized.", () => {
        addBotMessage(`Your temporal signature: ${signature}`, () => {
          addBotMessage(`Before you: 10 doors.\nEach reveals a facet of your being.`, () => {
            addBotMessage("The journey takes 15 minutes.", () => {
              addBotMessage("But what you'll discover will last a lifetime.", () => {
                const readyQuestion =
                  userData.gender === "Man 🧠"
                    ? "Are you ready to cross the first door?"
                    : "Are you ready to cross the first door?"

                addBotMessage(readyQuestion, () => {
                  addBotMessage(`The first Door opens now. 🌒`, () => {
                    const finalData: OnboardingData = {
                      name: userData.name || "",
                      age: userData.age || 0,
                      gender: userData.gender || "",
                      email: email,
                      signature,
                      referral_code: generateReferralCode(email), // Generate referral code for this user
                    }

                    localStorage.setItem("lifeclockOnboarding", JSON.stringify(finalData))

                    const supabase = createClient()
                    ;(async () => {
                      try {
                        const { error } = await supabase
                          .from("onboarding_data")
                          .insert({
                            name: finalData.name,
                            age: finalData.age,
                            gender: finalData.gender,
                            email: finalData.email,
                            referral_code: finalData.referral_code,
                          })

                        if (error) {
                          console.error("[v0] Error saving to Supabase:", {
                            message: error.message,
                            details: (error as any)?.details,
                            hint: (error as any)?.hint,
                            code: (error as any)?.code,
                          })
                        } else {
                          console.log("[v0] Onboarding data saved to Supabase")
                        }
                      } catch (e) {
                        console.error("[v0] Exception saving to Supabase:", e)
                      }
                    })()

                    const refCode = localStorage.getItem("lifeclock-referral-code")
                    if (refCode) {
                      supabase
                        .from("onboarding_data")
                        .select("email")
                        .eq("referral_code", refCode)
                        .single()
                        .then(({ data: referrerData, error: referrerError }) => {
                          if (!referrerError && referrerData) {
                            supabase
                              .from("referrals")
                              .insert({
                                referrer_email: referrerData.email,
                                referrer_code: refCode,
                                referred_email: finalData.email,
                                status: "pending",
                              })
                              .then(({ error: refError }) => {
                                if (refError) {
                                  console.error("[v0] Error tracking referral:", refError)
                                } else {
                                  console.log("[v0] Referral tracked successfully")
                                }
                              })
                          }
                        })
                    }

                    setTimeout(() => {
                      playSound("complete")
                      vibrate(80)
                      setShowPhaseTransition(true)
                    }, 2000)
                  })
                })
              })
            })
          })
        })
      })
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!canAnswer || !inputValue.trim()) return

    if (currentStep === "name") {
      handleNameSubmit(inputValue)
    } else if (currentStep === "age") {
      handleAgeSubmit(inputValue)
    } else if (currentStep === "email") {
      handleEmailSubmit(inputValue)
    }

    setInputValue("")
  }

  const handleTransitionComplete = () => {
    setShowPhaseTransition(false)
    router.push("/quiz")
  }

  return (
    <div className="flex h-screen flex-col bg-[#000000]">
      <AnimatePresence>
        {showPhaseTransition && (
          <PhaseTransition
            phase={{
              id: 1,
              name: "The Mirror",
              color: "#94A3B8",
              text: "The mirror reflects what you hide...",
              sound: "phase1",
            }}
            onComplete={handleTransitionComplete}
          />
        )}
      </AnimatePresence>

      <div className="border-b border-white/5 bg-black/50 p-4 backdrop-blur-sm">
        <div className="mx-auto max-w-md">
          <div className="flex items-center justify-center gap-2">
            <span className="text-xs text-[#AEAEB2]">Hourglass synchronization</span>
            <span className="text-xs">⏳</span>
          </div>
        </div>
      </div>

      <div
        ref={scrollContainerRef}
        className="hide-scrollbar flex-1 overflow-y-auto p-4"
        style={{ willChange: "transform", contain: "layout paint" }}
      >
        <div className="mx-auto flex max-w-md flex-col space-y-1.5 pb-[420px]">
          {messages.map((message, index) => (
            <ChatMessage
              key={index}
              role={message.role}
              text={message.text}
              showReadReceipt={message.showReadReceipt && index === lastUserMessageIndex}
              timestamp={message.timestamp}
            />
          ))}

          <AnimatePresence>{isTyping && <TypingIndicator />}</AnimatePresence>

          <div ref={messagesEndRef} />
        </div>
      </div>

      {canAnswer && (
        <motion.div
          className="fixed bottom-0 left-0 right-0 border-t border-white/5 bg-gradient-to-t from-black from-70% via-black/95 to-transparent p-4 pt-8 pb-6 backdrop-blur-lg"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="mx-auto max-w-md">
            {currentStep === "invocation" && (
              <div className="flex flex-col gap-3">
                {["I'm staying.", "Show me.", "I'm scared, but I want to know."].map((option, index) => (
                  <motion.button
                    key={option}
                    onClick={() => handleInvocationChoice(option)}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    whileTap={{ scale: 0.97 }}
                    whileHover={{ scale: 1.01 }}
                    className="group relative overflow-hidden rounded-2xl bg-[#2C2C2E] px-6 py-4 text-[17px] font-medium text-[#E5E5EA] shadow-lg transition-all hover:bg-[#3A3A3C] active:shadow-xl"
                    style={{
                      fontFamily: "SF Pro Text, -apple-system, system-ui, sans-serif",
                      boxShadow: "0 2px 8px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.05)",
                    }}
                  >
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent"
                      initial={{ x: "-100%" }}
                      whileHover={{ x: "100%" }}
                      transition={{ duration: 0.6 }}
                    />
                    <span className="relative">{option}</span>
                  </motion.button>
                ))}
              </div>
            )}

            {currentStep === "gender" && (
              <div className="flex flex-col gap-3">
                {["Man 🧠", "Woman 💫"].map((option, index) => (
                  <motion.button
                    key={option}
                    onClick={() => handleGenderChoice(option)}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    whileTap={{ scale: 0.97 }}
                    whileHover={{ scale: 1.01 }}
                    className="group relative overflow-hidden rounded-2xl bg-[#2C2C2E] px-6 py-4 text-[17px] font-medium text-[#E5E5EA] shadow-lg transition-all hover:bg-[#3A3A3C] active:shadow-xl"
                    style={{
                      fontFamily: "SF Pro Text, -apple-system, system-ui, sans-serif",
                      boxShadow: "0 2px 8px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.05)",
                    }}
                  >
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent"
                      initial={{ x: "-100%" }}
                      whileHover={{ x: "100%" }}
                      transition={{ duration: 0.6 }}
                    />
                    <span className="relative">{option}</span>
                  </motion.button>
                ))}
              </div>
            )}

            {(currentStep === "name" || currentStep === "age" || currentStep === "email") && (
              <form onSubmit={handleSubmit} className="flex items-center gap-3">
                <input
                  ref={inputRef}
                  type={currentStep === "email" ? "email" : currentStep === "age" ? "number" : "text"}
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder={
                    currentStep === "name" ? "Your first name…" : currentStep === "age" ? "Your age…" : "your@email.com"
                  }
                  min={currentStep === "age" ? 13 : undefined}
                  max={currentStep === "age" ? 120 : undefined}
                  className="flex-1 rounded-3xl bg-[#2C2C2E] px-5 py-3.5 text-[17px] text-[#E5E5EA] placeholder:text-[#8E8E93] outline-none ring-2 ring-transparent shadow-lg transition-all focus:bg-[#3A3A3C] focus:ring-[#0A84FF]"
                  style={{
                    fontFamily: "SF Pro Text, -apple-system, system-ui, sans-serif",
                    boxShadow: "0 2px 8px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.05)",
                  }}
                />

                <motion.button
                  type="submit"
                  disabled={!inputValue.trim()}
                  whileTap={{ scale: 0.9 }}
                  whileHover={{ scale: inputValue.trim() ? 1.05 : 1 }}
                  className="flex h-12 w-12 items-center justify-center rounded-full text-white shadow-lg transition-all disabled:opacity-40"
                  style={{
                    background: inputValue.trim() ? "linear-gradient(135deg, #007AFF 0%, #0A84FF 100%)" : "#2C2C2E",
                    boxShadow: inputValue.trim()
                      ? "0 4px 16px rgba(10, 132, 255, 0.5), 0 2px 4px rgba(0, 0, 0, 0.3)"
                      : "0 2px 8px rgba(0, 0, 0, 0.3)",
                  }}
                >
                  <svg
                    width="20"
                    height="20"
                    viewBox="0 0 20 20"
                    fill="none"
                    className="transition-transform group-hover:translate-y-[-2px]"
                  >
                    <path
                      d="M10 4L10 16M10 4L6 8M10 4L14 8"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </motion.button>
              </form>
            )}
          </div>
        </motion.div>
      )}
    </div>
  )
}
