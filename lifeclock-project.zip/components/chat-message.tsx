"use client"

import { motion } from "framer-motion"
import { cn } from "@/lib/utils"
import { useState, useEffect } from "react"

interface ChatMessageProps {
  role: "assistant" | "user"
  text: string
  delay?: number
  messageType?: "normal" | "motivation" | "revelation" | "introspection" | "humor"
  showReadReceipt?: boolean
  timestamp?: string
}

export default function ChatMessage({
  role,
  text,
  delay = 0,
  messageType = "normal",
  showReadReceipt = false,
  timestamp,
}: ChatMessageProps) {
  const isAssistant = role === "assistant"
  const [showReceipt, setShowReceipt] = useState(false)

  useEffect(() => {
    if (showReadReceipt && !isAssistant) {
      const timer = setTimeout(() => {
        setShowReceipt(true)
      }, 1500)
      return () => clearTimeout(timer)
    }
  }, [showReadReceipt, isAssistant])

  const messageStyles = {
    normal: {
      background: "#2C2C2E",
      color: "#E5E5EA",
      glow: "none",
      haloColor: "transparent",
      tailColor: "#2C2C2E",
    },
    motivation: {
      background: "linear-gradient(135deg, #F97316 0%, #FB923C 100%)",
      color: "#FFFFFF",
      glow: "0 0 15px rgba(249, 115, 22, 0.5)",
      haloColor: "#F97316",
      tailColor: "#F97316", // Use darker orange from gradient start
    },
    revelation: {
      background: "linear-gradient(135deg, #EF4444 0%, #F87171 100%)",
      color: "#FFFFFF",
      glow: "0 0 15px rgba(239, 68, 68, 0.5)",
      haloColor: "#EF4444",
      tailColor: "#EF4444", // Use darker red from gradient start
    },
    introspection: {
      background: "linear-gradient(135deg, #EAB308 0%, #FCD34D 100%)",
      color: "#000000",
      glow: "0 0 15px rgba(234, 179, 8, 0.5)",
      haloColor: "#EAB308",
      tailColor: "#EAB308", // Use darker yellow from gradient start
    },
    humor: {
      background: "linear-gradient(135deg, #22C55E 0%, #4ADE80 100%)",
      color: "#FFFFFF",
      glow: "0 0 15px rgba(34, 197, 94, 0.5)",
      haloColor: "#22C55E",
      tailColor: "#22C55E", // Use darker green from gradient start
    },
  }

  const style = isAssistant && messageType !== "normal" ? messageStyles[messageType] : messageStyles.normal

  if (isAssistant && messageType !== "normal") {
    return (
      <motion.div
        className="flex w-full justify-start"
        initial={{ opacity: 0, y: 10, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{
          duration: 0.5,
          delay,
          type: "spring",
          stiffness: 200,
          damping: 20,
        }}
      >
        <div className="relative">
          {/* Colored halo behind value message */}
          <motion.div
            className="absolute inset-0 -z-10 blur-xl"
            animate={{
              opacity: [0.4, 0.6, 0.4],
              scale: [1, 1.15, 1],
            }}
            transition={{
              duration: 2.5,
              repeat: Number.POSITIVE_INFINITY,
              ease: "easeInOut",
            }}
            style={{
              background: `radial-gradient(circle, ${style.haloColor}50 0%, transparent 70%)`,
            }}
          />
          <motion.div
            className="relative max-w-[80%] rounded-3xl px-4 py-2 text-pretty"
            style={{
              background: style.background,
              color: style.color,
              fontSize: "17px",
              lineHeight: "22px",
              boxShadow: style.glow,
            }}
            whileHover={{ scale: 1.02 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <p>{text}</p>
          </motion.div>
        </div>
      </motion.div>
    )
  }

  return (
    <motion.div
      className={cn("flex w-full flex-col", isAssistant ? "items-start" : "items-end")}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.3,
        delay,
        type: "spring",
        stiffness: 260,
        damping: 20,
      }}
    >
      <div
        className={cn(
          "max-w-[80%] rounded-3xl px-4 py-2 text-pretty",
          isAssistant ? "imessage-bubble-assistant" : "imessage-bubble-user",
        )}
        style={{
          fontSize: "17px",
          lineHeight: "22px",
        }}
      >
        <p>{text}</p>
      </div>

      {!isAssistant && showReceipt && timestamp && (
        <motion.div
          className="mt-0.5 pr-1.5 text-right"
          initial={{ opacity: 0, y: 3 }}
          animate={{
            opacity: [0, 1, 0.7, 1],
            y: 0,
          }}
          transition={{
            opacity: { duration: 0.6, times: [0, 0.5, 0.7, 1] },
            y: { duration: 0.6 },
          }}
        >
          <span
            className="text-[12px] text-[#8E8E93]"
            style={{ fontFamily: "SF Pro Text, -apple-system, system-ui, sans-serif" }}
          >
            read at {timestamp}
          </span>
        </motion.div>
      )}
    </motion.div>
  )
}
