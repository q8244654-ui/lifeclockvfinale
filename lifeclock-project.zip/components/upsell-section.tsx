"use client"

import { motion } from "framer-motion"
import { Sparkles, Users, ArrowRight } from "lucide-react"

export default function UpsellSection() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20 p-8 backdrop-blur-sm space-y-6"
    >
      <div className="text-center space-y-2">
        <div className="flex items-center justify-center gap-2 text-2xl font-bold text-white">
          <Sparkles className="w-6 h-6 text-yellow-400" />
          Aller plus loin
        </div>
        <p className="text-gray-300">Ton rapport n'est que le début du voyage</p>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <motion.div
          whileHover={{ scale: 1.02 }}
          className="rounded-xl bg-white/5 border border-white/10 p-6 space-y-3 cursor-pointer hover:border-purple-500/50 transition-colors"
        >
          <div className="w-12 h-12 rounded-full bg-purple-500/20 flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-purple-400" />
          </div>
          <h3 className="text-lg font-semibold text-white">Coaching 1-to-1</h3>
          <p className="text-sm text-gray-400">
            Travaille avec un coach certifié LifeClock pour transformer tes insights en actions concrètes.
          </p>
          <div className="flex items-center gap-2 text-purple-400 text-sm font-medium">
            En savoir plus <ArrowRight className="w-4 h-4" />
          </div>
        </motion.div>

        <motion.div
          whileHover={{ scale: 1.02 }}
          className="rounded-xl bg-white/5 border border-white/10 p-6 space-y-3 cursor-pointer hover:border-pink-500/50 transition-colors"
        >
          <div className="w-12 h-12 rounded-full bg-pink-500/20 flex items-center justify-center">
            <Users className="w-6 h-6 text-pink-400" />
          </div>
          <h3 className="text-lg font-semibold text-white">Communauté LifeClock</h3>
          <p className="text-sm text-gray-400">
            Rejoins une communauté de personnes qui, comme toi, ont choisi de se connaître vraiment.
          </p>
          <div className="flex items-center gap-2 text-pink-400 text-sm font-medium">
            Rejoindre <ArrowRight className="w-4 h-4" />
          </div>
        </motion.div>
      </div>

      <div className="text-center pt-4 border-t border-white/10">
        <p className="text-xs text-gray-500">Ces options sont disponibles pour approfondir ton expérience LifeClock</p>
      </div>
    </motion.div>
  )
}
