// Minimal i18n structure for French
// Can be extended with next-intl or similar library later

export const translations = {
  fr: {
    common: {
      error: 'Une erreur est survenue',
      retry: 'Réessayer',
      backHome: 'Retour à l\'accueil',
      loading: 'Chargement...',
    },
    onboarding: {
      title: 'Bienvenue',
      namePrompt: 'Quel est votre nom ?',
      agePrompt: 'Quel est votre âge ?',
      emailPrompt: 'Quel est votre email ?',
    },
    quiz: {
      title: 'Quiz',
      next: 'Suivant',
      previous: 'Précédent',
      submit: 'Soumettre',
    },
    result: {
      title: 'Vos résultats',
      viewReport: 'Voir le rapport',
      downloadPDF: 'Télécharger PDF',
    },
  },
} as const

export type Locale = 'fr'
export type TranslationKey = keyof typeof translations.fr

export function t(key: string, locale: Locale = 'fr'): string {
  const keys = key.split('.')
  let value: any = translations[locale]
  
  for (const k of keys) {
    value = value?.[k]
    if (value === undefined) {
      return key // Return key as fallback
    }
  }
  
  return typeof value === 'string' ? value : key
}

// Helper to get nested translations
export function getTranslation(path: string, locale: Locale = 'fr'): string {
  return t(path, locale)
}

