import { createBrowserClient } from "@supabase/ssr"

export function createClient() {
  // Debug temporaire: vérifier la présence des variables NEXT_PUBLIC_* côté client
  if (typeof window !== "undefined") {
    try {
      // N'affiche pas les valeurs complètes en console
      // Affiche uniquement des indicateurs pour diagnostiquer le chargement des variables
      // et un préfixe tronqué pour l'URL (non sensible)
      // Ces logs peuvent être retirés une fois le problème résolu
      // eslint-disable-next-line no-console
      console.log(
        "[Supabase] URL défini:",
        Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL),
        "prefix:",
        process.env.NEXT_PUBLIC_SUPABASE_URL?.slice(0, 30) || ""
      )
      // eslint-disable-next-line no-console
      console.log(
        "[Supabase] ANON_KEY défini:",
        Boolean(process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY)
      )
    } catch {}
  }
  return createBrowserClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!)
}
